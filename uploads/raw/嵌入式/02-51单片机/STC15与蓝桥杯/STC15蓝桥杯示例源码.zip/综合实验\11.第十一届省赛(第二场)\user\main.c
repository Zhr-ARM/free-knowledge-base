#include "main.h"
#include "hardware.h"
#include "onewire.h"
#include "iic.h"

uint8_t xdata led=0xff;
uint8_t xdata buzzer_flag=OFF;
uint8_t xdata relay_flag=OFF;

uint32_t xdata temperature;
uint32_t pcfv;

uint8_t xdata mode=SHOW;

uint8_t xdata time1_10ms;
uint8_t xdata time1_191ms;

void Timer1Init(void)		//1����@12.000MHz
{
	AUXR |= 0x40;		//��ʱ��ʱ��1Tģʽ
	TMOD &= 0x0F;		//���ö�ʱ��ģʽ
	TL1 = 0x20;		//���ö�ʱ��ֵ
	TH1 = 0xD1;		//���ö�ʱ��ֵ
	TF1 = 0;		//���TF1��־
	TR1 = 1;		//��ʱ��1��ʼ��ʱ
	
	ET1=1;
	EA=1;
}
uint32_t xdata t_max=3000;
uint32_t xdata t_min=2000;
uint32_t xdata t_max_buf=3000;
uint32_t xdata t_min_buf=2000;
uint32_t xdata t_max_temp=3000;
uint32_t xdata t_min_temp=2000;
uint8_t xdata flag=0;

void mode_select(void)
{
	if(mode==CONFIG)
	{
		dig_buf[mode][0]=24;
				
		dig_buf[mode][3]=t_max_temp/1000%10;
		dig_buf[mode][4]=t_max_temp/100%10;
		dig_buf[mode][6]=t_min_temp/1000%10;
		dig_buf[mode][7]=t_min_temp/100%10;
	}
	else if(mode==SHOW)
	{
		dig_buf[mode][0]=12;
		
		dig_buf[mode][6]=temperature/1000%10;
		dig_buf[mode][7]=temperature/100%10;
	}
}

void key_handle(void)
{
	if(key_value==7&&key_state==5)
	{
		if(mode==CONFIG)
		{
			if(flag==0)
			{
				if(t_max_temp<=9800)
					t_max_temp+=100;
				else
					t_max_temp=0;
			}
			else
			{
				if(t_min_temp<=9800)
					t_min_temp+=100;
				else
					t_min_temp=0;
			}
		}
	}
	else if(key_value==6&&key_state==5)
	{
		if(mode==CONFIG)
		{
			if(flag==0)
			{
				if(t_max_temp>0)
					t_max_temp-=100;
				else
					t_max_temp=9900;
			}
			else
			{
				if(t_min_temp>0)
					t_min_temp-=100;
				else
					t_min_temp=99;
			}
				
			
		}
	}
	else if(key_value==5&&key_state==5)
	{
		if(mode==CONFIG)
		{
			if(++flag>=2)	flag=0;
		}
	}
	else if(key_value==4&&key_state==5)
	{
		if(mode==0)	mode=1;
		else if(mode==1)
		{
			if(t_max_temp>=t_min_temp)
			{
				t_max_buf=t_max_temp;
				t_min_buf=t_min_temp;
				t_max=t_max_temp;
				t_min=t_min_temp;
				led|=0x08;
				mode=0;
			}
			else
			{
				t_max_temp=t_max_buf;
				t_min_temp=t_min_buf;
				led&=~0x08;
				mode=0;
			}
		}
	}
}

void show_handle(void)
{
	if(temperature>t_max)
	{
		led&=~0x01;
		pcf8591_write(4);
	}
	else
		led|=0x01;
	if(temperature<=t_max&&temperature>=t_min)
	{
		led&=~0x02;
		pcf8591_write(3);
	}
	else
		led|=0x02;
	if(temperature<t_min)
	{
		led&=~0x04;
		pcf8591_write(2);
	}
	else
		led|=0x04;
}

void main(void)
{
	P2&=0x1F;
	Timer1Init();
	rd_temperature();
	pcf8591_write(5);
	while(1)
	{
		if(time1_10ms>=10)
		{
			key_scan();
			key_handle();
			mode_select();
			show_handle();
			time1_10ms=0;
		}
		if(time1_191ms>=191)
		{
			temperature=rd_temperature();
			pcfv=pcf8591_read(0)/0.51;
			
			time1_191ms=0;
		}
		
	}
}

void Timer1Serveice(void) interrupt 3
{
	led_output(led);
	buzzer_relay(buzzer_flag,relay_flag);
	dig_show();
	time1_10ms++;
    time1_191ms++;
}
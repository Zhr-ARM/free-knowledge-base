#include <stdio.h>

struct Rectangle 
{
    float length;
    float width;
};

//按地址传递结构体
void setDimensions(struct Rectangle *rect, float length, float width)
{
	rect->length = length;
	rect->width = width;
}

//计算面积
float calArea(struct Rectangle *rect)
{
	float area = rect->length * rect->width;
	
	rect->length *= 2;
	rect->width *= 2;
	
	return area;
}


int main()
{
	struct Rectangle myRect;
	
	//设置初始尺寸
	setDimensions(&myRect, 5.0, 3.0);
	printf("初始矩形尺寸：%.1f * %.1f\n", myRect.length, myRect.width);
	
	float area = calArea(&myRect);
	
	printf("初始面积：%.1f\n", area);
	printf("修改后的矩形尺寸：%.1f * %.1f\n", myRect.length, myRect.width);
	
    
    return 0;
}
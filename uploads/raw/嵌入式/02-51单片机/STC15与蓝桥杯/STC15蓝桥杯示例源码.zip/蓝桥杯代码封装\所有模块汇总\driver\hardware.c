#include "hardware.h"

void led_output(uint8_t value)
{
    P0 = value;
    P2 = P2 & 0x1f | 0x80;
    P2 &= 0x1f;
}

void relay_buzzer(uint8_t relay, uint8_t buzzer)
{
    P0 = 0X00;
    if (relay == ON)
        P0 |= 0x10; // ������λ��1(�ߵ�ƽ)���򿪼̵���
    else
        P0 &= ~0x10; // ������λ��0(�͵�ƽ)���رռ̵���
    if (buzzer == ON)
        P0 |= 0x40; // ������λ��1(�ߵ�ƽ)���򿪷�����
    else
        P0 &= ~0x40; // ������λ��0(�͵�ƽ)���رշ�����

    P2 = P2 & 0x1f | 0xA0;
    P2 &= 0x1f;
}

uint8_t key_value = 255;
uint8_t key_state = 255;
uint8_t C = 255;
uint8_t R = 255;
uint8_t code key_code[4][4] =
    {
        {7, 11, 15, 19},
        {6, 10, 14, 18},
        {5, 9, 13, 17},
        {4, 8, 12, 16},
};

void key_scan(void)
{
    P3 = 0x0f;
    P4 = 0x00;
    if (~P3 & 0x0f)
    {
        if (key_state < 255)
            key_state++;
        if (P30 == 0)
            R = 0;
        else if (P31 == 0)
            R = 1;
        else if (P32 == 0)
            R = 2;
        else if (P33 == 0)
            R = 3;
        P3 = 0xf0;
        P4 = 0xff;
        if (P44 == 0)
            C = 0;
        else if (P42 == 0)
            C = 1;
        else if (P35 == 0)
            C = 2;
        else if (P34 == 0)
            C = 3;
        key_value = key_code[R][C];
    }
    else
    {
        key_value = 0;
        key_state = 0;
        R = 255;
        C = 255;
    }
}

uint8_t code t_display[] = { // ��׼�ֿ�
    //   0    1    2    3    4    5    6    7    8    9    A    B    C    D    E    F
    0x3F, 0x06, 0x5B, 0x4F, 0x66, 0x6D, 0x7D, 0x07, 0x7F, 0x6F, 0x77, 0x7C, 0x39, 0x5E, 0x79, 0x71,
    // black  -     H    J    K    L    N    o   P    U     t    G    Q    r   M    y
    0x00, 0x40, 0x76, 0x1E, 0x70, 0x38, 0x37, 0x5C, 0x73, 0x3E, 0x78, 0x3d, 0x67, 0x50, 0x37, 0x6e,
    0xBF, 0x86, 0xDB, 0xCF, 0xE6, 0xED, 0xFD, 0x87, 0xFF, 0xEF, 0x46}; // 0. 1. 2. 3. 4. 5. 6. 7. 8. 9. -1

uint8_t code T_COM[] = {0x01, 0x02, 0x04, 0x08, 0x10, 0x20, 0x40, 0x80}; // λ��
uint8_t xdata dig_buf[6][8] = {
    {16, 16, 16, 16, 16, 16, 16, 16},
    {16, 16, 16, 16, 16, 16, 16, 16},
    {16, 16, 16, 16, 16, 16, 16, 16},
    {16, 16, 16, 16, 16, 16, 16, 16},
	{16, 16, 16, 16, 16, 16, 16, 16},
	{16, 16, 16, 16, 16, 16, 16, 16},
};
void dig_show(void)
{
    static uint8_t dig_com = 0;
    // ��Ӱ
    P0 = 0x00;
    P2 = P2 & 0x1f | 0xC0;
    P2 &= 0x1f;
    // ��ѡ
    P0 = ~t_display[dig_buf[mode][dig_com]];
    P2 = P2 & 0x1f | 0xE0;
    P2 &= 0x1f;
    // λѡ
    P0 = T_COM[dig_com];
    P2 = P2 & 0x1f | 0xC0;
    P2 &= 0x1f;
    if (++dig_com >= 8)
        dig_com = 0;
}
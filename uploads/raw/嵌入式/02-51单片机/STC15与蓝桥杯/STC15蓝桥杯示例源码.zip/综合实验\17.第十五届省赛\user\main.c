#include "main.h"
#include "hardware.h"
#include "ds1302.h"
#include "iic.h"

uint8_t xdata led=0xff;
uint8_t xdata relay_flag=OFF;
uint8_t xdata buzzer_flag=OFF;
uint32_t xdata pcfv=0;
uint32_t xdata pcfv_buf=0;
uint8_t xdata mode=0;

void Timer0_Init(void)		//1����@12.000MHz
{
	TMOD &= 0xF0;			//���ö�ʱ��ģʽ
	TMOD |= 0x05;
	TL0 = 0x00;				//���ö�ʱ��ʼֵ
	TH0 = 0x00;				//���ö�ʱ��ʼֵ
	TF0 = 0;				//���TF0��־
	TR0 = 1;				//��ʱ��0��ʼ��ʱ
}

long int freq=0;
long int freq_max=2000;
long int freq_delta=0;
uint8_t xdata cnt_freq=0;

void freq_detect(void)
{
	if(cnt_freq>=100)
	{
		TR0=0;
		freq=(long int)TH0<<8|TL0;
		freq=freq*10+freq_delta;
		if(freq<500&&freq>=0)
			pcfv_buf=51;
		else if(freq>=500&&freq<=freq_max)
			pcfv_buf=(uint8_t)(((204/(freq_max-500))*(freq-500))+51);
		else if(freq>freq_max)
			pcfv_buf=255;
		else if(freq<0)
			pcfv_buf=0;
		TL0 = 0x00;				
		TH0 = 0x00;	
		cnt_freq=0;
		TR0=1;
	}
}

uint8_t xdata time_10ms=0;
uint8_t xdata time_200ms=0;
void Timer1_Init(void)		//1����@12.000MHz
{
	AUXR |= 0x40;			//��ʱ��ʱ��1Tģʽ
	TMOD &= 0x0F;			//���ö�ʱ��ģʽ
	TL1 = 0x20;				//���ö�ʱ��ʼֵ
	TH1 = 0xD1;				//���ö�ʱ��ʼֵ
	TF1 = 0;				//���TF1��־
	TR1 = 1;				//��ʱ��1��ʼ��ʱ
	ET1 = 1;				//ʹ�ܶ�ʱ��1�ж�
	EA=1;
}

uint8_t xdata mode_flag=0;
uint8_t flag_handle=0;
uint8_t flag1_handle=0;

void mode_select(void)
{
	if(mode_flag==1)
	{
		if(flag_handle==0)	mode=MODE2;
		else 
		{
			if(freq_delta>0)	mode=MODE3;
			else if(freq_delta==0) mode=MODE5;
			else	mode=MODE4;
		}
	}
	else if(mode_flag==2)
	{
		if(flag1_handle==1)
			mode=MODE7;
		else
			mode=MODE8;
	}
	if(mode==MODE1)
	{
		if(freq>=0)
		{
			dig_buf[mode][0]=15;
			if(freq>=10000)
				dig_buf[mode][3]=freq/10000%10;
			else
				dig_buf[mode][3]=16;
			if(freq>=1000)
				dig_buf[mode][4]=freq/1000%10;
			else
				dig_buf[mode][4]=16;
			if(freq>=100)
				dig_buf[mode][5]=freq/100%10;
			else
				dig_buf[mode][5]=16;
			if(freq>=10)
				dig_buf[mode][6]=freq/10%10;
			else
				dig_buf[mode][6]=16;
			if(freq>0)
				dig_buf[mode][7]=freq%10;
			else
				dig_buf[mode][7]=16;
		}
		else if(freq<0)
			mode=MODE9;
	}
	else if(mode==MODE2)
	{
		dig_buf[mode][0]=24;
		dig_buf[mode][1]=1;
		dig_buf[mode][4]=freq_max/1000%10;
		dig_buf[mode][5]=freq_max/100%10;
		dig_buf[mode][6]=freq_max/10%10;
		dig_buf[mode][7]=freq_max%10;
	}
	else if(mode==MODE3)
	{
		dig_buf[mode][0]=24;
		dig_buf[mode][1]=2;
		
		dig_buf[mode][5]=freq_delta/100%10;
		dig_buf[mode][6]=freq_delta/10%10;
		dig_buf[mode][7]=freq_delta%10;
	}
	else if(mode==MODE4)
	{
		dig_buf[mode][0]=24;
		dig_buf[mode][1]=2;
		dig_buf[mode][4]=17;
		dig_buf[mode][5]=(-freq_delta)/100%10;
		dig_buf[mode][6]=(-freq_delta)/10%10;
		dig_buf[mode][7]=(-freq_delta)%10;
	}
	else if(mode==MODE5)
	{
		dig_buf[mode][0]=24;
		dig_buf[mode][1]=2;
		
		dig_buf[mode][5]=16;
		dig_buf[mode][6]=16;
		dig_buf[mode][7]=0;
	}
	else if(mode==MODE6)
	{
		dig_buf[mode][0]=ds1302_buf[0]/0x10;
		dig_buf[mode][1]=ds1302_buf[0]%0x10;
		dig_buf[mode][2]=17;
		dig_buf[mode][3]=ds1302_buf[1]/0x10;
		dig_buf[mode][4]=ds1302_buf[1]%0x10;
		dig_buf[mode][5]=17;
		dig_buf[mode][6]=ds1302_buf[2]/0x10;
		dig_buf[mode][7]=ds1302_buf[2]%0x10;
	}
	else if(mode==MODE7)
	{
		dig_buf[mode][0]=18;
		dig_buf[mode][1]=15;
		
		if(max>=10000)
			dig_buf[mode][3]=max/10000%10;
		else
			dig_buf[mode][3]=16;
		if(max>=1000)
			dig_buf[mode][4]=max/1000%10;
		else
			dig_buf[mode][4]=16;
		if(max>=100)
			dig_buf[mode][5]=max/100%10;
		else
			dig_buf[mode][5]=16;
		if(max>=10)
			dig_buf[mode][6]=max/10%10;
		else
			dig_buf[mode][6]=16;
		if(max>0)
			dig_buf[mode][7]=max%10;
		else
			dig_buf[mode][7]=16;
	}
	else if(mode==MODE8)
	{
		dig_buf[mode][0]=18;
		dig_buf[mode][1]=10;
		dig_buf[mode][2]=ds1302_temp[0]/0x10;
		dig_buf[mode][3]=ds1302_temp[0]%0x10;
		dig_buf[mode][4]=ds1302_temp[1]/0x10;
		dig_buf[mode][5]=ds1302_temp[1]%0x10;
		dig_buf[mode][6]=ds1302_temp[2]/0x10;
		dig_buf[mode][7]=ds1302_temp[2]%0x10;
	}
	else if(mode==MODE9)
	{
		dig_buf[mode][0]=15;
		dig_buf[mode][6]=21;
		dig_buf[mode][7]=21;
		if(freq>=0)
			mode=MODE1;
	}
}

void key_handle(void)
{
	if(key_value==4&&key_state==5)
	{
		if(mode==MODE1||mode==MODE9)
		{
			mode_flag=1;
			flag_handle=0;
		}
		else if(mode_flag==1)
		{
			mode=MODE6;
			mode_flag=0;
		}
		else if(mode==MODE6)
		{
			mode_flag=2;
			flag1_handle=1;
		}
		else if(mode_flag==2)
		{
			mode_flag=0;
			mode=MODE1;
		}
	}
	else if(key_value==5&&key_state==5)
	{
		if(mode_flag==1)
		{
			if(flag_handle==1)	flag_handle=0;
			else  flag_handle=1;
		}
		else if(mode_flag==2)
		{
			if(flag1_handle==1)	flag1_handle=0;
			else  flag1_handle=1;
		}
	}
	else if(key_value==8&&key_state==5)
	{
		if(mode==MODE2)
		{
			if(freq_max<=8000)
				freq_max+=1000;
			else
				freq_max=1000;
		}
		else if(mode>=2&&mode<=4)
		{
			if(freq_delta<900)	freq_delta+=100;
			else				freq_delta=-900;
		}
	}
	else if(key_value==9&&key_state==5)
	{
		if(mode==MODE2)
		{
			if(freq_max>1000)
				freq_max-=1000;
			else 
				freq_max=9000;
		}
		else if(mode>=2&&mode<=4)
		{
			if(freq_delta>-900)	freq_delta-=100;
			else				freq_delta=900;
		}
	}
}
bit led_flag=0;
uint8_t xdata led_time=0;
uint8_t xdata led_bline=0;
uint8_t xdata led2_bline=0;
bit led2_flag=0;
uint8_t xdata led2_time=0;
void led_handle(void)
{
	if(mode==MODE1||mode==MODE9)
	{
		led_flag=1;
		if(led_bline==0)
		{
			led|=0x01;
		}
		else
		{
			led&=~0x01;
		}
	}
	else
	{
		led_flag=0;
		led|=0x01;
	}
	if(freq>=freq_max)
	{
		led2_flag=1;
	}
	else
	{
		led2_flag=0;
	}
	if(mode==MODE9||(led2_bline==1&&led2_flag==1))
		led&=~0x02;
	else
		led|=0x02;
}
uint8_t xdata ds1302_temp[3];
long int max;
void huixian(void)
{
	if(max<freq)
	{
		ds1302_temp[0]=ds1302_buf[0];
		ds1302_temp[1]=ds1302_buf[1];
		ds1302_temp[2]=ds1302_buf[2];
		max=freq;
	}
}

void main(void)
{
	ds1302_write();
	Timer1_Init();
	Timer0_Init();
	
	while(1)
	{
		freq_detect();
		if(time_10ms>=10)
		{
			key_scan();
			key_handle();
			mode_select();
			ds1302_read();
			huixian();
			time_10ms=0;
		}
		if(time_200ms>=200)
		{
			pcf8591_write(pcfv_buf);
			
			pcfv=pcf8591_read(0)/0.51;
			
			time_200ms=0;
		}
		if(led_time>=200)
		{
			led_bline=~led_bline;
			led_time=0;
		}
		if(led2_time>=200)
		{
			if(led2_bline==1)
				led2_bline=0;
			else
				led2_bline=1;
			led2_time=0;
		}
	}
	
}

void Timer1_Isr(void) interrupt 3
{
	led_output(led);
	relay_buzzer(relay_flag,buzzer_flag);
	dig_show();
	cnt_freq++; 
	time_10ms++;
	time_200ms++;
	led_handle();
	if(led_flag==1)
		led_time++;
	else
		led_time=0;
	if(led2_flag==1)
		led2_time++;
	else
		led2_time=0;
}

#ifndef __WIFI_H__
#define __WIFI_H__

#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_mac.h"
#include "lcd.h"

void wifi_scan(void);

#endif
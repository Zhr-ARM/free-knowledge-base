/*	# 	DS1302代码片段说明
	1. 	本文件夹中提供的驱动代码供参赛选手完成程序设计参考。
	2. 	参赛选手可以自行编写相关代码或以该代码为基础，根据所选单片机类型、运行速度和试题
		中对单片机时钟频率的要求，进行代码调试和修改。
*/								
#include  "ds1302.h"

sbit SCK=P1^7;
sbit SDA=P2^3;
sbit RST=P1^3;
//
void Write_Ds1302(unsigned  char temp) 
{
	unsigned char i;
	for (i=0;i<8;i++)     	
	{ 
		SCK = 0;
		SDA = temp&0x01;
		temp>>=1; 
		SCK=1;
	}
}   

//
void Write_Ds1302_Byte( unsigned char address,unsigned char dat )     
{
 	RST=0;	_nop_();
 	SCK=0;	_nop_();
 	RST=1; 	_nop_();  
 	Write_Ds1302(address);	
 	Write_Ds1302(dat);		
 	RST=0; 
}

//
unsigned char Read_Ds1302_Byte ( unsigned char address )
{
 	unsigned char i,temp=0x00;
 	RST=0;	_nop_();
 	SCK=0;	_nop_();
 	RST=1;	_nop_();
 	Write_Ds1302(address);
 	for (i=0;i<8;i++) 	
 	{		
		SCK=0;
		temp>>=1;	
 		if(SDA)
 		temp|=0x80;	
 		SCK=1;
	} 
 	RST=0;	_nop_();
 	SCK=0;	_nop_();
	SCK=1;	_nop_();
	SDA=0;	_nop_();
	SDA=1;	_nop_();
	return (temp);			
}

uint8_t ds1302_buf[3]={0x23,0x59,0x55};

void ds1302_write(void)
{
	Write_Ds1302_Byte(0x8E,0x00);//取消写保护
	
	Write_Ds1302_Byte(0x84,ds1302_buf[0]);//写小时地址为0x84
	Write_Ds1302_Byte(0x82,ds1302_buf[1]);//写分钟地址为0x82
	Write_Ds1302_Byte(0x80,ds1302_buf[2]);//写秒地址为0x80
	
	Write_Ds1302_Byte(0x8E,0x80);//打开写保护
}

void ds1302_read(void)
{
	ds1302_buf[0]=Read_Ds1302_Byte(0x85);//读小时地址为0x85
	ds1302_buf[1]=Read_Ds1302_Byte(0x83);//读分钟地址为0x83
	ds1302_buf[2]=Read_Ds1302_Byte(0x81);//读秒地址为0x81
}

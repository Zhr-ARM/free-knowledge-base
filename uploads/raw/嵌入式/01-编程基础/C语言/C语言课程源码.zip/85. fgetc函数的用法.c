#include <stdio.h>

int main()
{
	FILE *fp;
	int ch;
	
	fp = fopen("example.txt", "r");
	if(fp == NULL)
	{
		printf("无法打开文件\n");
		return 1;
	}
	
	printf("文件内容（逐字符读取）：");
	
	while((ch = fgetc(fp)) != EOF)
	{
		putchar(ch);
	}
	
	fclose(fp);
    
    return 0;
}
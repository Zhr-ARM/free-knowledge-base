#include "motor.h"

void motora_backward(void)
{
	DL_GPIO_clearPins(GPIOA,DL_GPIO_PIN_29);
	DL_GPIO_setPins(GPIOA,DL_GPIO_PIN_28);
}

void motora_forward(void)
{
	DL_GPIO_clearPins(GPIOA,DL_GPIO_PIN_28);
	DL_GPIO_setPins(GPIOA,DL_GPIO_PIN_29);
}

void motorb_backward(void)
{
	DL_GPIO_clearPins(GPIOA,DL_GPIO_PIN_31);
	DL_GPIO_setPins(GPIOA,DL_GPIO_PIN_30);
}

void motorb_forward(void)
{
	DL_GPIO_clearPins(GPIOA,DL_GPIO_PIN_30);
	DL_GPIO_setPins(GPIOA,DL_GPIO_PIN_31);
}

void pwm_motorA(int16_t value)
{
	DL_TimerA_setCaptureCompareValue(motor_INST,value,GPIO_motor_C0_IDX);
}

void pwm_motorB(int16_t value)
{
	DL_TimerA_setCaptureCompareValue(motor_INST,value,GPIO_motor_C1_IDX);
}

int16_t myabs(int16_t x)
{
    return (x < 0) ? -x : x;
}

void motor_set(int16_t left_motor, int16_t right_motor)
{
   if(left_motor >0)
   {
    motora_forward();
    pwm_motorA(myabs(left_motor));
   }
   else if(left_motor < 0)
   {
    motora_backward();
    pwm_motorA(myabs(left_motor));
   }
   else
   {
    motora_forward();
    pwm_motorA(0);
   }
    if(right_motor >0)
    {
     motorb_forward();
     pwm_motorB(myabs(right_motor));
    }
    else if(right_motor < 0)
    {
     motorb_backward();
     pwm_motorB(myabs(right_motor));
    }
    else
    {
     motorb_forward();
     pwm_motorB(0);
    }
}


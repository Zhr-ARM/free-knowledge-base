#ifndef __MAIN_H__
#define __MAIN_H__

#include <STC15F2K60S2.H>
#include "intrins.h"
#include "stdio.h"

#define uint8_t unsigned char
#define uint32_t unsigned int

#define ON     1
#define OFF    0

#define temp_mode     0
#define at24_mode     1
#define pcf_mode      2
#define ds18b20_mode  3
#define uart_mode     4
#define dis_mode      5
extern uint8_t mode;

#endif















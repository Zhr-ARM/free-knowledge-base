#include <STC15F2K60S2.H>
#include "intrins.h"

sbit L1 = P0^0;
sbit L8 = P0^7;

void Delay(unsigned int t)
{
    while(t--);
    while(t--);
    while(t--);
}


void SelectHC573()
{
  P2 = (P2 & 0x1f) | 0x80;
    P2 &= 0x1f;
}

void Working()
{
    SelectHC573();
 L1 = 0;
 Delay(60000);
 L1 = 1;
 Delay(60000);
}

//================================

void Init_INTO()
{
    ITO = 1;
    EXO = 1;
    EA = 1;
}

void ServiceINTO() interrupt 0
{
    L8 = 0;
    Delay(60000);
    Delay(60000);
    Delay(60000);
    Delay(60000);
    Delay(60000);
    Delay(60000);
    L8 = 1;
}

//================================

void main()
{
 Init_INTO();
 while(1)
 {
   Working();
 }
}
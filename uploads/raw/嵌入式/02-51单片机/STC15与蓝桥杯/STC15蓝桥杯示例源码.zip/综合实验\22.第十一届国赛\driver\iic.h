#ifndef  __IIC_H__
#define  __IIC_H__

#include "main.h"
uint32_t pcfv_read(uint8_t channel);

#endif //
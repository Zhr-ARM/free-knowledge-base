/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * File Name          : freertos.c
 * Description        : Code for freertos applications
 ******************************************************************************
 * @attention
 *
 * Copyright (c) 2025 STMicroelectronics.
 * All rights reserved.
 *
 * This software is licensed under terms that can be found in the LICENSE file
 * in the root directory of this software component.
 * If no LICENSE file comes with this software, it is provided AS-IS.
 *
 ******************************************************************************
 */
/* USER CODE END Header */

/* Includes ------------------------------------------------------------------*/
#include "FreeRTOS.h"
#include "task.h"
#include "main.h"
#include "cmsis_os.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

#include "Oled.h"
#include "mpu6050.h"
#include "dht11.h"

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */

/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/
/* USER CODE BEGIN Variables */

/* I2C句柄声明 */
extern I2C_HandleTypeDef hi2c1;

/* MPU6050设备句柄 */
MPU6050_Handle_t hmpu;

/* MPU6050就绪标志 */
volatile uint8_t g_mpu_ready = 0;

/* DHT11设备句柄 */
DHT11_Handle_t hdht11;

/* 接口函数实现 */
static uint8_t MPU_Write(uint8_t devAddr, uint8_t reg, uint8_t data)
{
    return HAL_I2C_Mem_Write(&hi2c1, devAddr, reg, I2C_MEMADD_SIZE_8BIT, &data, 1, 1000) == HAL_OK ? 0 : 1;
}

static uint8_t MPU_Read(uint8_t devAddr, uint8_t reg, uint8_t *data, uint8_t len)
{
    return HAL_I2C_Mem_Read(&hi2c1, devAddr, reg, I2C_MEMADD_SIZE_8BIT, data, len, 1000) == HAL_OK ? 0 : 1;
}

static void MPU_Delay(uint32_t ms)
{
    osDelay(ms);
}

/* USER CODE END Variables */
/* Definitions for defaultTask */
osThreadId_t defaultTaskHandle;
const osThreadAttr_t defaultTask_attributes = {
  .name = "defaultTask",
  .stack_size = 128 * 4,
  .priority = (osPriority_t) osPriorityNormal,
};
/* Definitions for oled */
osThreadId_t oledHandle;
const osThreadAttr_t oled_attributes = {
  .name = "oled",
  .stack_size = 512 * 4,
  .priority = (osPriority_t) osPriorityRealtime,
};
/* Definitions for mpu6050 */
osThreadId_t mpu6050Handle;
const osThreadAttr_t mpu6050_attributes = {
  .name = "mpu6050",
  .stack_size = 512 * 4,
  .priority = (osPriority_t) osPriorityRealtime7,
};
/* Definitions for dht22 */
osThreadId_t dht22Handle;
const osThreadAttr_t dht22_attributes = {
  .name = "dht22",
  .stack_size = 512 * 4,
  .priority = (osPriority_t) osPriorityAboveNormal,
};
/* Definitions for angle_queue */
osMessageQueueId_t angle_queueHandle;
const osMessageQueueAttr_t angle_queue_attributes = {
  .name = "angle_queue"
};
/* Definitions for dht22_queue */
osMessageQueueId_t dht22_queueHandle;
const osMessageQueueAttr_t dht22_queue_attributes = {
  .name = "dht22_queue"
};
/* Definitions for dht22_humi_queue */
osMessageQueueId_t dht22_humi_queueHandle;
const osMessageQueueAttr_t dht22_humi_queue_attributes = {
  .name = "dht22_humi_queue"
};

/* Private function prototypes -----------------------------------------------*/
/* USER CODE BEGIN FunctionPrototypes */

/* USER CODE END FunctionPrototypes */

void StartDefaultTask(void *argument);
void data_show(void *argument);
void mpu6050_run(void *argument);
void DHT22_Run(void *argument);

void MX_FREERTOS_Init(void); /* (MISRA C 2004 rule 8.1) */

/* Hook prototypes */
void vApplicationMallocFailedHook(void);

/* USER CODE BEGIN 5 */
void vApplicationMallocFailedHook(void)
{
  /* vApplicationMallocFailedHook() will only be called if
  configUSE_MALLOC_FAILED_HOOK is set to 1 in FreeRTOSConfig.h. It is a hook
  function that will get called if a call to pvPortMalloc() fails.
  pvPortMalloc() is called internally by the kernel whenever a task, queue,
  timer or semaphore is created. It is also called by various parts of the
  demo application. If heap_1.c or heap_2.c are used, then the size of the
  heap available to pvPortMalloc() is defined by configTOTAL_HEAP_SIZE in
  FreeRTOSConfig.h, and the xPortGetFreeHeapSize() API function can be used
  to query the size of free heap space that remains (although it does not
  provide information on how the remaining heap might be fragmented). */
}
/* USER CODE END 5 */

/**
  * @brief  FreeRTOS initialization
  * @param  None
  * @retval None
  */
void MX_FREERTOS_Init(void) {
  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* USER CODE BEGIN RTOS_MUTEX */
  /* add mutexes, ... */
  /* USER CODE END RTOS_MUTEX */

  /* USER CODE BEGIN RTOS_SEMAPHORES */
  /* add semaphores, ... */
  /* USER CODE END RTOS_SEMAPHORES */

  /* USER CODE BEGIN RTOS_TIMERS */
  /* start timers, add new ones, ... */
  /* USER CODE END RTOS_TIMERS */

  /* Create the queue(s) */
  /* creation of angle_queue */
  angle_queueHandle = osMessageQueueNew (3, sizeof(MPU6050_EulerAngle_t), &angle_queue_attributes);

  /* creation of dht22_queue */
  dht22_queueHandle = osMessageQueueNew (3, sizeof(float), &dht22_queue_attributes);

  /* creation of dht22_humi_queue */
  dht22_humi_queueHandle = osMessageQueueNew (3, sizeof(float), &dht22_humi_queue_attributes);

  /* USER CODE BEGIN RTOS_QUEUES */
  /* add queues, ... */
  /* USER CODE END RTOS_QUEUES */

  /* Create the thread(s) */
  /* creation of defaultTask */
  defaultTaskHandle = osThreadNew(StartDefaultTask, NULL, &defaultTask_attributes);

  /* creation of oled */
  oledHandle = osThreadNew(data_show, NULL, &oled_attributes);

  /* creation of mpu6050 */
  mpu6050Handle = osThreadNew(mpu6050_run, NULL, &mpu6050_attributes);

  /* creation of dht22 */
  dht22Handle = osThreadNew(DHT22_Run, NULL, &dht22_attributes);

  /* USER CODE BEGIN RTOS_THREADS */
  /* add threads, ... */
  /* USER CODE END RTOS_THREADS */

  /* USER CODE BEGIN RTOS_EVENTS */
  /* add events, ... */
  /* USER CODE END RTOS_EVENTS */

}

/* USER CODE BEGIN Header_StartDefaultTask */
/**
 * @brief  Function implementing the defaultTask thread.
 * @param  argument: Not used
 * @retval None
 */
/* USER CODE END Header_StartDefaultTask */
void StartDefaultTask(void *argument)
{
  /* USER CODE BEGIN StartDefaultTask */
  
  /* Infinite loop */
  for (;;)
  {
    HAL_GPIO_TogglePin(GPIOC, GPIO_PIN_13);
    osDelay(250);
  }
  /* USER CODE END StartDefaultTask */
}

/* USER CODE BEGIN Header_data_show */
/**
 * @brief Function implementing the oled thread.
 * @param argument: Not used
 * @retval None
 */
/* USER CODE END Header_data_show */
void data_show(void *argument)
{
  /* USER CODE BEGIN data_show */
  OLED_Init();
  OLED_Clear();
  
  MPU6050_EulerAngle_t angle = {0};
  float temperature = 0.0f;
  float humidity = 0.0f;
  
  /* Infinite loop */
  for (;;)
  {
    uint8_t updated = 0;

    if (osMessageQueueGet(angle_queueHandle, &angle, NULL, 200) == osOK)
    {
      updated = 1;
    }

    if (osMessageQueueGet(dht22_queueHandle, &temperature, NULL, 200) == osOK)
    {
      updated = 1;
    }

    if (osMessageQueueGet(dht22_humi_queueHandle, &humidity, NULL, 200) == osOK)
    {
      updated = 1;
    }

    if (updated)
    {
      OLED_Printf(0, 0, OLED_FONT_6X12, "R:%+7.2f", angle.roll);
      OLED_Printf(0, 2, OLED_FONT_6X12, "P:%+7.2f", angle.pitch);
      OLED_Printf(0, 4, OLED_FONT_6X12, "Y:%+7.2f", angle.yaw);
      OLED_Printf(0, 6, OLED_FONT_6X12, "T:%6.1f H:%6.1f", temperature,humidity);
      
    }
  }
  /* USER CODE END data_show */
}

/* USER CODE BEGIN Header_mpu6050_run */
/**
 * @brief Function implementing the mpu6050 thread.
 * @param argument: Not used
 * @retval None
 */
/* USER CODE END Header_mpu6050_run */
void mpu6050_run(void *argument)
{
  /* USER CODE BEGIN mpu6050_run */
  MPU6050_EulerAngle_t angle;  /* 三轴姿态角度变量 */
  TickType_t xLastWakeTime;
  const TickType_t xPeriod = pdMS_TO_TICKS(10);  /* 10ms = 100Hz */
  
  /* 初始化MPU6050句柄 */
  hmpu.WriteReg = MPU_Write;
  hmpu.ReadReg = MPU_Read;
  hmpu.DelayMs = MPU_Delay;
  hmpu.devAddr = 0xD0;  /* AD0接地 */
  hmpu.mahonyKp = 0.1f; /* 滤波系数 */
  
  /* 初始化MPU6050 */
  MPU6050_Init(&hmpu);
  
  /* 延时等待传感器内部电路稳定，防止校准数据不准 */
  osDelay(500);

  /* 陀螺仪零偏校准 (确保传感器静止水平放置) */
  MPU6050_CalibrateGyro(&hmpu);
  
  /* 设置当前Yaw为零点 */
  MPU6050_SetYawZero(&hmpu);
  
  /* 获取当前时间 */
  xLastWakeTime = xTaskGetTickCount();
  
  for (;;)
  {
    /* 更新姿态解算，dt=5ms = 0.005s */
    MPU6050_UpdateAttitude(&hmpu, 0.01f);
    
    /* 获取欧拉角 */
    MPU6050_GetEulerAngles(&hmpu, &angle);
    
    /* Send to Queue (every 20th sample = 10Hz) */
    static uint8_t displayCnt = 0;
    if (++displayCnt >= 20)
    {
      displayCnt = 0;
      osMessageQueuePut(angle_queueHandle, &angle, 0, 0);
    }
    
    /* 精确定时，200Hz更新频率 */
    /**
     * @brief 使用“绝对时间”方式阻塞当前任务，保证任务以固定周期运行（无累积漂移）。
     *
     * @details
     * vTaskDelayUntil() 会根据上一次唤醒时刻 @p xLastWakeTime 与周期 @p xPeriod
     * 计算下一次应当唤醒的时间点，并将当前任务阻塞到该时间点。
     * 与 vTaskDelay() 的相对延时不同，该方式能在任务执行时间有抖动时仍保持稳定的周期节拍，
     * 避免每次“延时 + 执行耗时”导致的周期逐渐漂移。
     *
     * @param[in,out] xLastWakeTime
     *  指向上次唤醒时刻（Tick 计数）的变量指针。首次调用前通常应初始化为 xTaskGetTickCount()；
     *  函数内部会更新该值为本次计划的唤醒基准，用于下一次调用。
     *
     * @param[in] xPeriod
     *  周期（以 Tick 为单位）。例如：pdMS_TO_TICKS(10) 表示 10ms 周期（取决于 tick 频率）。
     *
     * @note
     *  适用于周期性任务主循环（如 while(1) 中）以实现稳定的周期调度。
     */
    vTaskDelayUntil(&xLastWakeTime, xPeriod);
  }
  /* USER CODE END mpu6050_run */
}

/* USER CODE BEGIN Header_DHT22_Run */
/**
* @brief Function implementing the dht22 thread.
* @param argument: Not used
* @retval None
*/
/* USER CODE END Header_DHT22_Run */
void DHT22_Run(void *argument)
{
  /* USER CODE BEGIN DHT22_Run */
  DHT11_Data_t dht11_data;
  uint8_t ret;
  osPriority_t old_priority;
  uint32_t error_count = 0;
  static uint8_t last_error = 0;

  hdht11.port = GPIOA;
  hdht11.pin = GPIO_PIN_1;

  DHT11_Init(&hdht11);

  for(;;)
  {
    old_priority = osThreadGetPriority(dht22Handle);
    osThreadSetPriority(dht22Handle, osPriorityRealtime7);

    ret = DHT11_ReadData(&hdht11, &dht11_data);

    osThreadSetPriority(dht22Handle, old_priority);

    if (ret == 0)
    {
      float temp = dht11_data.temperature_int + dht11_data.temperature_dec * 0.1f;
      float humi = dht11_data.humidity_int + dht11_data.humidity_dec * 0.1f;

      osMessageQueuePut(dht22_queueHandle, &temp, 0, 0);
      osMessageQueuePut(dht22_humi_queueHandle, &humi, 0, 0);
      
      error_count = 0;
      last_error = 0;
    }
    else
    {
      error_count++;
      last_error = ret;
      
      if (error_count > 5)
      {
        DHT11_Init(&hdht11);
        error_count = 0;
      }
    }

    osDelay(2000);
  }
  /* USER CODE END DHT22_Run */
}

/* Private application code --------------------------------------------------*/
/* USER CODE BEGIN Application */

/* USER CODE END Application */


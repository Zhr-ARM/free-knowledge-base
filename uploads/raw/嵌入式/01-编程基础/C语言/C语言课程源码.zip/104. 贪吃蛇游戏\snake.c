#include "snake.h"

//蛇头
struct Snake snake;

//蛇身
struct Body body[ROW * COL];		//开辟足以存储蛇身的结构体数组

//地图
int map[ROW][COL];		//标记游戏区各个位置的状态

int score = 0;		//分数
int direction = RIGHT;	//当前移动方向

//隐藏光标
void HideCursor()
{
	CONSOLE_CURSOR_INFO curInfo; //定义光标信息的结构体变量
	curInfo.dwSize = 1; //如果没赋值的话，光标隐藏无效
	curInfo.bVisible = FALSE; //将光标设置为不可见
	HANDLE handle = GetStdHandle(STD_OUTPUT_HANDLE); //获取控制台句柄
	SetConsoleCursorInfo(handle, &curInfo); //设置光标信息
}

//光标跳转
void CursorJump(int x, int y)
{
	COORD pos; //定义光标位置的结构体变量
	pos.X = x; //横坐标
	pos.Y = y; //纵坐标
	SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), pos); //设置光标位置
}

//颜色设置
void SetColor(int c)
{
	SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), c);
}

//初始化界面
void InitInterface()
{
	SetColor(COLOR_WHITE);
	for(int i = 0; i < ROW; i++)
	{
		for(int j = 0; j < COL; j++)
		{
			if(i == 0 || i == ROW - 1)
			{
				map[i][j] = WALL;
				printf("■");	//占用两个字符
			}
			else if(j == 0 || j == COL - 1)
			{
				map[i][j] = WALL;
				printf("■");	//占用两个字符
			}
			else
			{
				map[i][j] = EMPTY;
				printf("  ");	//占用两个字符
			}
		}
		printf("\n");
	}
	
	SetColor(COLOR_DEFAULT);
	printf("当前得分：%d\n", score);
	printf("操作说明：\n");
	printf("↑ ↓ ← →：移动蛇\n");
	printf("空格键：暂停游戏\n");
}

//初始化蛇
void InitSnake()
{
	//蛇头
	snake.len = 3;			//蛇长度初始化为3
	snake.headX = COL/2;	//蛇头初始化横坐标
	snake.headY = ROW/2;
	
	//蛇身
	body[0].bodyX = COL/2 - 1;	//第一节蛇身
	body[0].bodyY = ROW/2;
	body[1].bodyX = COL/2 - 2;	//第二节蛇身
	body[1].bodyY = ROW/2;
	
	map[snake.headY][snake.headX] = HEAD;		//在游戏区标记蛇头
	map[body[0].bodyY][body[0].bodyX] = BODY;	//在游戏区标记第一节蛇身
	map[body[1].bodyY][body[1].bodyX] = BODY;	//在游戏区标记第一节蛇身
}

//随机生成食物
void RandFood()
{
	int x, y;
	do
	{
		x = rand() % (COL - 2) + 1;	 	//列范围 1~COL-2
		y = rand() % (ROW - 2) + 1;		//行的范围1~ROW-2
	} while(map[y][x] != EMPTY);	//如果不为空就重新生成
	
	map[y][x] = FOOD;		//标记食物
	CursorJump(2 * x, y);
	SetColor(COLOR_RED);	//设置食物为红色
	printf("■");
	SetColor(COLOR_DEFAULT);
}

//打印蛇
void DrawSnake(int flag)
{
	if(flag == 1)	//打印蛇
	{
		CursorJump(2 * snake.headX, snake.headY);	//注意乘以2，因为■占用2个字符
		SetColor(COLOR_LIGHT_BLUE);		//设置蛇头颜色为淡蓝色
		printf("■");
		SetColor(COLOR_BLUE);			//设置蛇身颜色为蓝色
		for(int i = 0; i < snake.len - 1; i++)
		{
			CursorJump(2 * body[i].bodyX, body[i].bodyY);
			printf("■");
		}
		SetColor(COLOR_DEFAULT);
	}
	else 		//覆盖蛇
	{
		CursorJump(2 * body[snake.len - 2].bodyX, body[snake.len - 2].bodyY);
		printf("  ");
	}
	
}

//移动蛇
int MoveSnake(int x, int y)
{
	int ateFood = (map[snake.headY + y][snake.headX + x] == FOOD);	//检查即将移动到的位置是否有食物
	if(!ateFood)	//如果没有吃到食物，清除蛇尾
	{
		DrawSnake(0);		//先清除蛇尾
		map[body[snake.len - 2].bodyY][body[snake.len - 2].bodyX] = EMPTY;	//原蛇尾位置标记为空
	}
	else			//如果吃到食物，增加长度
	{
		snake.len++;
		score += 10;
	}
	
	//蛇身坐标变换
	for(int i = snake.len - 2; i > 0; i--)
	{
		body[i].bodyX =body[i - 1].bodyX;
		body[i].bodyY =body[i - 1].bodyY;
	}
	body[0].bodyX = snake.headX;	//蛇头变为蛇身
	body[0].bodyY = snake.headY;
	map[snake.headY][snake.headX] = BODY;	//原蛇头位置标记为蛇身
	
	//蛇头坐标变换
	snake.headX += x;
	snake.headY += y;
	map[snake.headY][snake.headX] = HEAD;	//新蛇头位置标记为蛇头
	
	if(ateFood)	//如果吃到了食物，则重新生成食物
	{
		RandFood();
	}
	
	return ateFood;
}

//判断是否撞墙或撞自己
int JudgeFunc(int x, int y)
{
	if(map[y][x] == WALL || map[y][x] == BODY)
		return 0;
		
	return 1;
}

//主逻辑
void PlayGame()
{
	int tmpKey = 0;		//记录按键
	
	while(1)
	{
		//检测按键
		if(kbhit())
		{
			tmpKey = getch();
			if(tmpKey == ARROW)		//方向键
			{
				tmpKey = getch();
				//更新方向
				if(tmpKey == UP && direction != DOWN)	direction = UP;
				else if(tmpKey == DOWN && direction != UP) direction = DOWN;
				else if(tmpKey == LEFT && direction != RIGHT) direction = LEFT;
				else if(tmpKey == RIGHT && direction != LEFT) direction = RIGHT;
			}
			else if(tmpKey == SPACE)	//空格键
			{
				system("pause>nul");
			}	
		}
		
		//执行移动
		int a = 0, b = 0;
		if(direction == UP)
		{
			a = 0;
			b = -1;
		}
		else if(direction == DOWN)
		{
			a = 0;
			b = 1;
		}
		else if(direction == LEFT)
		{
			a = -1;
			b = 0;
		}
		else if(direction == RIGHT)
		{
			a = 1;
			b = 0;
		}
		
		if(JudgeFunc(snake.headX + a, snake.headY + b))	//没有出界没有撞到自己
		{
			int ateFood = MoveSnake(a, b);
			DrawSnake(1);
			CursorJump(0, ROW);
			if(ateFood)
				printf("当前得分：%d", score);
		}
		else	//结束结束
		{
			//显示游戏结束信息
			CursorJump(16, 10);
			SetColor(COLOR_RED);
			printf("GAME OVER");
			SetColor(COLOR_DEFAULT);
			CursorJump(15, 11);
			printf("最终得分：%d", score);
			CursorJump(0, ROW + 1);		//光标移到安全位置
			return;
		}
		
		
		Sleep(150);		//控制游戏速度
	}
}

int main()
{
	HideCursor();
	InitInterface();
	InitSnake();
	DrawSnake(1);
	srand(time(NULL));	//设置随机数种子
	RandFood();
	PlayGame();
	while(1);
    return 0;
}
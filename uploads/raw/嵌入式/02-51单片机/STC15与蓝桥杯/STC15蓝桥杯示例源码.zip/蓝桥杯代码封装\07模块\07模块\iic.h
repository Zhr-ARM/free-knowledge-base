#ifndef __IIC_H_
#define __IIC_H_
#include "main.h"
sbit scl=P2^0;
sbit sda=P2^1;
unsigned int rd_pcf(unsigned char channel);
void wri_pcf(float v);

uchar rd_e2p(uchar addr);
void wri_e2p(unsigned char addr,uchar dat);
#endif
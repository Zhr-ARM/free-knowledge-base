#include <stdio.h>

struct Rectangle
{
	float length;
	float width;
};

//按值传递结构体
float calArea(struct Rectangle rect)
{
	//计算面积
	float area = rect.length * rect.width;
	
	//修改参数
	rect.length = 0;
	rect.width = 0;
	
	return area;
}

int main()
{
	struct Rectangle myRect = {5.0, 3.0};
	printf("矩形尺寸：%.1f * %.1f\n", myRect.length, myRect.width);
	
	float area = calArea(myRect);
	printf("面积：%.1f\n", area);
	printf("调用函数后矩形尺寸：%.1f * %.1f\n", myRect.length, myRect.width);
	
    
    return 0;
}
#ifndef __HARDWARE_H__
#define __HARDWARE_H__

#include "main.h"

void led_control(uint8_t value);
void beep_relay(uint8_t beep,uint8_t relay);
void dig_show(void);
void key_scan(void);

extern uint8_t xdata dig_buf[][8];
extern uint8_t xdata key_value;
extern uint8_t xdata key_state;

#endif
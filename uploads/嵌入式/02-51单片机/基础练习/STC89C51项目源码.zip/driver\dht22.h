#ifndef __DHT22_H__
#define __DHT22_H__

#include "main.h"

// ================= 配置区 =================
// 确认你的硬件接在哪里！这里设为 P2.7
#define DHT_PIN P2^7  
// =========================================

extern int DHT_Temperature;
extern int DHT_Humidity;

void DHT22_Init(void);
// 返回值：0=成功, 1=无响应, 2=数据0超时, 3=数据1超时, 4=校验错误
unsigned char DHT22_Read(void);

#endif
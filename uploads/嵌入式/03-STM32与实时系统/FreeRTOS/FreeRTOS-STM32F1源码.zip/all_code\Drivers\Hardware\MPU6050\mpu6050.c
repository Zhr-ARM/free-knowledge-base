/**
 * @file    mpu6050.c
 * @brief   MPU6050六轴传感器驱动源文件
 * @details 本文件实现了MPU6050的I2C通信、初始化配置、数据读取和转换等功能
 *          支持读取3轴加速度和3轴陀螺仪数据，并将原始ADC值转换为物理单位
 */

#include "mpu6050.h"
#include <math.h> 

/*============================================================================
 *                           宏定义常量
 *===========================================================================*/

/**
 * @brief MPU6050的I2C设备地址
 * @note  当AD0引脚接地(低电平)时，设备地址为0x68，左移1位后为0xD0
 *        当AD0引脚接VCC(高电平)时，设备地址为0x69，左移1位后为0xD2
 */
#define MPU6050_ADDR 0xD0

/**
 * @brief 陀螺仪量程配置值
 * @note  0x00 = ±250°/s,  灵敏度: 131 LSB/(°/s)
 *        0x08 = ±500°/s,  灵敏度: 65.5 LSB/(°/s)
 *        0x10 = ±1000°/s, 灵敏度: 32.8 LSB/(°/s)
 *        0x18 = ±2000°/s, 灵敏度: 16.4 LSB/(°/s)
 */
#define Gyro_Range 0x18

/**
 * @brief 加速度计量程配置值
 * @note  0x00 = ±2g,  灵敏度: 16384 LSB/g
 *        0x08 = ±4g,  灵敏度: 8192 LSB/g
 *        0x10 = ±8g,  灵敏度: 4096 LSB/g
 *        0x18 = ±16g, 灵敏度: 2048 LSB/g
 */
#define Accel_Range 0x18

/* 数学常量定义 */
#define PI 3.1415926535f          /* 圆周率π */
#define RtA 57.2957795f           /* 弧度转角度系数: 180/π */
#define AtR 0.0174532925f         /* 角度转弧度系数: π/180 */

/*============================================================================
 *                         I2C通信基础函数
 *===========================================================================*/

/**
 * @brief  向MPU6050指定寄存器写入一个字节数据
 * @param  dev: 设备句柄
 * @param  RegAddress: 目标寄存器地址
 * @param  Data: 要写入的数据
 */
static void MPU6050_WriteReg(MPU6050_Handle_t *dev, uint8_t RegAddress, uint8_t Data)
{
    if (dev && dev->WriteReg)
    {
        dev->WriteReg(dev->devAddr, RegAddress, Data);
    }
}



/*============================================================================
 *                         数据转换函数
 *===========================================================================*/

/**
 * @brief  将加速度计原始值转换为g单位
 * @param  value: 加速度计原始ADC值 (有符号16位整数)
 * @param  range: 加速度计量程配置寄存器值
 * @retval 加速度值 (单位: g, 重力加速度)
 */
float MPU6050_ConvertAccel(int16_t value, uint8_t range) 
{
    float factor; // 用于存储转换因子
    // 根据加速度计的量程选择合适的转换因子
    switch (range) {
        case 0x00: factor = 16384.0; break; // ±2g，转换因子为16384
        case 0x08: factor = 8192.0; break;  // ±4g，转换因子为8192
        case 0x10: factor = 4096.0; break;  // ±8g，转换因子为4096
        case 0x18: factor = 2048.0; break;  // ±16g，转换因子为2048
        default: factor = 16384.0; break;    // 默认量程范围为±2g
    }
    // 将原始加速度值转换为g单位
    return value / factor;
}

/**
 * @brief  将陀螺仪原始值转换为角速度
 * @param  value: 陀螺仪原始ADC值 (有符号16位整数)
 * @param  range: 陀螺仪量程配置寄存器值
 * @retval 角速度值 (单位: °/s, 度每秒)
 */
float MPU6050_ConvertGyro(int16_t value, uint8_t range) 
{
    float factor; // 用于存储转换因子
    // 根据陀螺仪的量程选择合适的转换因子
    switch (range) {
        case 0x00: factor = 131.0; break;  // ±250°/s，转换因子为131
        case 0x08: factor = 65.5; break;   // ±500°/s，转换因子为65.5
        case 0x10: factor = 32.8; break;   // ±1000°/s，转换因子为32.8
        case 0x18: factor = 16.4; break;   // ±2000°/s，转换因子为16.4
        default: factor = 131.0; break;     // 默认量程范围为±250°/s
    }
    // 将原始陀螺仪值转换为°/s单位
    return value / factor;
}

/*============================================================================
 *                         初始化函数
 *===========================================================================*/

/**
 * @brief  初始化MPU6050传感器
 * @param  dev: 设备句柄指针
 * @note   初始化步骤:
 *         1. 初始化运行时状态
 *         2. 复位设备并选择陀螺仪X轴PLL作为时钟源
 *         3. 使能3轴加速度计和3轴陀螺仪
 *         4. 设置采样率分频器
 *         5. 配置数字低通滤波器
 *         6. 配置陀螺仪和加速度计量程
 */
void MPU6050_Init(MPU6050_Handle_t *dev)
{
    if (!dev) return;

    /* 初始化运行时状态 */
    dev->q.q0 = 1.0f;
    dev->q.q1 = 0.0f;
    dev->q.q2 = 0.0f;
    dev->q.q3 = 0.0f;
    dev->yawAccumulated = 0.0f;
    dev->yawOffset = 0.0f;
    
    /* 默认参数配置 (如果用户未设置) */
    if (dev->mahonyKp == 0.0f) dev->mahonyKp = 0.1f;

	/* 复位设备，选用陀螺仪X轴PLL作为时钟源 (更精确稳定) */
	MPU6050_WriteReg(dev, MPU6050_PWR_MGMT_1, 0x80);  /* 先复位 */
	if (dev->DelayMs) dev->DelayMs(100);  /* 等待复位完成 */
	
	/* 唤醒设备，选择陀螺仪X轴PLL作为时钟源 */
	MPU6050_WriteReg(dev, MPU6050_PWR_MGMT_1, 0x01);
	
	/* 使能3轴加速度计和3轴陀螺仪，禁用待机模式 */
	MPU6050_WriteReg(dev, MPU6050_PWR_MGMT_2, 0x00);
	
	/* 设置采样率分频器为0，采样率 = 陀螺仪输出率/(1+SMPLRT_DIV) = 1kHz/1 = 1000Hz */
	MPU6050_WriteReg(dev, MPU6050_SMPLRT_DIV, 0x00);
	
	/* 设置数字低通滤波器(DLPF)，配置值0x03对应带宽42Hz，进一步降低噪声 */
	MPU6050_WriteReg(dev, MPU6050_CONFIG, 0x03);
	
	/* 配置陀螺仪满量程为±2000°/s (Gyro_Range = 0x18) */
	MPU6050_WriteReg(dev, MPU6050_GYRO_CONFIG, Gyro_Range);
	
	/* 配置加速度计满量程为±16g (Accel_Range = 0x18) */
	MPU6050_WriteReg(dev, MPU6050_ACCEL_CONFIG, Accel_Range);
	
	/* 延时50ms等待传感器稳定 */
	if (dev->DelayMs) dev->DelayMs(50);
}

/*============================================================================
 *                         综合数据读取函数
 *===========================================================================*/

/**
 * @brief  读取所有传感器数据并转换为物理单位
 * @param  dev: 设备句柄指针
 * @param  ax: X轴加速度指针 (单位: g)
 * @param  ay: Y轴加速度指针 (单位: g)
 * @param  az: Z轴加速度指针 (单位: g)
 * @param  gx: X轴角速度指针 (单位: °/s)
 * @param  gy: Y轴角速度指针 (单位: °/s)
 * @param  gz: Z轴角速度指针 (单位: °/s)
 */
void MPU6050_ReadSensors(MPU6050_Handle_t *dev, float *ax, float *ay, float *az, float *gx, float *gy, float *gz) 
{
    uint8_t buffer[14];
    int16_t raw_ax, raw_ay, raw_az;
    int16_t raw_gx, raw_gy, raw_gz;
 
    if (!dev || !dev->ReadReg) return;

    // 一次性读取14个字节：加速度(6) + 温度(2) + 陀螺仪(6)
    dev->ReadReg(dev->devAddr, MPU6050_ACCEL_XOUT_H, buffer, 14);
 
    // 解析加速度数据
    raw_ax = (buffer[0] << 8) | buffer[1];
    raw_ay = (buffer[2] << 8) | buffer[3];
    raw_az = (buffer[4] << 8) | buffer[5];
    
    // buffer[6]和buffer[7]是温度数据，此处忽略
    
    // 解析陀螺仪数据
    raw_gx = (buffer[8] << 8) | buffer[9];
    raw_gy = (buffer[10] << 8) | buffer[11];
    raw_gz = (buffer[12] << 8) | buffer[13];
 
    // 将加速度计的原始数据转换为浮点数形式（单位：g）
    *ax = MPU6050_ConvertAccel(raw_ax, Accel_Range); // 根据配置的量程转换
    *ay = MPU6050_ConvertAccel(raw_ay, Accel_Range);
    *az = MPU6050_ConvertAccel(raw_az, Accel_Range);
    
    // 将陀螺仪的原始数据转换为浮点数形式（单位：°/s）
    *gx = MPU6050_ConvertGyro(raw_gx, Gyro_Range); // 根据配置的量程转换
    *gy = MPU6050_ConvertGyro(raw_gy, Gyro_Range);
    *gz = MPU6050_ConvertGyro(raw_gz, Gyro_Range);
}

/*============================================================================
 *                         姿态解算相关变量
 *===========================================================================*/

/**
 * @brief 校准采样次数
 */
#define CALIBRATION_SAMPLES  2000

/*============================================================================
 *                         姿态解算辅助函数
 *===========================================================================*/

/**
 * @brief  快速平方根倒数算法 (Quake III算法)
 * @param  x: 输入值
 * @retval 1/sqrt(x) 的近似值
 * @note   比标准库sqrt快3-4倍，精度约99.8%
 */
static float invSqrt(float x)
{
    float halfx = 0.5f * x;
    float y = x;
    long i = *(long*)&y;
    i = 0x5f3759df - (i >> 1);
    y = *(float*)&i;
    y = y * (1.5f - (halfx * y * y));  /* 牛顿迭代一次 */
    y = y * (1.5f - (halfx * y * y));  /* 牛顿迭代两次，提高精度 */
    return y;
}

/*============================================================================
 *                         姿态解算核心函数
 *===========================================================================*/

/**
 * @brief  陀螺仪零偏校准
 * @param  dev: 设备句柄指针
 * @note   采集CALIBRATION_SAMPLES次数据，计算均值作为零偏
 *         校准期间请确保传感器静止水平放置
 */
void MPU6050_CalibrateGyro(MPU6050_Handle_t *dev)
{
    float ax, ay, az, gx, gy, gz;
    float sumGx = 0.0f, sumGy = 0.0f, sumGz = 0.0f;
    int i;
    
    if (!dev) return;

    /* 采集多次数据 */
    for (i = 0; i < CALIBRATION_SAMPLES; i++)
    {
        MPU6050_ReadSensors(dev, &ax, &ay, &az, &gx, &gy, &gz);
        sumGx += gx;
        sumGy += gy;
        sumGz += gz;
        if (dev->DelayMs) dev->DelayMs(2);  /* 2ms采样间隔 */
    }
    
    /* 计算零偏均值 */
    dev->gyroOffset.x = sumGx / CALIBRATION_SAMPLES;
    dev->gyroOffset.y = sumGy / CALIBRATION_SAMPLES;
    dev->gyroOffset.z = sumGz / CALIBRATION_SAMPLES;
    
    /* 使用加速度计初始化Roll和Pitch姿态 */
    MPU6050_ReadSensors(dev, &ax, &ay, &az, &gx, &gy, &gz);
    
    /* 从加速度计计算初始Roll和Pitch角度 */
    float roll0 = atan2f(ay, sqrtf(ax * ax + az * az));
    float pitch0 = atan2f(-ax, sqrtf(ay * ay + az * az));
    
    /* 从欧拉角转换为初始四元数 (Yaw=0) */
    float cr = cosf(roll0 * 0.5f);
    float sr = sinf(roll0 * 0.5f);
    float cp = cosf(pitch0 * 0.5f);
    float sp = sinf(pitch0 * 0.5f);
    
    dev->q.q0 = cr * cp;
    dev->q.q1 = sr * cp;
    dev->q.q2 = cr * sp;
    dev->q.q3 = -sr * sp;
    
    /* 重置Yaw偏移 */
    dev->yawOffset = 0.0f;
    dev->yawAccumulated = 0.0f;
}

/**
 * @brief  Mahony互补滤波姿态更新 (优化版)
 * @param  dev: 设备句柄指针
 * @param  dt: 采样周期 (秒)
 * @note   算法原理:
 *         1. 使用加速度计计算重力方向的参考向量
 *         2. 将参考向量与四元数估计的重力方向做叉乘得到误差
 *         3. 使用PI控制器修正陀螺仪数据
 *         4. 用修正后的角速度更新四元数
 *         5. 四元数归一化
 */
void MPU6050_UpdateAttitude(MPU6050_Handle_t *dev, float dt)
{
    float ax, ay, az, gx, gy, gz;
    float recipNorm;
    float vx, vy, vz;
    float ex, ey;
    float q0, q1, q2, q3;
    float dq0, dq1, dq2, dq3;
    
    if (!dev) return;

    /* 读取传感器数据 */
    MPU6050_ReadSensors(dev, &ax, &ay, &az, &gx, &gy, &gz);
    
    /* 减去零偏 (单位: °/s) */
    gx -= dev->gyroOffset.x;
    gy -= dev->gyroOffset.y;
    gz -= dev->gyroOffset.z;
    
    /* 死区处理 - 消除静止时的零漂 */
    if (fabsf(gx) < 0.2f) gx = 0.0f;
    if (fabsf(gy) < 0.2f) gy = 0.0f;
    if (fabsf(gz) < 0.5f) gz = 0.0f; /* 恢复合理的死区 */

    /* 独立积分Yaw轴 (单位: 弧度)，完全不受Roll/Pitch影响 */
    /* 注意：这里使用的是死区处理后、转弧度前的gz值(度/秒)，所以需要乘以AtR */
    dev->yawAccumulated += gz * AtR * dt;

    /* 角速度转换为弧度/秒 */
    gx *= AtR;
    gy *= AtR;
    gz *= AtR;
    
    /* 加速度计数据有效性检查 */
    recipNorm = ax * ax + ay * ay + az * az;
    
    /* 严格的运动检测策略：
       1. 加速度模长必须极度接近1g (0.95g ~ 1.05g)
       2. 角速度必须极小 (小于5°/s)，说明处于绝对静止状态
       只有同时满足这两个条件，才认为加速度计测量的是纯重力，才允许修正姿态 */
    if (recipNorm > 0.90f && recipNorm < 1.10f && (fabsf(gx) + fabsf(gy) + fabsf(gz)) < (5.0f * AtR))
    {
        /* 归一化加速度计测量值 */
        recipNorm = invSqrt(recipNorm);
        ax *= recipNorm;
        ay *= recipNorm;
        az *= recipNorm;
        
        /* 从四元数计算估计的重力方向 (机体坐标系下) */
        vx = 2.0f * (dev->q.q1 * dev->q.q3 - dev->q.q0 * dev->q.q2);
        vy = 2.0f * (dev->q.q0 * dev->q.q1 + dev->q.q2 * dev->q.q3);
        vz = dev->q.q0 * dev->q.q0 - dev->q.q1 * dev->q.q1 - dev->q.q2 * dev->q.q2 + dev->q.q3 * dev->q.q3;
        
        /* 叉乘得到误差向量 (加速度计测量 × 估计重力) */
        ex = ay * vz - az * vy;
        ey = az * vx - ax * vz;
        
        /* 应用PI修正到角速度 */
        gx += dev->mahonyKp * ex;
        gy += dev->mahonyKp * ey;
    }
    
    /* 保存当前四元数 */
    q0 = dev->q.q0;
    q1 = dev->q.q1;
    q2 = dev->q.q2;
    q3 = dev->q.q3;
    
    /* 四元数微分方程 (标准形式) */
    dq0 = 0.5f * (-q1 * gx - q2 * gy - q3 * gz);
    dq1 = 0.5f * ( q0 * gx + q2 * gz - q3 * gy);
    dq2 = 0.5f * ( q0 * gy - q1 * gz + q3 * gx);
    dq3 = 0.5f * ( q0 * gz + q1 * gy - q2 * gx);
    
    /* 一阶欧拉积分更新四元数 */
    dev->q.q0 += dq0 * dt;
    dev->q.q1 += dq1 * dt;
    dev->q.q2 += dq2 * dt;
    dev->q.q3 += dq3 * dt;
    
    /* 四元数归一化 */
    recipNorm = invSqrt(dev->q.q0 * dev->q.q0 + dev->q.q1 * dev->q.q1 + dev->q.q2 * dev->q.q2 + dev->q.q3 * dev->q.q3);
    dev->q.q0 *= recipNorm;
    dev->q.q1 *= recipNorm;
    dev->q.q2 *= recipNorm;
    dev->q.q3 *= recipNorm;
}

/**
 * @brief  获取欧拉角
 * @param  dev: 设备句柄指针
 * @param  euler: 欧拉角结构体指针
 * @note   从四元数转换为欧拉角 (ZYX旋转顺序)
 *         Roll:  绕X轴旋转 (-180° ~ +180°)
 *         Pitch: 绕Y轴旋转 (-90° ~ +90°)
 *         Yaw:   绕Z轴旋转 (-180° ~ +180°)
 */
void MPU6050_GetEulerAngles(MPU6050_Handle_t *dev, MPU6050_EulerAngle_t *euler)
{
    if (!dev) return;

    float q0q0 = dev->q.q0 * dev->q.q0;
    float q1q1 = dev->q.q1 * dev->q.q1;
    float q2q2 = dev->q.q2 * dev->q.q2;
    float q3q3 = dev->q.q3 * dev->q.q3;
    
    /* Roll (φ) - 绕X轴旋转 */
    euler->roll = atan2f(2.0f * (dev->q.q0 * dev->q.q1 + dev->q.q2 * dev->q.q3), 
                         q0q0 - q1q1 - q2q2 + q3q3) * RtA;
    
    /* Pitch (θ) - 绕Y轴旋转，需要限幅防止asin越界 */
    float sinPitch = 2.0f * (dev->q.q0 * dev->q.q2 - dev->q.q1 * dev->q.q3);
    if (sinPitch > 1.0f) sinPitch = 1.0f;
    if (sinPitch < -1.0f) sinPitch = -1.0f;
    euler->pitch = asinf(sinPitch) * RtA;
    
    /* Yaw (ψ) - 使用独立积分的Yaw值，彻底解耦 */
    euler->yaw = dev->yawAccumulated * RtA - dev->yawOffset;
    
    /* 将Yaw角限制在 -180° ~ +180° 范围内 */
    while (euler->yaw > 180.0f) euler->yaw -= 360.0f;
    while (euler->yaw < -180.0f) euler->yaw += 360.0f;
}

/**
 * @brief  重置姿态解算器
 * @param  dev: 设备句柄指针
 * @note   将四元数重置为初始状态，清除积分误差
 */
void MPU6050_ResetAttitude(MPU6050_Handle_t *dev)
{
    if (!dev) return;

    /* 重置四元数为单位四元数 */
    dev->q.q0 = 1.0f;
    dev->q.q1 = 0.0f;
    dev->q.q2 = 0.0f;
    dev->q.q3 = 0.0f;
    
    /* 清除Yaw偏移和累积值 */
    dev->yawOffset = 0.0f;
    dev->yawAccumulated = 0.0f;
}

/**
 * @brief  设置Yaw轴零点
 * @param  dev: 设备句柄指针
 * @note   将当前Yaw角度设为零点参考
 *         调用此函数后，当前朝向即为Yaw=0°
 */
void MPU6050_SetYawZero(MPU6050_Handle_t *dev)
{
    if (!dev) return;
    /* 设置当前累积角度为零点偏移 */
    dev->yawOffset = dev->yawAccumulated * RtA;
}

#include <stdio.h>

//变量一定要先定义再使用

int global_int;	//全局变量自动初始化为0

int main(void)
{
	//定义一个变量
	int age;
	int x, y, z;	//同时定义多个变量
	int count = 30;	//定义并初始化变量
	//相当于：
	//int count;
	//count = 30;
	float a = 1.0f, b = 2.0f, c = 3.0f;	//多个变量同时初始化
	float A;
	int return;
	
	//为变量赋值
	age = 25;
	x = 10;
	x = 11;
	x = 12;
	y = 20;
	y = age;
	z = 30;
	z = x + y;
	
	
	//输出变量的值
	printf("年龄：%d\n", age);
	printf("x = %d, y = %d, z = %d\n", x, y, z);
	printf("学生数量：%d\n", count);
	printf("a = %f, b = %f, c = %f\n", a, b, c);
	printf("globale_int = %d\n", global_int);
    
    return 0;
}
#ifndef __I2C_H__
#define __I2C_H__

#include "main.h"

void pcf8591_write(uint8_t v);
uint32_t pcf8591_read(uint8_t addr);

#endif
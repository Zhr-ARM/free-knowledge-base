#include "main.h"
#include "hardware.h"
#include "ds1302.h"
#include "onewire.h"
#include "iic.h"

extern uint8_t key_value;
extern uint8_t key_state;
extern uint8_t dig_buf[][8];
extern uint8_t ds1302_buf[3];
uint8_t mode=0;
uint8_t time10ms=0;
uint8_t time200ms=0;
uint8_t led=0xff;
uint8_t led_number=4;
uint8_t led_temp=4;
uint32_t temp=0;
uint32_t pcfv=0;
uint8_t light_flag=0;
uint8_t time=17;
uint32_t time_temp=17;
uint32_t temp_flag=25;
uint8_t temp_buf=25;
uint8_t key_flag=0;
uint32_t light_time=0;
uint32_t light_time1=0;

void Timer1_Isr(void) interrupt 3
{
    time10ms++;
    time200ms++;
    dig_show();
    led_handle(led);
    if(light_flag==0)
        light_time++;
    else
        light_time=0;
    if(light_flag==1)
        light_time1++;
    else
        light_time1=0;
}

void Timer1_Init(void)		//1毫秒@12.000MHz
{
	AUXR |= 0x40;			//定时器时钟1T模式
	TMOD &= 0x0F;			//设置定时器模式
	TL1 = 0x20;				//设置定时初始值
	TH1 = 0xD1;				//设置定时初始值
	TF1 = 0;				//清除TF1标志
	TR1 = 1;				//定时器1开始计时
	ET1 = 1;				//使能定时器1中断
    EA=1;
}

void key_handle(void)
{
    if(key_value==4&&key_state==5)
    {
        if(key_flag==0)
        {
            key_flag=1;
            mode=TIME_CONFIG;
        }
        else
        {
           key_flag=0;
           mode=TIME;
           led_number=led_temp;
           temp=temp_buf;
           time=time_temp;
        }
    }
    else if(key_value==5&&key_state==5)
    {
        if(key_flag==0)
        {
            if(mode==TIME)
                mode=TEMP;
            else if (mode==TEMP)
            {
                mode=LIGHT;
            }
            else if(mode==LIGHT)
            {
                mode=TIME;
            }
        }
        else if(key_flag==1)
        {
            if(mode==TIME_CONFIG)
                mode=TEMP_CONFIG;
            else if (mode==TEMP_CONFIG)
            {
                mode=LED_CONFIG;
            }
            else if(mode==LED_CONFIG)
            {
                mode=TIME_CONFIG;
            }
        }
    }
    else if(key_value==8&&key_state==5)
    {
        if(key_flag==1&&mode==TIME_CONFIG)
        {
            if(time_temp>0)
                time_temp--;
            else
                time_temp=23;
        }
        else if(key_flag==1&&mode==TEMP_CONFIG)
        {
            temp_buf--;
        }
        else if(key_flag==1&&mode==LED_CONFIG)
        {
            if(led_temp>4)
                led_temp--;
            else
                led_temp=8;
        }
    }
    else if(key_value==9&&key_state==5)
    {
        if(key_flag==1&&mode==TIME_CONFIG)
        {
            if(time_temp<23)
            time_temp++;
            else
            time_temp=0;
        }
        else if(key_flag==1&&mode==TEMP_CONFIG)
        {
            temp_buf++;
        }
        else if(key_flag==1&&mode==LED_CONFIG)
        {
            if(led_temp<8)
                led_temp++;
            else
                led_temp=4;
        }
    }
}

void dig_handle(void)
{
    if(mode==TIME)
    {
        dig_buf[mode][0]=ds1302_buf[0]/0x10;
        dig_buf[mode][1]=ds1302_buf[0]%0x10;
        dig_buf[mode][2]=17;
        dig_buf[mode][3]=ds1302_buf[1]/0x10;
        dig_buf[mode][4]=ds1302_buf[1]%0x10;
        dig_buf[mode][5]=17;
        dig_buf[mode][6]=ds1302_buf[2]/0x10;
        dig_buf[mode][7]=ds1302_buf[2]%0x10;
    }
    else if(mode==TEMP)
    {
        dig_buf[mode][0]=15;
        dig_buf[mode][1]=16;
        dig_buf[mode][2]=16;
        dig_buf[mode][3]=16;
        dig_buf[mode][4]=16;
        dig_buf[mode][5]=temp/1000%10;
        dig_buf[mode][6]=temp/100%10+32;
        dig_buf[mode][7]=temp/10%10;
    }
    else if(mode==LIGHT)
    {
        dig_buf[mode][0]=18;
        dig_buf[mode][1]=16;
        dig_buf[mode][2]=pcfv/100%10+32;
        dig_buf[mode][3]=pcfv/10%10;
        dig_buf[mode][4]=pcfv%10;
        dig_buf[mode][5]=16;
        dig_buf[mode][6]=16;
        dig_buf[mode][7]=light_flag;
    }
    else if(mode==TIME_CONFIG)
    {
        dig_buf[mode][0]=21;
        dig_buf[mode][1]=1;
        if(time>=10)
        {
            dig_buf[mode][6]=time_temp/10%10;
            dig_buf[mode][7]=time_temp%10;
        }
        else
        {
            dig_buf[mode][6]=0;
            dig_buf[mode][7]=time_temp;
        }
    }
    else if(mode==TEMP_CONFIG)
    {
        dig_buf[mode][0]=21;
        dig_buf[mode][1]=2;
        dig_buf[mode][6]=temp_buf/10%10;
        dig_buf[mode][7]=temp_buf%10;
    }
    else if(mode==LED_CONFIG)
    {
        dig_buf[mode][0]=21;
        dig_buf[mode][1]=3;
        dig_buf[mode][7]=led_temp;
    }
}
uint8_t time_now;
uint8_t time_flag=0;
void led_cotrol(void)
{
    time_now=((ds1302_buf[0]/0x10)*10+ds1302_buf[0]%0x10);
    if(time_now>=time)
        time_flag=1;
    if(time_now<8&&time_flag==1)
        time_flag=2;
    if(time_flag==2)
        led&=~0x01;
    else
        led|=0x01;
    if(temp<(temp_flag*100))
        led&=~0x02;
    else
        led|=0x02;
    if(light_time>=3000)
        led&=~0x04;
    else if(light_time1>=3000)
        led|=0x04;
    if(led_number==4)
        led&=~0x08;
    else
        led|=0x08;
    
    if(led_number==5)
        led&=~0x10;
    else
        led|=0x10;
    if(led_number==6)
        led&=~0x20;
    else
        led|=0x20;
    if(led_number==7)
        led&=~0x40;
    else
        led|=0x40;
    if(led_number==8)
        led&=~0x80;
    else
        led|=0x80;
}

void main(void)
{
    P2&=0x1F;
    beep_relay_init();
    Timer1_Init();
    ds1302_write();
    while(1)
    {
        if(time10ms>=10)
        {
            time10ms=0;
            key_scan();
            key_handle();
        }
        if(time200ms>=200)
        {
            time200ms=0;
            temp=rd_temperature();
            pcfv=pcfv_read(1)/0.51+0.5;
            led_cotrol();
            if(pcfv<=150)
                light_flag=0;
            else
                light_flag=1;
            ds1302_read();
            dig_handle();
        }
    }
}



#include "main.h"
#include "hardware.h"
#include "iic.h"
#include "onewire.h"
#include "string.h"
#include "stdio.h"

uint8_t xdata led=0xff;
uint8_t xdata relay_flag=OFF;
uint8_t xdata buzzer_flag=OFF;
uint8_t xdata mode=0;
uint32_t xdata pcfv=0;
uint32_t xdata temp=0;
uint8_t xdata at_buf_tx[2]={30,35};
uint8_t xdata  temp_max=30;
uint8_t xdata  dis_max=35;

void Delay5ms(void)	//@12.000MHz
{
	unsigned char data i, j;

	i = 59;
	j = 90;
	do
	{
		while (--j);
	} while (--i);
}


void Delay13us(void)	//@12.000MHz
{
	unsigned char data i;

	_nop_();
	_nop_();
	i = 36;
	while (--i);
}


uint8_t xdata time_10ms=0;
uint8_t xdata time_200ms=0;
void Timer1_Init(void)		//1����@12.000MHz
{
	AUXR |= 0x40;			//��ʱ��ʱ��1Tģʽ
	TMOD &= 0x0F;			//���ö�ʱ��ģʽ
	TL1 = 0x20;				//���ö�ʱ��ʼֵ
	TH1 = 0xD1;				//���ö�ʱ��ʼֵ
	TF1 = 0;				//���TF1��־
	TR1 = 1;				//��ʱ��1��ʼ��ʱ
	ET1 = 1;				//ʹ�ܶ�ʱ��1�ж�
	
	EA=1;
}
sbit TX=P1^0;
sbit RX=P1^1;
uint8_t xdata cnt_dis=0;
uint32_t xdata distance=0;
uint32_t xdata time_us=0;
bit dis_flag=0;

void pca_init(void)
{
	P_SW1&=0XCF;
	CCON=0;
	CMOD=0X01;
	CCAPM0=0X10;
}

void rd_dis(void)
{
	uint8_t i=8;
	CF=CCF0=0;
	CH=CL=0;
	CCAP0L=CCAP0H=0;
	CCAPM0|=0X01;
	CR=1;
	EA=0;
	while(i--)
	{
		TX=1;
		Delay13us();
		TX=0;
		Delay13us();
	}
	EA=1;
	if(dis_flag==0)
	{
		distance=time_us*0.017+0.5;
		dis_flag=0;
	}
	else if(dis_flag==1)
	{
		distance=999;
		dis_flag=0;
	}
}
uint8_t xdata uart_rx_buf[10]={0};
uint8_t xdata uart_tx_buf[10]={0};
uint8_t xdata uart_index=0;
bit uart_flag=0;
void SendByte(uint8_t dat)
{
	SBUF=dat;
	while(TI==0);
	TI=0;
}

void SendString(uint8_t *value)
{
	while(*value!='\0')
	{
		SendByte(*value++);
	}
	uart_index=0;
	memset(uart_rx_buf,0,sizeof(uart_rx_buf));
}

void Uart1_Isr(void) interrupt 4
{
	if (RI)				//��⴮��1�����ж�
	{
		if(SBUF!='\n')
			uart_rx_buf[uart_index++]=SBUF;
		else
		{
			uart_rx_buf[uart_index++]=SBUF;
			uart_flag=1	;
		}
		RI = 0;			//�������1�����ж�����λ
	}
}

void Uart1_Init(void)	//4800bps@12.000MHz
{
	SCON = 0x50;		//8λ����,�ɱ䲨����
	AUXR |= 0x01;		//����1ѡ��ʱ��2Ϊ�����ʷ�����
	AUXR |= 0x04;		//��ʱ��ʱ��1Tģʽ
	T2L = 0x8F;			//���ö�ʱ��ʼֵ
	T2H = 0xFD;			//���ö�ʱ��ʼֵ
	AUXR |= 0x10;		//��ʱ��2��ʼ��ʱ
	ES = 1;				//ʹ�ܴ���1�ж�
	EA = 1;
}

uint32_t xdata key_time=0;
bit key_flag=0;
bit mode_flag=0;
uint8_t xdata last_key_value=0;
uint8_t xdata  flag=0;
uint8_t xdata  flag_time=0;
uint8_t xdata  pcfv_flag=0;
uint8_t xdata  last_dis_max=35;
uint8_t xdata  last_temp_max=30;
void key_handle(void)
{
	if(key_value==13)
	{
		last_key_value=key_value;
		key_flag=1;
	}
	if(key_value==12)
	{
		last_key_value=key_value;
		key_flag=1;
	}
	if(key_flag==1&&last_key_value!=key_value)
	{
		if(last_key_value==12)
		{
			if(key_time<500)
			{
				if(flag==0)//������ʾ
				{
					if(++mode==3)
						mode=0;
				}
				else
				{
					if(mode_flag==1)
						mode_flag=0;
					else
						mode_flag=1;
				}
			}
			else if(key_time>=1000)
			{
				flag_time=0;
				
				at_buf_tx[0]=temp_max;
				at_buf_tx[1]=dis_max;
				at24c02_write(at_buf_tx,0x00,2);
			}
		}
		else if(last_key_value==13)
		{
			if(key_time<500)
			{
				if(flag==0)//������ʾ
				{
					flag=1;//������ʾ
					mode=MODE4;
					mode_flag=1;//�¶Ȳ���
				}
				else
				{
					flag=0;
					mode=MODE1;
					if(last_temp_max!=temp_max||last_dis_max!=dis_max)
					{
						at_buf_tx[0]=temp_max;
						at_buf_tx[1]=dis_max;
						last_temp_max=temp_max;
						last_dis_max=dis_max;
						flag_time++;
						at24c02_write(at_buf_tx,0x00,2);
					}
				}
			}
			else if(key_time>=1000)
			{
				if(pcfv_flag==0)
					pcfv_flag=1;
				else
					pcfv_flag=0;
			}
		}
		key_time=0;
		key_flag=0;
	}
	if(key_value==16&&key_state==5)
	{
		if(mode==MODE4&&mode_flag==1)
		{
			if(temp_max>=2)
				temp_max=temp_max-2;
			else
				temp_max=99;
		}
		else if(mode==MODE4&&mode_flag==0)
		{
			if(dis_max>=5)
				dis_max=dis_max-5;
			else
				dis_max=99;
		}

	}
	if(key_value==17&&key_state==5)
	{
		if(mode==MODE4&&mode_flag==1)
		{
			if(temp_max<=97)
				temp_max=temp_max+2;
			else
				temp_max=0;
		}
		else if(mode==MODE4&&mode_flag==0)
		{
			if(dis_max<=94)
				dis_max=dis_max+5;
			else
				dis_max=0;
		}
	}
}

void mode_select(void)
{
	if(mode==MODE1)
	{
		dig_buf[mode][0]=15;
		dig_buf[mode][4]=temp/1000%10;
		dig_buf[mode][5]=temp/100%10+32;
		dig_buf[mode][6]=temp/10%10;
		dig_buf[mode][7]=temp%10;
	}
	else if(mode==MODE2)
	{
		dig_buf[mode][0]=21;
		dig_buf[mode][6]=distance/10%10;
		dig_buf[mode][7]=distance%10;
	}
	else if(mode==MODE3)
	{
		dig_buf[mode][0]=28;
		if(flag_time>=10000)
			dig_buf[mode][3]=flag_time/10000%10;
		else
			dig_buf[mode][3]=16;
		if(flag_time>=1000)
			dig_buf[mode][4]=flag_time/1000%10;
		else
			dig_buf[mode][4]=16;
		if(flag_time>=100)
			dig_buf[mode][5]=flag_time/100%10;
		else
			dig_buf[mode][5]=16;
		if(flag_time>=10)
			dig_buf[mode][6]=flag_time/10%10;
		else
			dig_buf[mode][6]=16;
		if(flag_time>=0)
			dig_buf[mode][7]=flag_time%10;
		else
			dig_buf[mode][7]=16;
	}
	else if(mode==MODE4)
	{
		if(mode_flag==1)
		{
			dig_buf[mode][0]=24;
			dig_buf[mode][3]=1;
			dig_buf[mode][6]=temp_max/10%10;
			dig_buf[mode][7]=temp_max%10;
		}
		else if(mode_flag==0)
		{
			dig_buf[mode][0]=24;
			dig_buf[mode][3]=2;
			dig_buf[mode][6]=dis_max/10%10;
			dig_buf[mode][7]=dis_max%10;
		}
	}
}

void led_handle(void)
{
	if(temp>(temp_max*100))
		led&=~0x01;
	else
		led|=0x01;
	if(distance<dis_max)
		led&=~0x02;
	else
		led|=0x02;
	if(pcfv_flag==1)
		led&=~0x04;
	else
		led|=0x04;
}

void main(void)
{
	at24c02_write(at_buf_tx,0x00,2);
	Delay5ms();
	temp_max=at24c02_read(0x00);
	dis_max=at24c02_read(0x01);
	P2&=0x1F;
	rd_temperature();
	pca_init();
	Timer1_Init();
	Uart1_Init();
	SendString("Hello world");
	while(1)
	{
		if(time_10ms>=10)
		{
			key_scan();
			key_handle();
			mode_select();
			led_handle();
			time_10ms=0;
		}
		if(time_200ms>=200)
		{
			if(pcfv_flag==1)
			{
				if(distance>dis_max)
					pcf8591_write(204);
				else
					pcf8591_write(102);
			}
			else
				pcf8591_write(20);
			temp=rd_temperature();
			time_200ms=0;
		}
		if(cnt_dis>=200)
		{
			rd_dis();
			cnt_dis=0;
		}
		if(uart_flag==1)
		{
			if(strcmp(uart_rx_buf,"ST\r\n")==0&&uart_index != 0)
			{
				memset(uart_tx_buf,0,sizeof(uart_tx_buf));
				sprintf(uart_tx_buf,"$%d,%.2f\r\n",distance,(float)(temp/100.0));
				SendString(uart_tx_buf);
			}
			else if(strcmp(uart_rx_buf,"PARA\r\n")==0&&uart_index != 0)
			{
				memset(uart_tx_buf,0,sizeof(uart_tx_buf));
				sprintf(uart_tx_buf,"#%d,%d\r\n",(int)dis_max,(int)temp_max);
				SendString(uart_tx_buf);
			}
			else
				SendString("ERROR\r\n");
			uart_flag=0;
		}
	}
}

void Timer1_Isr(void) interrupt 3
{
	led_output(led);
	relay_buzzer(relay_flag,buzzer_flag);
	dig_show();
	time_10ms++;
	time_200ms++;
	cnt_dis++;
	if(key_flag==1)
	{
		key_time++;
	}
	else
		key_time=0;
}

void pca_ire(void) interrupt 7
{
	CCAPM0&=~0X01;
	CR=0;
	if(CF)
	{
		CF=0;
		dis_flag=1;
	}
	else if(CCF0)
	{
		CCF0=0;
		dis_flag=0;
		time_us=(int)(CCAP0H<<8|CCAP0L);
	}
	
}
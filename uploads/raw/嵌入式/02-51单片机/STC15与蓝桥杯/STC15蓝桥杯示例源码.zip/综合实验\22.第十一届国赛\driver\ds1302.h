#ifndef __DS1302_H__
#define __DS1302_H__

#include "main.h"

void ds1302_write(void);
void ds1302_read(void);

#endif // 
#ifndef __HARDWARE_H__
#define __HARDWARE_H__

#include <STC15F2K60S2.H>
void Timer1Init(void);
extern unsigned char led_buf;
extern unsigned int timer1s;
extern unsigned char code t_display[];
extern unsigned char code T_COM[];
extern unsigned char dig_buf[8];
void led_output();
void dig_output();
#endif
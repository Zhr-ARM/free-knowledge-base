#ifndef __KEY_H__
#define __KEY_H__

#include <stdio.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/gpio.h"

/* 引脚定义 */
#define BOOT_GPIO_PIN   GPIO_NUM_0   /* BOOT按键引脚 */

/* IO操作 */
#define BOOT      gpio_get_level(BOOT_GPIO_PIN)

/*按键按下定义*/
#define BOOT_PRES  1 /* BOOT按键按下 */

/* 函数声明 */
void key_init(void);    /* 按键初始化 */
uint8_t key_scan(uint8_t mode); /* 按键扫描 */

#endif /* __KEY_H__ */
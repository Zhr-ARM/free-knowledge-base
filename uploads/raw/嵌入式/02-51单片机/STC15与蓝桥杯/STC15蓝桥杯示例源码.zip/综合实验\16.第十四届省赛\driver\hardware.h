#ifndef __HARDWARE_H__
#define __HARDWARE_H__

#include "main.h"
void led_output(uint8_t value);
void relay_buzzer(uint8_t relay_flag,uint8_t buzzer_flag);
void key_scan(void);
void dig_show(void);

extern uint8_t xdata dig_buf[6][8];
extern uint8_t xdata key_state;
extern uint8_t xdata key_value;

#endif
#ifndef __SMG_H__
#define  __SMG_H__

extern unsigned char dig_buf[8];
void dig_show(void);

#endif
#ifndef __HARDWARE_H__
#define __HARDWARE_H__

#include "main.h"

void beep_relay(uint8_t beep_data,uint8_t relay_data);
void led_control(uint8_t dat);
void dig_show(void);
void key_scan(void);

extern uint8_t xdata dig_buf[7][8];
extern uint8_t xdata key_state;
extern uint8_t xdata key_value;
#endif
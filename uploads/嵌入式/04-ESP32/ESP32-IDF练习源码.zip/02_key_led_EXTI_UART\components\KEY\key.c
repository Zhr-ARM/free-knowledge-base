#include "key.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

void key_init(void)
{
    gpio_config_t gpio_init_struct;

    gpio_init_struct.intr_type = GPIO_INTR_DISABLE;
    gpio_init_struct.mode = GPIO_MODE_INPUT;
    gpio_init_struct.pull_up_en = GPIO_PULLUP_ENABLE;
    gpio_init_struct.pull_down_en = GPIO_PULLDOWN_DISABLE;
    gpio_init_struct.pin_bit_mask = 1ull << BOOT_GPIO_PIN;
    gpio_config(&gpio_init_struct);
}

uint8_t key_scan(uint8_t mode)
{
    uint8_t keyval = 0;
    static uint8_t key_boot = 1;

    if (mode)
    {
        key_boot = 1;
    }
    if (key_boot && (BOOT == 0))
    {
        vTaskDelay(10);
        key_boot = 0;
        if (BOOT == 0)
        {
            keyval = BOOT_PRES;
        }
    }
    else if (BOOT == 1)
    {
        key_boot = 1;
    }

    return keyval;
}
/*不使用外部中断则复制下面函数到main.c中进行按键检测*/
// key = key_scan(0); /* 获取键值 */
// switch (key)
// {
// case BOOT_PRES: /* BOOT 被按下 */
// {
//     LED_TOGGLE(); /* LED 状态翻转 */
//     break;
// }
// default:
// {
//     break;
// }
// }
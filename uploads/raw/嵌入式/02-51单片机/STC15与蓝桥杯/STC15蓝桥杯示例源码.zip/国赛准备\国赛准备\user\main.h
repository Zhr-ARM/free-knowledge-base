#ifndef __MAIN_H__
#define __MAIN_H__

#include <STC15F2K60S2.H>
#include "intrins.h"
#include "string.h"

#define uint8_t unsigned char
#define uint32_t unsigned int

#define ON  1
#define OFF 0

#define TIME_READ  0
#define TEMP_READ  1
#define PCFV_READ  2
#define AT_READ    3
#define FREQ_READ  4
#define DIS_READ   5
#define UART_RECV  6

void Delay14us(void);
void SendByte(uint8_t dat);
void SendString(uint8_t *dat);

extern uint8_t xdata mode;

#endif
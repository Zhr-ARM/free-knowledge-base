#ifndef __DS1302_H__
#define __DS1302_H__

#include "main.h"

extern uint8_t xdata ds1302_buf[3];
void ds1302_read(void);
void ds1302_write(void);

#endif 
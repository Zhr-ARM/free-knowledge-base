#ifndef __ONEWIRE_H__
#define __ONEWIRE_H__
#include "stdint.h"
uint32_t rd_tempereture(void);
#endif
#include <stdio.h>
#include <string.h>

int main()
{
    char source[] = "Hello World";
    char dest[10];
    
    strncpy(dest, source, 3);
    dest[sizeof(dest) - 1] = '\0';
    
    printf("源字符串：%s\n", source);
    printf("目标字符串：%s\n", dest);
    
    return 0;
}
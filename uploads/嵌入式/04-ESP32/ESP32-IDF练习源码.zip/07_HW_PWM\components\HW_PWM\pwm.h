#ifndef __PWM_H__
#define __PWM_H__

#include "driver/ledc.h"

/* 引脚以及重要参数定义 */
#define LEDC_PWM_TIMER    LEDC_TIMER_0
#define LEDC_PWM_MODE     LEDC_LOW_SPEED_MODE  /* 模式设定必须使用LEDC低速模式 */
#define LEDC_PWM_CH0_GPIO   GPIO_NUM_1         /* LED控制器通道对应GPIO */
#define LEDC_PWM_CH0_CHANNEL LEDC_CHANNEL_0     /* LED控制器通道 */
#define LEDC_PWM_DUTY       8000                /*渐变的变大最终目标占空比*/
#define LEDC_PWM_FADE_TIME  1000                /* 变化时长 */

/* 函数声明 */
void pwm_init(uint8_t resolution, uint16_t frequency); /* 初始化PWM */
void pwm_set_duty(uint32_t duty);                      /* 设置PWM占空比 */

#endif
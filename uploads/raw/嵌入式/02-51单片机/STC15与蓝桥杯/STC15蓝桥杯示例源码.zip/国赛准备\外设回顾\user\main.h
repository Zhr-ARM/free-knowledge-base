#ifndef __MAIN_H__
#define __MAIN_H__

#include <STC15F2K60S2.H>
#include "intrins.h"
#include <stdio.h>
#include "string.h"

#define uint8_t unsigned char
#define uint32_t unsigned int

#define ON 1
#define OFF 0 

#define TIME        0
#define TEMPERATURE 1
#define PCFV        2
#define AT24        3
#define NE555       4
#define DIS         5

extern uint8_t mode;
void Delay14us(void);

#endif
#include <stdio.h>

struct Student
{
	char name[50];
	int id;
	float score;	
};

int main()
{
	struct Student students1[5];		//定义了一个包含5个Student结构体的数组
	
	struct Student students2[3] = {
		{"张三", 1001, 85.5},
		{"李四", 1002, 92.0},
		{"王五", 1003, 78.5},
	};
	
	struct Student students3[3] = {
		[0] = {.name = "张三", .id = 1001, .score = 85.5},
		[1] = {.name = "李四", .id = 1002, .score = 92.0},
		[2] = {.name = "王五", .id = 1003, .score = 78.5},
	};
	
	//访问第一个学生的姓名
	printf("第一个学生：%s\n", students2[0].name);
	
	//修改第二个学生的成绩
	students2[1].score = 95.0;
	printf("第二个学生成绩：%.1f\n", students2[1].score);
	
	//遍历数组，打印所有学生的信息
	for(int i = 0; i < 3; i++)
	{
		printf("学生%d: %s, 学号：%d, 成绩: %.1f\n",
				i+1, students2[i].name, students2[i].id, students2[i].score);
	}
    
    return 0;
}
#include "dht22.h"
#include <intrins.h>

sbit DHT_IO = DHT_PIN;

int DHT_Temperature = 0;
int DHT_Humidity = 0;

// 毫秒延时
void DHT_DelayMs(unsigned int ms) {
    unsigned int i, j;
    for (i = ms; i > 0; i--)
        for (j = 90; j > 0; j--);
}

void DHT22_Init(void) {
    DHT_IO = 1;
    DHT_DelayMs(1000);
}

unsigned char DHT22_Read(void) {
    unsigned char i, idx;
    unsigned char U8comdata;
    unsigned char Data[5] = {0};
    unsigned char check_sum;
    
    // 计数器，使用 char 类型让循环跑得更快
    unsigned char count = 0;

    // 关中断！防止中断打断敏感时序
    bit EA_SAVE = EA;
    EA = 0;

    // --- 1. 主机发送起始信号 ---
    DHT_IO = 0;
    DHT_DelayMs(20); // 拉低 >18ms
    DHT_IO = 1;
    
    // 延时 30us 等待
    _nop_(); _nop_(); _nop_(); _nop_(); 
    _nop_(); _nop_(); _nop_(); _nop_();

    // --- 2. 握手阶段 (防死机) ---
    // 每一个 while 里面都加了简单的防死机计数 (count)
    // 250次循环对于 8MHz 来说大约是 1-2ms，足够了
    
    // 等待变低 (响应开始)
    count = 0;
    while (DHT_IO) { if (++count > 250) { EA = EA_SAVE; return 1; } }
    
    // 等待变高 (响应结束)
    count = 0;
    while (!DHT_IO) { if (++count > 250) { EA = EA_SAVE; return 1; } }

    // 等待变低 (准备传输)
    count = 0;
    while (DHT_IO) { if (++count > 250) { EA = EA_SAVE; return 1; } }

    // --- 3. 读取 40 位数据 ---
    for (idx = 0; idx < 5; idx++) {
        U8comdata = 0;
        for (i = 0; i < 8; i++) {
            
            // 1. 等待上一位低电平结束 (也就是等待位开始)
            // 正常应该是 50us
            count = 0;
            while (!DHT_IO) {
                // 如果这里超时，说明传感器不发数据了
                if (++count > 250) { EA = EA_SAVE; return 2; } 
            }

            // 2. 核心：测量高电平长度
            // 0: 26us
            // 1: 70us
            // 我们通过数循环次数来判断
            count = 0;
            while (DHT_IO) {
                count++;
                // 30是安全上限，防止卡死
                if (count > 30) { EA = EA_SAVE; return 3; } 
            }

            // 3. 判定逻辑 (针对 8MHz 调校)
            // 在 8MHz 下，C语言的 while 循环跑一圈很慢 (约10-12us)
            // '0' (26us) -> count 大约是 2
            // '1' (70us) -> count 大约是 6-7
            // 所以我们把阈值设为 4
            
            U8comdata <<= 1;
            if (count > 4) {
                U8comdata |= 1;
            }
        }
        Data[idx] = U8comdata;
    }

    // 恢复中断
    EA = EA_SAVE;
    DHT_IO = 1;

    // --- 4. 校验 ---
    check_sum = Data[0] + Data[1] + Data[2] + Data[3];
    
    // 为了方便调试，如果校验错，我们依然把读到的值放进去，
    // 这样你能在屏幕上看到一个“奇怪”的数值，而不是 Err 4
    // 这一步在正式产品中不要，但现在调试很有用！
    
    DHT_Humidity = (Data[0] << 8) | Data[1];
    DHT_Temperature = ((Data[2] & 0x7F) << 8) | Data[3];
    if (Data[2] & 0x80) DHT_Temperature = -DHT_Temperature;

    if (check_sum == Data[4]) {
        return 0; // 成功
    } else {
        // 如果校验失败，返回 4
        // 但此时全局变量里已经有值了，你可以看看是多少，帮我判断阈值
        return 4; 
    }
}
#ifndef __DHT11_H__
#define __DHT11_H__

#ifdef __cplusplus
extern "C" {
#endif

#include "main.h"
#include <stdint.h>

/*============================================================================
 *                         类型定义
 *===========================================================================*/

/**
 * @brief DHT11温湿度数据结构体
 */
typedef struct
{
    uint8_t humidity_int;    /* 湿度整数部分 (0-100%) */
    uint8_t humidity_dec;    /* 湿度小数部分 (0-9) */
    uint8_t temperature_int; /* 温度整数部分 (0-50℃) */
    uint8_t temperature_dec; /* 温度小数部分 (0-9) */
} DHT11_Data_t;

/**
 * @brief DHT11设备句柄结构体
 */
typedef struct
{
    GPIO_TypeDef *port;     /* GPIO端口 */
    uint16_t pin;           /* GPIO引脚 */
} DHT11_Handle_t;

/*============================================================================
 *                         宏定义常量
 *===========================================================================*/

/* 超时时间定义 */
#define DHT11_TIMEOUT_US         100000  /* 总超时时间 100ms */
#define DHT11_START_LOW_US       20000   /* 起始信号低电平 20ms */
#define DHT11_START_HIGH_US     30      /* 起始信号高电平 30us */
#define DHT11_RESPONSE_LOW_US   80      /* 响应信号低电平 80us */
#define DHT11_RESPONSE_HIGH_US  80      /* 响应信号高电平 80us */
#define DHT11_BIT_0_LOW_US      50      /* 数据0低电平 50us */
#define DHT11_BIT_0_HIGH_US     26      /* 数据0高电平 26us */
#define DHT11_BIT_1_LOW_US      50      /* 数据1低电平 50us */
#define DHT11_BIT_1_HIGH_US     70      /* 数据1高电平 70us */

/* 等待超时时间定义 */
#define DHT11_WAIT_TIMEOUT_US    150     /* 等待电平变化的超时时间 150us */
#define DHT11_PULSE_TIMEOUT_US   150     /* 测量高电平脉宽的超时时间 150us */

/* 判定阈值 */
#define DHT11_BIT_THRESHOLD_US  40      /* 判定0/1的阈值 */

/*============================================================================
 *                         函数声明
 *===========================================================================*/

/**
 * @brief  初始化DHT11传感器
 * @param  dev: 设备句柄指针
 * @retval 0: 成功, 非0: 失败
 */
uint8_t DHT11_Init(DHT11_Handle_t *dev);

/**
 * @brief  读取DHT11温湿度数据
 * @param  dev: 设备句柄指针
 * @param  data: 温湿度数据结构体指针
 * @retval 0: 成功, 非0: 失败
 */
uint8_t DHT11_ReadData(DHT11_Handle_t *dev, DHT11_Data_t *data);

#ifdef __cplusplus
}
#endif

#endif

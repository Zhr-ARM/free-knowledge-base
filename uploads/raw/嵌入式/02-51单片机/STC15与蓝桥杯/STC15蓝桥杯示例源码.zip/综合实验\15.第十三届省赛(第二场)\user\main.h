#ifndef __MAIN_H__
#define __MAIN_H__

#include <STC15F2K60S2.H>
#include "intrins.h"

#define ON  1
#define OFF 0

#define uint8_t unsigned char
#define uint32_t unsigned int
	
#define MODE1 0
#define MODE2 1
#define MODE3 2

extern uint8_t xdata mode;

#endif
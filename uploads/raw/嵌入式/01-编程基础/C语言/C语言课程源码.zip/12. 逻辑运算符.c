#include <stdio.h>

int main()
{
    int height = 100;			//一米八大长腿
    int money = 1000;		//一个小目标
    int handsome = 10;			//明星颜值
    
    int marry = (height > 170) || (money > 10000) || (handsome > 80);
    printf("是否可以结婚：%d\n", !marry);	//看走眼了
    
    return 0;
}
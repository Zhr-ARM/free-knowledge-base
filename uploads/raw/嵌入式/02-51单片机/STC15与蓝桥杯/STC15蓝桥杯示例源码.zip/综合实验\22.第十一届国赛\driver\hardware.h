#ifndef __HARDWARE_H__
#define __HARDWARE_H__

#include "main.h"

void led_handle(uint8_t value);
void beep_relay_init(void);
void dig_show(void);
void key_scan(void);


#endif
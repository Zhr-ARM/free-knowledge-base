#include "step.h"
#include <math.h>
/*
�������ÿ�յ�һ������ת��0.1125�ȣ�������Ϊ0.1125��
*/

//�������ƺ���
void Step1_set(int16_t value,int16_t speed)
{
	while(value--)
	{
		DL_GPIO_clearPins(STEP_STP1_PORT,STEP_STP1_PIN);
		delay_us(401-speed);
		DL_GPIO_setPins(STEP_STP1_PORT,STEP_STP1_PIN);
		delay_us(401-speed);
	}
}
void Step2_set(int16_t value,int16_t speed)
{
	while(value--)
	{
		DL_GPIO_clearPins(STEP_STP2_PORT,STEP_STP2_PIN);
		delay_us(401-speed);
		DL_GPIO_setPins(STEP_STP2_PORT,STEP_STP2_PIN);
		delay_us(401-speed);
	}
}
//������ƺ���(���Ʋ����ͷ���)
void Step1_turn(int16_t value,int16_t speed)
{
	DL_GPIO_setPins(STEP_EN1_PORT,STEP_EN1_PIN);
	if(value>=0)
	{
		Step1_set(value,speed);
		DL_GPIO_clearPins(STEP_DIR1_PORT,STEP_DIR1_PIN);
	}
	else
	{
		value=-value;
		Step1_set(value,speed);
		DL_GPIO_setPins(STEP_DIR1_PORT,STEP_DIR1_PIN);
	}
	DL_GPIO_clearPins(STEP_EN1_PORT,STEP_EN1_PIN);
}


void Step2_turn(int16_t value,int16_t speed)
{
	DL_GPIO_setPins(STEP_EN2_PORT,STEP_EN2_PIN);
	if(value>=0)
	{
		Step2_set(value,speed);
		DL_GPIO_clearPins(STEP_DIR2_PORT,STEP_DIR2_PIN);
	}
	else
	{
		value=-value;
		Step2_set(value,speed);
		DL_GPIO_setPins(STEP_DIR2_PORT,STEP_DIR2_PIN);
	}
	DL_GPIO_clearPins(STEP_EN2_PORT,STEP_EN2_PIN);
}
#include "system.h"
#include "uart.h"
#include "lcd.h"
#include "OpenMVrec.h"
#include "motor.h"
#include "step.h"
#include "encoder.h"
#include "string.h"
#include <stdio.h>
#include "follow.h"
#include "pid.h"

static uint8_t  fac_us=0;		// us��ʱ������			   
static uint16_t fac_ms=0;		// ms��ʱ������,��os��,����ÿ�����ĵ�ms��

extern void xPortSysTickHandler();
static int8_t system_createTasks(void);
static int8_t system_createQueues(void);

uint8_t N=0;

void system_init(void)
{
	// Systick���ã�1ms����жϣ�����rtos����
	DL_SYSTICK_init(CPUCLK_FREQ/1000);
    DL_SYSTICK_enableInterrupt();
    NVIC_SetPriority(SysTick_IRQn, 2);
	// ��ʱ��������
	fac_us = CPUCLK_FREQ / 1000000;
	
	// ����rtos�߳�
	if(system_createTasks() != 0) {
        // ���񴴽�ʧ�ܵĴ���
    }
	if(system_createQueues() != 0)
	{
		// ��Ϣ���д���ʧ�ܵĴ���
	}
}

TaskHandle_t led_task_handle = NULL;
TaskHandle_t uart_task_handle = NULL;
TaskHandle_t openmv_task_handle = NULL;
TaskHandle_t lcd_task_handle = NULL;
TaskHandle_t motor_task_handle = NULL;
TaskHandle_t step_task_handle = NULL;
TaskHandle_t detect_task_handle = NULL;
TaskHandle_t key_task_handle = NULL;

static int8_t system_createTasks(void)
{
    int8_t status = 0; // ���񴴽�״̬
    // ����LED����
    status |= xTaskCreate(led_task, "led_task", LED_TASK_STACK_SIZE, NULL, LED_TASK_PRIORITY, NULL);
	status |= xTaskCreate(lcd_task,"lcd_task",LCD_TASK_STACK_SIZE, NULL , LCD_TASK_PRIORITY, NULL);
	status |= xTaskCreate(motor_task,"motor_task",MOTOR_TASK_STACK_SIZE, NULL,MOTOR_TASK_PRIORITY, NULL);
	status |= xTaskCreate(detect_task,"detect_task",DETECT_TASK_STACK_SIZE, NULL,DETECT_TASK_PRIORITY, NULL);
	status |= xTaskCreate(key_task,"key_task",KEY_TASK_STACK_SIZE,NULL,KEY_TASK_PRIORITY, NULL);
    return status; // �������񴴽�״̬
}

// ����ȫ�ֶ��о��
QueueHandle_t motoraQueue = NULL;
QueueHandle_t motorbQueue = NULL;
QueueHandle_t aresultQueue = NULL;
QueueHandle_t bresultQueue = NULL;

static int8_t system_createQueues(void)
{
	int8_t status = 0;  // ���д���״̬
	
	motoraQueue = xQueueCreate(10, sizeof(int16_t));
	if (motoraQueue == NULL) status |= 0x02;  // bit 1 ��ʾ motoraQueue ����ʧ��
	
	motorbQueue = xQueueCreate(10, sizeof(int16_t));
	if (motorbQueue == NULL) status |= 0x02;  // bit 1 ��ʾ motorbQueue ����ʧ��
	
	aresultQueue = xQueueCreate(10,sizeof(int16_t));
	if (aresultQueue == NULL) status |= 0x02;  // bit 1 ��ʾ aresultQueue ����ʧ��
	
	bresultQueue = xQueueCreate(10,sizeof(int16_t));
	if (bresultQueue == NULL) status |= 0x02;  // bit 1 ��ʾ bresultQueue ����ʧ��
	
    return status;  // 0 ��ʾ�ɹ�����0��ʾĳЩ���д���ʧ��
}


void SysTick_Handler(void)
{	
    if(xTaskGetSchedulerState()!=taskSCHEDULER_NOT_STARTED)//ϵͳ�Ѿ�����
    {
        xPortSysTickHandler();	
    }
}

void delay_us(uint32_t nus)
{		
    uint32_t ticks;
    uint32_t told, tnow, tcnt=0;
    uint32_t reload = SysTick->LOAD;     // ��ȡ��װ��ֵ
    ticks = nus * fac_us;                // ������Ҫ�Ľ�����
    told = SysTick->VAL;                 // ��¼��ǰ����ֵ
    
    while(1) {
        tnow = SysTick->VAL;             // ���ϻ�ȡ�µļ���ֵ
        if(tnow != told) {               // ����ֵ�б仯ʱ
            if(tnow < told)              // �����ݼ�
                tcnt += told - tnow;
            else                         // ������������
                tcnt += reload - tnow + told;
                
            told = tnow;                 // ���¾�ֵ
            if(tcnt >= ticks) break;     // �ﵽҪ�����ʱʱ��
        }  
    }									    
}

void led_task(void *pvParameters)
{
	while(1)
	{
		DL_GPIO_clearPins(GPIOB,DL_GPIO_PIN_22);
		vTaskDelay(1000);
		DL_GPIO_setPins(GPIOB,DL_GPIO_PIN_22);
		vTaskDelay(1000);
	}
}
uint8_t angle_flag=0;
int16_t aresult=0;
int16_t bresult=0;
int16_t tempa=0;
int16_t tempb=0;
int16_t speeda=0;
int16_t speedb=0;
int16_t delta_speed=0;
int16_t n_time_buf=0;
int16_t n_time=0;
uint16_t detect_time=0;
volatile uint8_t t_flag=0;
void lcd_task(void *pvParameters)
{
	LCD_Init();
	LCD_Fill(0,0,LCD_W,LCD_H,WHITE);
	while(1)
	{
		if(tempa>=0)
		{
			LCD_ShowString(0,0,(uint8_t *)"motora  ",RED,WHITE,32,0);
			LCD_ShowIntNum(120,0,tempa,3,RED,WHITE,32);
		}
		else
		{
			LCD_ShowIntNum(120,0,(-tempa),3,RED,WHITE,32);
			LCD_ShowString(0,0,(uint8_t *)"motora -",RED,WHITE,32,0);
		}
		if(tempb>=0)
		{
			LCD_ShowString(0,32,(uint8_t *)"motorb  ",RED,WHITE,32,0);
			LCD_ShowIntNum(120,32,tempb,3,RED,WHITE,32);
		}
		else
		{
			LCD_ShowIntNum(120,32,(-tempb),3,RED,WHITE,32);
			LCD_ShowString(0,32,(uint8_t *)"motorb -",RED,WHITE,32,0);
		}
		LCD_ShowString(0,96,(uint8_t *)"A_RESULT: ",RED,WHITE,32,0);
		LCD_ShowString(0,128,(uint8_t *)"B_RESULT: ",RED,WHITE,32,0);
		LCD_ShowIntNum(144,96,aresult,3,RED,WHITE,32);
		LCD_ShowIntNum(144,128,bresult,3,RED,WHITE,32);
		LCD_ShowIntNum(0,160,detect[0],1,BLACK,WHITE,24);
		LCD_ShowIntNum(24,160,detect[1],1,BLACK,WHITE,24);
		LCD_ShowIntNum(48,160,detect[2],1,BLACK,WHITE,24);
		LCD_ShowIntNum(72,160,detect[3],1,BLACK,WHITE,24);
		LCD_ShowIntNum(96,160,detect[4],1,BLACK,WHITE,24);
		LCD_ShowIntNum(120,160,detect[5],1,BLACK,WHITE,24);
		LCD_ShowIntNum(144,160,detect[6],1,BLACK,WHITE,24);
		LCD_ShowIntNum(168,160,detect[7],1,BLACK,WHITE,24);
		LCD_ShowIntNum(192,160,detect[8],1,BLACK,WHITE,24);
		LCD_ShowIntNum(0,200,t_flag,1,RED,WHITE,32);
		LCD_ShowString(0,256,(uint8_t *)"TIME: ",RED,WHITE,32,0);
		LCD_ShowIntNum(144,256,angle_flag,2,RED,WHITE,32);
		LCD_ShowString(0,288,(uint8_t *)"N:",RED,WHITE,32,0);
		LCD_ShowIntNum(32,288,N,2,RED,WHITE,32);
		LCD_ShowIntNum(96,288,detect_time,4,BLACK,WHITE,32);
		vTaskDelay(50);
	}
}
PID_HandleDef motora_handle;
PID_HandleDef motorb_handle;
uint8_t turn_flag=0;
uint8_t detect_delay=0;
uint8_t detect_flag=1;
uint8_t motor_flag=0;

void motor_task(void *pvParameters)
{
	encoder_init();
	pid_init(&motora_handle,1,0.4,0.09,-1000,1000,0.7);
	pid_init(&motorb_handle,1,0.4,0.1,-1000,1000,0.7);
	vTaskDelay(500);
	speeda=13;
	speedb=13;
	while(1)
	{
		encoder_update();
		tempa=(int16_t)get_encoderA_count();
		tempb=(int16_t)get_encoderB_count();
		
		if(motor_flag!=1)
			motor_set((int16_t)pid_result(aresult,tempa,&motora_handle,0),(int16_t)pid_result(bresult,tempb,&motorb_handle,0));
		else if(motor_flag==1)
		{
			motor_set((int16_t)pid_result(0,tempa,&motora_handle,0),(int16_t)pid_result(0,tempb,&motorb_handle,0));
		}
		vTaskDelay(10);
	}
}
volatile uint16_t delay_time=0;
uint8_t stop_flag=0;
PID_HandleDef DetectHandle;
void detect_task(void *pvParameters)
{
//	uart0_send_string((char *)"detect\r\n");
	pid_init(&DetectHandle,10,4,5,-5,5,1);
	while(1)
	{
		light_detect();
		detect_handle();
/****************��ʼλ�ü�¼***************************/
		if(angle_flag==0)
		{
			n_time++;
		}
		else if(n_time_buf==0)
		{
			n_time_buf=6567-n_time;
			n_time=0;
		}
		if(detect_delay==0)
		{
			aresult=speeda+delta;
			bresult=speedb-delta;
		}
		else
		{
			aresult=speeda;
			bresult=speedb;
		}
		if(aresult>=20)
			aresult=20;
		if(bresult>=20)
			bresult=20;
/***********************����ѭ�����***************************/
//		if(t_flag==0&&(detect[7]==1&&detect[6]==1&&detect[5]==1&&detect[4]==1&&detect_delay==0)||(detect[7]==1&&detect[6]==1&&detect[5]==1&&detect_delay==0))
//		{
//			t_flag=1;
//			detect_delay=1;
//			speeda=6;
//			speedb=-4;
//		}
		if(detect[8]==1&&t_flag==0&&detect_delay==0)
		{
			angle_flag++;
			speeda=6;
			speedb=-4;
			detect_delay=1;
			t_flag=1;
		}
		if(t_flag==1)
		{
			detect_time++;
/****************�ջ�ת��********************/
			if(detect_time>=1000&&(detect[8]==1||detect[7]==1||detect[6]==1||detect[5]==1||detect[4]==1||detect[3]==1)&&detect_delay==1)
			{
				speeda=0;
				speedb=0;
				detect_delay=2;
				DL_GPIO_setPins(GPIOA,DL_GPIO_PIN_14);
			}
			else if(detect_time>=3300&&detect_delay==2)
			{
				speeda=13;
				speedb=13;
				detect_delay=0;
				
			}
			else if(detect_time>=5000)
			{
				t_flag=0;
				detect_time=0;
			}
			else if(detect_time>=1000&&detect_delay==2)
			{
				delta_speed=pid_result(0,delta,&DetectHandle,0);
			}	
/*****************����ת��********************/
//			if(detect_time>=130&&detect_delay==1)
//			{
//				speeda=13;
//				speedb=13;
//				detect_time=0;
//				detect_delay=0;
//			}
//			else if(detect_time>=300)
//			{
//				detect_time=0;
//				t_flag=0;
//			}
/*****************************************************/
		}
		else
		{
			detect_time=0;
		}
		if(speeda==13)
		{
			if(delta>2)	delta=2;
			else if(delta<-2) delta=-2;
		}
		else
		{
			delta=delta_speed;
		}
/******************�ջ�ѭ�����************************/
//		delta_speed=pid_result(0,delta,&DetectHandle,0);

//		if(t_flag==1)
//		{
//			if(detect_time++>=200)
//			{
//				detect_time=0;
//				t_flag=0;
//			}
//		}
/******************ֹͣ�ж�**************************/
		if((angle_flag/4)==N&&angle_flag>=4)
		{
			stop_flag=1;
			
		}
		if(stop_flag==1)
		{
			n_time++;
			if(n_time>=n_time_buf)
			{
				DL_GPIO_setPins(RGB_R_PORT,RGB_R_PIN);
				motor_flag=1;
			}
		}
/*******************************************************/
		vTaskDelay(1);
	}
}
void key_task(void *pvParameters)
{
	uint8_t key1_flag=0;
	uint16_t key1_time=0;
	uint8_t key2_flag=0;
	uint8_t key2_time=0;
	while(1)
	{
		if(DL_GPIO_readPins(GPIOB,DL_GPIO_PIN_27)==0&&key1_time==0)
		{
			key1_flag=1;
		}
		if(key1_flag!=0)
		{
			key1_time++;
		}
		if(key1_time>=500)
		{
			key1_flag=0;
			key1_time=0;
		}
		else if(key1_time>=50&&key1_flag==1)
		{
			if(DL_GPIO_readPins(GPIOB,DL_GPIO_PIN_27)==0)
			{
				vTaskSuspend(step_task_handle);  // ����ָ��������
				key1_flag=2;
				if(N>=5)
					N=1;
				else
					N++;
			}
		}
		vTaskDelay(1);
	}
}
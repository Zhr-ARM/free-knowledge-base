#ifndef __SYSTEM_H
#define __SYSTEM_H

#include "ti_msp_dl_config.h"

#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "timers.h"
#include "semphr.h"

/* GPIO定义 */
#define LED_B_PORT GPIOB
#define LED_B_PIN DL_GPIO_PIN_22

/* RTOS线程定义 */
// LED线程
#define LED_TASK_PRIORITY 6
#define LED_TASK_STACK_SIZE 64
void led_task(void *pvParameters);

// LCD线程
#define LCD_TASK_PRIORITY 7
#define LCD_TASK_STACK_SIZE 256
void lcd_task(void *pvParameters);

// MOTOR线程
#define MOTOR_TASK_PRIORITY 11
#define MOTOR_TASK_STACK_SIZE 128
void motor_task(void *pvParameters);

// DETECT线程
#define DETECT_TASK_PRIORITY 12
#define DETECT_TASK_STACK_SIZE 128
void detect_task(void *pvParameters);

// KEY线程
#define KEY_TASK_PRIORITY 10
#define KEY_TASK_STACK_SIZE 64
void key_task(void *pvParameters);

extern QueueHandle_t motoraQueue;
extern QueueHandle_t motorbQueue;

extern uint8_t N;

#ifdef __cplusplus
extern "C" {
#endif

void system_init(void);
void delay_us(uint32_t nus);

#ifdef __cplusplus
}
#endif

#endif /* ti_msp_dl_config_h */

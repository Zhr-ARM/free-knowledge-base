#ifndef __AP3216C_H__
#define __AP3216C_H__

#include "xl9555.h"
#include "driver/gpio.h"

typedef struct _ap3216c_value_t
{
    uint16_t ir;
    uint16_t als;
    uint16_t ps;
} ap3216c_value_t;

/* 相关参数定义 */
#define AP3216C_INT     xl9555_pin_read(AP_INT_IO)
#define AP3216C_ADDR    0X1E

/* 函数声明 */
void ap3216c_init(i2c_obj_t self);                                  /* 初始化AP3216C */
uint8_t ap3216c_comfig(void);                                       /* 检查AP3216C */
void ap3216c_read_data(uint16_t *ir, uint16_t *ps, uint16_t *als);  /* 读取AP3216C的数据 */

#endif
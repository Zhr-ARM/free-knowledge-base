#ifndef __SENSOR_H__
#define __SENSOR_H__

#include "esp_err.h"
#include <stdio.h>
#include <string.h>
#include <inttypes.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "driver/temperature_sensor.h"


/* 参数定义 */
#define SENSOR_RANGE_MIN    20      /* 要测试温度的最小值 */
#define SENSOR_RANGE_MAX    50      /* 要测试温度的最大值 */

/* 函数声明 */
void temperature_sensor_init(void); /* 初始化内部温度传感器 */
short sensor_get_temperature(void); /* 获取内部温度传感器温度值 */

#endif
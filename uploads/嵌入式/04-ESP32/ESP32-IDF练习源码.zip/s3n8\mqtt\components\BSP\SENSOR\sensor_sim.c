/**
 * @file sensor_sim.c
 * @brief 模拟传感器模块实现
 * @description 生成模拟的温湿度数据，用于调试和测试
 */

#include <math.h>
#include <time.h>
#include "sensor_sim.h"
#include "esp_log.h"
#include "esp_timer.h"

static const char *TAG = "SENSOR_SIM";

// 模拟数据基准值
#define TEMP_BASE           25.0f       // 温度基准值
#define TEMP_AMPLITUDE      5.0f        // 温度波动幅度
#define HUMIDITY_BASE       55.0f       // 湿度基准值
#define HUMIDITY_AMPLITUDE  15.0f       // 湿度波动幅度

// 模拟数据周期 (秒)
#define SIM_PERIOD          60.0f

// 模块初始化标志
static bool s_initialized = false;
static int64_t s_start_time = 0;

esp_err_t sensor_sim_init(void)
{
    s_start_time = esp_timer_get_time();
    s_initialized = true;
    ESP_LOGI(TAG, "模拟传感器初始化完成");
    return ESP_OK;
}

esp_err_t sensor_sim_read(sensor_data_t *data)
{
    if (data == NULL) {
        return ESP_ERR_INVALID_ARG;
    }

    if (!s_initialized) {
        sensor_sim_init();
    }

    // 获取当前时间
    int64_t current_time = esp_timer_get_time();
    float elapsed_sec = (current_time - s_start_time) / 1000000.0f;

    // 使用正弦函数模拟数据波动
    // 温度: 20~30℃ 范围内波动
    float temp_phase = 2.0f * M_PI * elapsed_sec / SIM_PERIOD;
    data->temperature = TEMP_BASE + TEMP_AMPLITUDE * sinf(temp_phase);

    // 湿度: 40~70% 范围内波动 (与温度反相)
    float humidity_phase = temp_phase + M_PI / 3.0f;  // 相位偏移
    data->humidity = HUMIDITY_BASE + HUMIDITY_AMPLITUDE * sinf(humidity_phase);

    // 添加随机噪声 (模拟真实传感器)
    float noise_temp = ((float)(esp_timer_get_time() % 100) - 50.0f) / 100.0f;
    float noise_hum = ((float)((esp_timer_get_time() / 7) % 100) - 50.0f) / 100.0f;
    
    data->temperature += noise_temp * 0.5f;
    data->humidity += noise_hum * 1.0f;

    // 限制范围
    if (data->temperature < 0.0f) data->temperature = 0.0f;
    if (data->temperature > 50.0f) data->temperature = 50.0f;
    if (data->humidity < 0.0f) data->humidity = 0.0f;
    if (data->humidity > 100.0f) data->humidity = 100.0f;

    // 记录时间戳
    data->timestamp = (uint32_t)(elapsed_sec);

    return ESP_OK;
}

float sensor_sim_get_temperature(void)
{
    sensor_data_t data;
    if (sensor_sim_read(&data) == ESP_OK) {
        return data.temperature;
    }
    return TEMP_BASE;
}

float sensor_sim_get_humidity(void)
{
    sensor_data_t data;
    if (sensor_sim_read(&data) == ESP_OK) {
        return data.humidity;
    }
    return HUMIDITY_BASE;
}

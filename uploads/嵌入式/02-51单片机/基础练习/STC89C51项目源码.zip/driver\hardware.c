#include "hardware.h"

uint8_t key_value=0;
uint8_t key_state=0;

void key_scan(void)
{
	if(P0_0==0)
	{
		key_value=key1;
		key_state++;
	}
	else if(P0_1 == 0)
	{
		key_value=key2;
		key_state++;
	}
	else if(P0_2 == 0)
	{
		key_value = key3;
		key_state++;
	}
	else if (P3_2 == 1)
	{
		key_value = key4;
		key_state++;
	}
	else
	{
		key_value = nokey;
		key_state = 0;
	}
}


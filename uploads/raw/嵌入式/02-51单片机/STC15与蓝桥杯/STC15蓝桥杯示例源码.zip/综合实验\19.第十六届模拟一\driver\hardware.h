#ifndef __HARDWARE_H__
#define __HARDWARE_H__

#include "main.h"
extern uint8_t xdata key_state;
extern uint8_t xdata key_value;
extern uint8_t xdata dig_buf[3][8];

void led_output(uint8_t value);
void relay_buzzer(uint8_t relay_flag,uint8_t buzzer_flag);
void dig_show(void);
void key_scan(void);

#endif
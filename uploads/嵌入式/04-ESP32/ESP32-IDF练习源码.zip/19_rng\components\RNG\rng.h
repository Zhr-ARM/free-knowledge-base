#ifndef __RNG_H__
#define __RNG_H__

#include <stdint.h>
#include <stddef.h>
#include <string.h>
#include <sys/param.h>
#include "esp_attr.h"
#include "esp_cpu.h"
#include "soc/wdev_reg.h"
#include "esp_random.h"
#include "esp_private/esp_clk.h"


/* 函数声明 */
uint32_t rng_get_random_num(void);          /* 得到随机数 */
int rng_get_random_range(int min, int max); /* 得到某个范围内的随机数 */

#endif

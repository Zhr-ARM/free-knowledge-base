#ifndef __SMG_H__
#define __SMG_H__
#include <STC15F2K60S2.H>
extern unsigned char code t_display[];
extern unsigned char code T_COM[];
extern unsigned char dig_buf[];

void show_smg();
#endif 
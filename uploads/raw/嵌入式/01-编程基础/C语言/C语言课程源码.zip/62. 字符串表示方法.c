#include <stdio.h>

int main()
{
    //字符数组表示字符串
    char str1[20] = {'H', 'e', 'l', 'l', 'o', '\0'};
    char str2[] = "Hello";
    
    str2[0] = 'h';
    
    printf("str1: %s\n", str1);
    printf("str2: %s\n", str2);
    
    //字符指针表示字符串
    char *p = "Hello world";
    p = "liangxu";
    //p = str1;
    //p[0] = 'L';
    
    printf("p: %s\n", p);
    
    
    return 0;
}
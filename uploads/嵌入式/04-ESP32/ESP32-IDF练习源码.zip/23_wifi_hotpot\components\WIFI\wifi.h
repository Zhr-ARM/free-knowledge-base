#ifndef __WIFI_H__
#define __WIFI_H__

#include "lcd.h"
#include "esp_wifi.h"
#include "esp_event.h"
#include <netdb.h>

#define EXAMPLE_ESP_WIFI_SSID   "123"
#define EXAMPLE_ESP_WIFI_PASS   "123456789"
#define EXAMPLE_MAX_STA_CONN    5
#define MAC2STR(a) (a)[0], (a)[1], (a)[2], (a)[3], (a)[4], (a)[5]
#define MACSTR "%02x:%02x:%02x:%02x:%02x:%02x"

void wifi_init_softap(void);

#endif
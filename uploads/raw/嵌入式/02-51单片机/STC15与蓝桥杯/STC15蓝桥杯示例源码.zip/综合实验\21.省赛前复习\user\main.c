#include "main.h"
#include "hardware.h"
#include "iic.h"
#include "ds1302.h"
#include "onewire.h"
#include "string.h"

uint8_t xdata led=0xff;
uint8_t xdata relay_flag=OFF;
uint8_t xdata buzzer_flag=OFF;
uint8_t mode=0;
uint32_t xdata pcfv;
uint32_t xdata pcfv1;
uint32_t xdata temp;
uint8_t xdata buf1;
uint8_t xdata buf2;

uint8_t xdata uart_buf[10];
uint8_t xdata uart_tx_buf[10]={0};
uint8_t xdata index=0;
bit uart_flag=0;
void Uart1_Isr(void) interrupt 4
{
	if (RI)				//��⴮��1�����ж�
	{
		if(SBUF!='\n')
			uart_buf[index++]=SBUF;
		else
		{
			uart_buf[index++]=SBUF;
			uart_flag=1;
		}
		RI = 0;			//�������1�����ж�����λ
	}
}

void SendByte(uint8_t dat)
{
	SBUF=dat;
	while(TI==0);
		TI=0;
}

void SendString(uint8_t *dat)
{
	while(*dat!='\0')
	{
		SendByte(*dat++);
	}
	index=0;
}

void Uart1_Init(void)	//9600bps@12.000MHz
{
	SCON = 0x50;		//8λ����,�ɱ䲨����
	AUXR |= 0x01;		//����1ѡ��ʱ��2Ϊ�����ʷ�����
	AUXR |= 0x04;		//��ʱ��ʱ��1Tģʽ
	T2L = 0xC7;			//���ö�ʱ��ʼֵ
	T2H = 0xFE;			//���ö�ʱ��ʼֵ
	AUXR |= 0x10;		//��ʱ��2��ʼ��ʱ
	ES = 1;				//ʹ�ܴ���1�ж�
	EA=1;
}


uint32_t xdata freq=0;
void Timer0_Init(void)		//1����@12.000MHz
{
	TMOD &= 0xF0;			//���ö�ʱ��ģʽ
	TMOD |= 0X04;
	TL0 = 0X00;				//���ö�ʱ��ʼֵ
	TH0 = 0X00;				//���ö�ʱ��ʼֵ
	TF0 = 0;				//���TF0��־
	TR0 = 1;				//��ʱ��0��ʼ��ʱ
}

void rd_freq(void)
{
	TR0=0;
	freq=TH0&0X0f;
	freq<<=8;
	freq|=TL0;
	freq=freq*10;
	TH0=TL0=0;
	TR0=1;
}

sbit TX=P1^0;
sbit RX=P1^1;
bit dis_flag=0;
uint32_t time_us=0;
uint32_t dis=0;

void Delay13us(void)	//@12.000MHz
{
	unsigned char data i;

	_nop_();
	_nop_();
	i = 36;
	while (--i);
}


void pca_init(void)
{
	P_SW1&=0XcF;
	CCON=0;
	CMOD=0X01;
	CCAPM0=0X10;
}

void rd_dis(void)
{
	uint8_t i=8;
	CF=CCF0=0;
	CH=CL=0;
	CCAP0H=CCAP0L=0;
	CCAPM0|=0X01;
	CR=1;
	EA=0;
	while(i--)
	{
		TX=1;
		Delay13us();
		TX=0;
		Delay13us();
	}
	EA=1;
	if(dis_flag==1)
	{
		dis_flag=0;
		dis=999;
	}
	else
	{
		dis_flag=0;
		dis=time_us*0.017+0.5;
	}
}

uint8_t xdata time10ms=0;
uint8_t xdata time200ms=0;
uint8_t xdata cnt_freq=0;
uint8_t xdata cnt_dis=0;
void Timer1_Init(void)		//1����@12.000MHz
{
	AUXR |= 0x40;			//��ʱ��ʱ��1Tģʽ
	TMOD &= 0x0F;			//���ö�ʱ��ģʽ
	TL1 = 0x20;				//���ö�ʱ��ʼֵ
	TH1 = 0xD1;				//���ö�ʱ��ʼֵ
	TF1 = 0;				//���TF1��־
	TR1 = 1;				//��ʱ��1��ʼ��ʱ
	ET1 = 1;				//ʹ�ܶ�ʱ��1�ж�
	EA=1;
}

void key_handle(void)
{
	if(key_value==7&&key_state==5)
		led=0x00;
	if(key_value==6&&key_state==5)
		led=0xff;
	if(key_value==11&&key_state==5)
		relay_flag=ON;
	if(key_value==10&&key_state==5)
		relay_flag=OFF;
	if(key_value==15&&key_state==5)
		buzzer_flag=ON;
	if(key_value==14&&key_state==5)
		buzzer_flag=OFF;
	if(key_value==4&&key_state==5)
	{
		if(++mode==6) mode=0;
	}
}

void mode_select(void)
{
	if(mode==MODE1)
	{
		dig_buf[mode][0]=1;
		dig_buf[mode][4]=temp/1000%10;
		dig_buf[mode][5]=temp/100%10+32;
		dig_buf[mode][6]=temp/10%10;
		dig_buf[mode][7]=temp%10;
	}
	else if(mode==MODE2)
	{
		dig_buf[mode][0]=ds1302_buf[0]/0x10;
		dig_buf[mode][1]=ds1302_buf[0]%0x10;
		dig_buf[mode][2]=17;
		dig_buf[mode][3]=ds1302_buf[1]/0x10;
		dig_buf[mode][4]=ds1302_buf[1]%0x10;
		dig_buf[mode][5]=17;
		dig_buf[mode][6]=ds1302_buf[2]/0x10;
		dig_buf[mode][7]=ds1302_buf[2]%0x10;
	}
	else if(mode==MODE3)
	{
		dig_buf[mode][0]=2;
		dig_buf[mode][5]=dis/100%10+32;
		dig_buf[mode][6]=dis/10%10;
		dig_buf[mode][7]=dis%10;
	}
	else if(mode==MODE4)
	{
		dig_buf[mode][0]=3;
		dig_buf[mode][3]=freq/10000%10;
		dig_buf[mode][4]=freq/1000%10;
		dig_buf[mode][5]=freq/100%10;
		dig_buf[mode][6]=freq/10%10;
		dig_buf[mode][7]=freq%10;
	}
	else if(mode==MODE5)
	{
		dig_buf[mode][0]=4;
		dig_buf[mode][1]=pcfv/100%10+32;
		dig_buf[mode][2]=pcfv/10%10;
		dig_buf[mode][3]=pcfv%10;
		
		dig_buf[mode][5]=pcfv1/100%10+32;
		dig_buf[mode][6]=pcfv1/10%10;
		dig_buf[mode][7]=pcfv1%10;
	}
	else if(mode==MODE6)
	{
		dig_buf[mode][0]=buf1/10%10;
		dig_buf[mode][1]=buf1%10;
		dig_buf[mode][2]=buf2/10%10;
		dig_buf[mode][3]=buf2%10;
	}
}

uint8_t xdata at24c02_buf[2]={80,90};
void main(void)
{
	ds1302_write();
	Timer0_Init();
	Timer1_Init();
	pca_init();
	Uart1_Init();
	at24c02_write(at24c02_buf,2,0x00);
	pcf8591_write(120);
	SendString("Hello world");
	while(1)
	{
		if(time10ms>=10)
		{
			key_scan();
			key_handle();
			mode_select();
			time10ms=0;
		}
		if(time200ms>=200)
		{
			pcfv=pcf8591_read(3)/0.51+0.5;
			pcfv1=pcf8591_read(0)/0.51+0.5;
			temp=rd_temperature();
			buf1=at24c02_read(0x00);
			buf2=at24c02_read(0x01);
			ds1302_read();
			time200ms=0;
		}
		if(cnt_freq>=100)
		{
			cnt_freq=0;
			rd_freq();
		}
		if(cnt_dis>=200)
		{
			cnt_dis=0;
			rd_dis();
		}
		if(uart_flag==1&&index!=0)
		{
			strcpy(uart_tx_buf, uart_buf);  // Copies uart_buf into uart_tx_buf
			SendString(uart_tx_buf);
			uart_flag=0;
		}
	}
}

void Timer1_Isr(void) interrupt 3
{
	led_output(led);
	relay_buzzer(relay_flag,buzzer_flag);
	dig_show();
	time10ms++;
	time200ms++;
    cnt_freq++;
    cnt_dis++;	
}

void pca_ire(void) interrupt 7
{
	CR=0;
	CCAPM0&=~0X01;
	if(CF)
	{
		CF=0;
		dis_flag=1;
	}
	else if(CCF0)
	{
		CCF0=0;
		dis_flag=0;
		time_us=(int)CCAP0H<<8|CCAP0L;
	}
}
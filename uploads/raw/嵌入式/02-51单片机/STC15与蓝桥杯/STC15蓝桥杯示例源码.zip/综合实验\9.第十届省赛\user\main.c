#include "main.h"
#include <STC15F2K60S2.H>
#include "hardware.h"
#include "i2c.h"

uint8_t xdata led=0xff;
uint8_t xdata led_mode=0;
uint8_t xdata relay_flag=OFF;
uint8_t xdata buzzer_flag=OFF;

uint32_t xdata pcfv;

void Timer0Init(void)		//1����@12.000MHz
{
	TMOD &= 0xF0;		//���ö�ʱ��ģʽ
	TMOD |= 0X04;
	TL0 = 0x00;		//���ö�ʱ��ֵ
	TH0 = 0x00;		//���ö�ʱ��ֵ
	TF0 = 0;		//���TF0��־
	TR0 = 1;		//��ʱ��0��ʼ��ʱ
	
}

uint8_t xdata time_10ms=0;
uint8_t xdata time_191ms=0;
uint8_t xdata time_200ms=0;

void Timer1Init(void)		//1����@12.000MHz
{
	AUXR |= 0x40;		//��ʱ��ʱ��1Tģʽ
	TMOD &= 0x0F;		//���ö�ʱ��ģʽ
	TL1 = 0x20;		//���ö�ʱ��ֵ
	TH1 = 0xD1;		//���ö�ʱ��ֵ
	TF1 = 0;		//���TF1��־
	TR1 = 1;		//��ʱ��1��ʼ��ʱ
	
	ET1=1;
	EA=1;
}

uint32_t xdata ne555_freq=0;
void ne555_detect(void)
{
	uint32_t temp=0;
	if(time_200ms>=200)
	{
		time_200ms=0;
		TR0=0;
		
		temp=TL0|((uint32_t)TH0<<8);
		
		TL0 = 0x00;		//���ö�ʱ��ֵ
	    TH0 = 0x00;		//���ö�ʱ��ֵ
		
		TR0=1;
		ne555_freq=temp*5;
	}
}
uint8_t xdata mode=PCFV;
uint8_t xdata temp=0;
uint8_t xdata buf=ON;
void mode_handle(void)
{
	if(buf==ON)
	{
	   if(mode==FREQ)
	   {
			dig_buf[mode][0]=15;
			if(ne555_freq>=10000) 
				dig_buf[mode][3]=ne555_freq/10000%10;
			else 
				dig_buf[mode][3]=16;
			if(ne555_freq>=1000) 
				dig_buf[mode][4]=ne555_freq/1000%10;
			else 
				dig_buf[mode][4]=16;
			if(ne555_freq>=100) 
				dig_buf[mode][5]=ne555_freq/100%10;
			else 
				dig_buf[mode][5]=16;
			if(ne555_freq>=10) 
				dig_buf[mode][6]=ne555_freq/10%10;
			else 
				dig_buf[mode][6]=16;
			if(ne555_freq>=0) 
				dig_buf[mode][7]=ne555_freq%10;
			else 
				dig_buf[mode][7]=16;
//			if(ne555_freq/10000%10!=0)
//				dig_buf[mode][3]=ne555_freq/10000%10;
//			else
//				dig_buf[mode][3]=16;
//			if(ne555_freq/1000%10!=0)
//				dig_buf[mode][4]=ne555_freq/1000%10;
//			else
//				dig_buf[mode][4]=16;
//			if(ne555_freq/100%10!=0)
//				dig_buf[mode][5]=ne555_freq/100%10;
//			else
//				dig_buf[mode][5]=16;
//			if(ne555_freq/10%10!=0)
//				dig_buf[mode][6]=ne555_freq/10%10;
//			else
//				dig_buf[mode][6]=16;
//			if(ne555_freq%10!=0)
//				dig_buf[mode][7]=ne555_freq%10;
//			else
//				dig_buf[mode][7]=16;

	   }
	   else if(mode==PCFV)
	   {
			dig_buf[mode][0]=25;
			dig_buf[mode][5]=pcfv/100%10+32;
			dig_buf[mode][6]=pcfv/10%10;
			dig_buf[mode][7]=pcfv%10;
	   }
	}
	else
	{
		dig_buf[mode][0]=16;
		dig_buf[mode][1]=16;
		dig_buf[mode][2]=16;
		dig_buf[mode][3]=16;
		dig_buf[mode][4]=16;
		dig_buf[mode][5]=16;
		dig_buf[mode][6]=16;
		dig_buf[mode][7]=16;
	}
}
void led_handle(void)
{
	if(led_mode==ON)
	{
		if(mode == FREQ)
		{
			led&=~(0x01);
			led|=0x02;
			if(ne555_freq<1000||(ne555_freq>=5000&&ne555_freq<=10000))	led|=0x08;
			else if((ne555_freq>=1000&&ne555_freq<=5000)||ne555_freq>10000) led&=~0x08;
		}
		else if(mode==PCFV)
		{
			led|=0x01;
			led&=~(0x02);
			if(pcfv<150||(pcfv>=250&&pcfv<=350))	   led|=0x04;
			else if((pcfv>=150&&pcfv<=250)||pcfv>350)  led&=~0x04;
		}
		if(temp==0)
			led|=0x10;
		else
			led&=~0x10;
	}
	else if(led_mode==OFF)
	{
		led=0xff;
	}
}
void key_handle(void)
{
	if(key_value==7&&key_state==5) 
	{
		if(buf==ON)
			buf=OFF;
		else
			buf=ON;
	}
	else if(key_value==6&&key_state==5) 
	{
		if(led_mode==ON)
			led_mode=OFF;
		else
			led_mode=ON;
	}
	else if(key_value==5&&key_state==5) 
	{
		if(temp==0)
			temp=3;
		else
			temp=0;
	}
	else if(key_value==4&&key_state==5) if(++mode==2) mode=0;
}

void main(void)
{
	led=0xff;
	relay_flag=OFF;
	buzzer_flag=OFF;
	Timer0Init();
	Timer1Init();
	pcf8591_write(2);
	while(1)
	{
		ne555_detect();
		if(time_10ms>=10)
		{
			key_scan();
			key_handle();
			led_handle();
			mode_handle();
			time_10ms=0;
		}
		if(time_191ms>=191)
		{
			pcfv=pcf8591_read(temp)/0.51+0.5;
			time_191ms=0;
		}
	}
}

void Timer1_serveice(void) interrupt 3
{
	led_output(led);
	relay_buzzer(relay_flag,buzzer_flag);
	dig_show();
	time_10ms++;
	time_191ms++;
	time_200ms++;
}
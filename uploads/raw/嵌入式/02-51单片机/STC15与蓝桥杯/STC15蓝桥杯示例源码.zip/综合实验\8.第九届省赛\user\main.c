#include "main.h"
#include "hardware.h"
#include "i2c.h"

uint8_t xdata led_buf=0xff;
uint8_t xdata led_temp=0xff;
uint32_t xdata led_flag=0;
uint32_t xdata led_count=0;
uint32_t xdata led_delay=400;
uint32_t xdata led_pcfv=0;
uint8_t xdata led=ON;

uint8_t xdata led_mode=mode1;

uint8_t xdata relay_flag=OFF;
uint8_t xdata buzzer_flag=OFF;

uint8_t at_tx_buf[2]={0};
uint8_t at_rx_buf[2]={0};

uint8_t xdata count=0;
uint8_t xdata flag=20;

uint8_t xdata mode=RUN;
uint8_t xdata config=RUN;
uint8_t xdata run_flag=1;
uint8_t xdata time_flag=1;
uint32_t xdata time0_800ms=0;

uint8_t xdata time0_10ms=0;
void Timer0Init(void)		//1����@12.000MHz
{
	AUXR |= 0x80;		//��ʱ��ʱ��1Tģʽ
	TMOD &= 0xF0;		//���ö�ʱ��ģʽ
	TL0 = 0x20;		//���ö�ʱ��ֵ
	TH0 = 0xD1;		//���ö�ʱ��ֵ
	TF0 = 0;		//���TF0��־
	TR0 = 1;		//��ʱ��0��ʼ��ʱ
	
	ET0=1;
	EA=1;
}

uint8_t xdata flag_config=0;

void key_handle(void)
{
	if(key_value==7&&key_state==5)	led=~led;
	if(key_value==6&&key_state==5)  
	{
		mode=CONFIG;
		if(flag_config==0) 
		{
			config = RUN;
			flag_config++;
		}
		else  if(flag_config==1)
		{ 	
			config = TIME;
			flag_config++;
		}
		else if(flag_config==2)
		{
			config = RUN;
			mode=NORMAL;
			flag_config=0;
			dig_buf[0]=16;
			dig_buf[1]=16;
			dig_buf[2]=16;
			dig_buf[3]=16;
			dig_buf[4]=16;
			dig_buf[5]=16;
			dig_buf[6]=16;
			dig_buf[7]=16;			
		}
		
	}
	if(key_value==5&&key_state==5)
	{
		if(config==RUN&&mode==CONFIG)
			if(++led_mode>=4)
				led_mode=0;
		if(config==TIME&&mode==CONFIG)
		{
			if(led_delay>=2000)
				led_delay=400;
			else
				led_delay=led_delay+100;
			at_tx_buf[0]=led_delay/1000%10;
			at_tx_buf[1]=led_delay/100%10;
			
			at24c02_write(0x00,at_tx_buf,2);
		}
	}
	if(key_value==4&&key_state==5)
	{	
		if(config==RUN&&mode==CONFIG)
		{
			if(led_mode==0)
				led_mode=3;
			else
				led_mode--;
		}
		if(config==TIME&&mode==CONFIG)
		{
			if(led_delay<=400)
				led_delay=2000;
			else
				led_delay=led_delay-100;
			at_tx_buf[0]=led_delay/1000%10;
			at_tx_buf[1]=led_delay/100%10;
			
			at24c02_write(0x00,at_tx_buf,2);
		}
	}
	if(key_value==4)
	{
		dig_buf[6]=17;
		dig_buf[7]=flag/4;
	}
	else 
	{
		dig_buf[6]=16;
		dig_buf[7]=16;
	}
}

void config_handle(void)
{
	if(config==TIME&&mode==CONFIG)
	{
		dig_buf[0]=17;
		dig_buf[1]=led_mode+1;
		dig_buf[2]=17;
		dig_buf[3]=16;
		dig_buf[4]=16;
		if(run_flag==1)
		{
			if(led_delay>=1000)
				dig_buf[4]=led_delay/1000%10;
			dig_buf[5]=led_delay/100%10;
			dig_buf[6]=led_delay/10%10;
			dig_buf[7]=led_delay%10;
		}
		else
		{
			dig_buf[5]=16;
			dig_buf[6]=16;
			dig_buf[7]=16;
		}   
	}
	if(config==RUN&&mode==CONFIG)
	{
		if(time_flag==1)
		{
			dig_buf[0]=17;
			dig_buf[1]=led_mode+1;
			dig_buf[2]=17;
		}
		else 
		{
			dig_buf[0]=16;
			dig_buf[1]=16;
			dig_buf[2]=16;
		}
		dig_buf[3]=16;
		if(led_delay>=1000)
				dig_buf[4]=led_delay/1000%10;
		dig_buf[5]=led_delay/100%10;
		dig_buf[6]=led_delay/10%10;
		dig_buf[7]=led_delay%10;
	}
}

void led_control(void)
{
	if(led_pcfv<125) flag=4;
	else if(led_pcfv<250) flag=9;
	else if(led_pcfv<375) flag=13;
	else if(led_pcfv<500) flag=19;
	if(led_mode==mode1)
	{
		if(led_flag==0) 	 led_temp=~((led_temp&0x00)|0x01);
		else if(led_flag==1) led_temp=~((led_temp&0x00)|0x02);
		else if(led_flag==2) led_temp=~((led_temp&0x00)|0x04);
		else if(led_flag==3) led_temp=~((led_temp&0x00)|0x08);
		else if(led_flag==4) led_temp=~((led_temp&0x00)|0x10);
		else if(led_flag==5) led_temp=~((led_temp&0x00)|0x20);
		else if(led_flag==6) led_temp=~((led_temp&0x00)|0x40);
		else if(led_flag==7) led_temp=~((led_temp&0x00)|0x80);
	}
	else if(led_mode==mode2)
	{
		if(led_flag==0) 	 led_temp=~((led_temp&0x00)|0x80);
		else if(led_flag==1) led_temp=~((led_temp&0x00)|0x40);
		else if(led_flag==2) led_temp=~((led_temp&0x00)|0x20);
		else if(led_flag==3) led_temp=~((led_temp&0x00)|0x10);
		else if(led_flag==4) led_temp=~((led_temp&0x00)|0x08);
		else if(led_flag==5) led_temp=~((led_temp&0x00)|0x04);
		else if(led_flag==6) led_temp=~((led_temp&0x00)|0x02);
		else if(led_flag==7) led_temp=~((led_temp&0x00)|0x01);
	}
	else if(led_mode==mode3)
	{
		if(led_flag==0) 	 led_temp=~((led_temp&0x00)|0x81);
		else if(led_flag==1) led_temp=~((led_temp&0x00)|0x42);
		else if(led_flag==2) led_temp=~((led_temp&0x00)|0x24);
		else if(led_flag==3) led_temp=~((led_temp&0x00)|0x18);
		else if(led_flag==4) led_temp=~((led_temp&0x00)|0x81);
		else if(led_flag==5) led_temp=~((led_temp&0x00)|0x42);
		else if(led_flag==6) led_temp=~((led_temp&0x00)|0x24);
		else if(led_flag==7) led_temp=~((led_temp&0x00)|0x18);
	}
	else if(led_mode==mode4)
	{
		if(led_flag==0) 	 led_temp=~((led_temp&0x00)|0x18);
		else if(led_flag==1) led_temp=~((led_temp&0x00)|0x24);
		else if(led_flag==2) led_temp=~((led_temp&0x00)|0x42);
		else if(led_flag==3) led_temp=~((led_temp&0x00)|0x81);
		else if(led_flag==4) led_temp=~((led_temp&0x00)|0x18);
		else if(led_flag==5) led_temp=~((led_temp&0x00)|0x24);
		else if(led_flag==6) led_temp=~((led_temp&0x00)|0x42);
		else if(led_flag==7) led_temp=~((led_temp&0x00)|0x81);
	}
}

void main(void)
{
	P2&=0x1F;
	led_delay=at24c02_read(0x00);
	led_delay=led_delay*1000+at24c02_read(0x01)*100;
	led_temp=0xff;
	buzzer_flag=OFF;
	relay_flag=OFF;
	config=TIME;
	Timer0Init();
	while(1)
	{
		if(time0_10ms>=10)
		{
			key_scan();
			key_handle();
			config_handle();
			led_control();
			led_pcfv=pcf8591_read(3);
			
			
//			dig_buf[0]=pcf8591_read(3)/100%10+32;
//			dig_buf[1]=pcf8591_read(3)/10%10;
//			dig_buf[2]=pcf8591_read(3)%10;
//			dig_buf[3]=at_rx_buf[1]/10%10;
//			dig_buf[4]=at_rx_buf[1]%10;
			time0_10ms=0;
		}
		if(led_count>=led_delay)
		{
			if(++led_flag>=8) led_flag=0;
			led_count = 0;
		}
		if(time0_800ms>=800)
		{
			run_flag=~run_flag;
			time_flag=~time_flag;
			time0_800ms=0;
		}
	}
}

void Timer0_Serveice(void) interrupt 1
{
	count++;
	if(led==ON)  
		led_count++;
	led_buf=led_temp;
	if(count>=20) count=0;
	if(count<flag)	led_output(led_buf);
	else		led_output(0xff);
	relay_buzzer(relay_flag,buzzer_flag);
	dig_show();
	time0_10ms++;
	time0_800ms++;
}

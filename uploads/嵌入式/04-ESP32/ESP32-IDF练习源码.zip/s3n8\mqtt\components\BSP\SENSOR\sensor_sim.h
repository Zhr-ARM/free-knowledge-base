/**
 * @file sensor_sim.h
 * @brief 模拟传感器模块头文件
 * @description 提供模拟温湿度数据生成功能
 */

#ifndef __SENSOR_SIM_H__
#define __SENSOR_SIM_H__

#include <stdint.h>
#include "esp_err.h"

/**
 * @brief 传感器数据结构体
 */
typedef struct {
    float temperature;      // 温度 (单位: 摄氏度)
    float humidity;         // 湿度 (单位: %)
    uint32_t timestamp;     // 时间戳
} sensor_data_t;

/**
 * @brief 初始化模拟传感器
 * @return ESP_OK: 成功
 */
esp_err_t sensor_sim_init(void);

/**
 * @brief 获取模拟传感器数据
 * @param data 存储传感器数据的结构体指针
 * @return ESP_OK: 成功, 其他: 失败
 */
esp_err_t sensor_sim_read(sensor_data_t *data);

/**
 * @brief 获取模拟温度值
 * @return 温度值 (单位: 摄氏度)
 */
float sensor_sim_get_temperature(void);

/**
 * @brief 获取模拟湿度值
 * @return 湿度值 (单位: %)
 */
float sensor_sim_get_humidity(void);

#endif // __SENSOR_SIM_H__

#include "duoji.h"

void x_duoji_control(uint16_t value)
{
	DL_TimerG_setCaptureCompareValue(duoji_INST,value,GPIO_duoji_C0_IDX);
}

void y_duoji_control(uint16_t value)
{
	DL_TimerG_setCaptureCompareValue(duoji_INST,value,GPIO_duoji_C1_IDX);
}

void x_duoji_set(int16_t value)
{
	uint16_t speed=value/5+10;
}

void y_duoji_set(int16_t value)
{
	
}
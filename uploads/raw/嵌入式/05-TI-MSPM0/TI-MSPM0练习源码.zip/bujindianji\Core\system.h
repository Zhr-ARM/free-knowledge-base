#ifndef __SYSTEM_H
#define __SYSTEM_H

#include "ti_msp_dl_config.h"

#include "FreeRTOS.h"
#include "task.h"
#include "queue.h"
#include "timers.h"
#include "semphr.h"

/* GPIO定义 */
#define LED_B_PORT GPIOB
#define LED_B_PIN DL_GPIO_PIN_22

/* RTOS线程定义 */
// LED线程
#define LED_TASK_PRIORITY 6
#define LED_TASK_STACK_SIZE 96
void led_task(void *pvParameters);

// UART线程
#define UART_TASK_PRIORITY 5
#define UART_TASK_STACK_SIZE 128
void uart_task(void *pvParameters);

// OPENMV线程
#define OPENMV_TASK_PRIORITY 9
#define OPENMV_TASK_STACK_SIZE 128
void openmv_task(void *pvParameters);

// STEP线程
#define STEP_TASK_PRIORITY 13
#define STEP_TASK_STACK_SIZE 128
void step_task(void *pvParameters);

// KEY线程
#define KEY_TASK_PRIORITY 11
#define KEY_TASK_STACK_SIZE 64
void key_task(void *pvParameters);

extern QueueHandle_t motoraQueue;
extern QueueHandle_t motorbQueue;
extern QueueHandle_t xQueue;
extern QueueHandle_t yQueue;

extern uint8_t N;

extern int16_t step1_result;
extern int16_t step2_result;
#ifdef __cplusplus
extern "C" {
#endif

void system_init(void);
void delay_us(uint32_t nus);

#ifdef __cplusplus
}
#endif

#endif /* ti_msp_dl_config_h */

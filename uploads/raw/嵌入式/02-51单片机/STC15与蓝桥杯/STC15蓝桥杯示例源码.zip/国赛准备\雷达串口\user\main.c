#include <STC15F2K60S2.H>
#include "main.h"
#include "hardware.h"

uint8_t uart_buf[10]={0};
uint8_t uart_tx_buf[10]={0};
uint8_t index=0;
bit uart_flag=0;
void Uart1_Isr(void) interrupt 4
{
	if(RI)
    {
        if(SBUF!='\n')
        {
            uart_buf[index++]=SBUF;
        }
        else
        {
            uart_flag=1;
        }
        RI=0;
    }
}
void SendByte(uint8_t dat)
{
    ES=0;
    SBUF=dat;
    while(TI==0);
    TI=0;
    ES=1;
}
void SendString(uint8_t *dat)
{
    while(*dat!='\0')
    {
        SendByte(*dat++);
    }
    index=0;
}
void Uart1_Init(void)	//9600bps@12.000MHz
{
	SCON = 0x50;		//8位数据,可变波特率
	AUXR |= 0x01;		//串口1选择定时器2为波特率发生器
	AUXR |= 0x04;		//定时器时钟1T模式
	T2L = 0xC7;			//设置定时初始值
	T2H = 0xFE;			//设置定时初始值
	AUXR |= 0x10;		//定时器2开始计时
	ES = 1;				//使能串口1中断
    EA=1;
}


sbit TX = P1^0;
sbit RX = P1^1;
uint32_t dis=0;
uint32_t tim_us=0;
uint8_t dis_time=0;
bit dis_flag=0;

void pca_init(void)
{
    CCON=0;
    CMOD=0X01;
    CCAPM0=0X10;
    P_SW1&=0XCF;
}
void rd_dis(void)
{
    uint8_t i=8;
    CCAPM0|=0X01;
    CH=CL=0;
    CCAP0L=CCAP0H=0;
    CF=CCF0=0;
    CR=1;
    EA=0;
    do
    {
        TX=1;
        Delay13us();
        TX=0;
        Delay13us();
    } while (i--);
    EA=1;
    if(dis_flag==1)
    {
        dis_flag=0;
        dis=999;
    }
    else
    {
        dis=tim_us*0.017+0.5;
    }
}

void pca_irq(void) interrupt 7
{
    CCAPM0&=~0X01;
    CR=0;
    if(CF)
    {
        dis_flag=1;
        CF=0;
    }
    else if(CCF0)
    {
        dis_flag=0;
        tim_us=(int)(CCAP0H<<8)|CCAP0L;
        CCF0=0;
    }
}

void Timer0_Init(void)		//1毫秒@12.000MHz
{
	TMOD &= 0xF0;			//设置定时器模式
    TMOD |= 0x04;
	TL0 = 0x00;				//设置定时初始值
	TH0 = 0x00;				//设置定时初始值
	TF0 = 0;				//清除TF0标志
	TR0 = 1;				//定时器0开始计时
    EA=1;
}
uint8_t ne555_time=0;
uint32_t ne555_freq=0;
void ne555_detect(void)
{
    if(ne555_time>=200)
    {
        TR0=0;
        ne555_freq=(int)(TH0<<8)|TL0;
        TH0=TL0=0;
        TR0=1;
        ne555_time=0;
        ne555_freq*=5;
    }
}

uint32_t cnt=0;
uint32_t T=20;
int duty=0;
uint8_t pwm_time=0;
bit duty_flag=0;

void pwm_control(void)
{
    if(++cnt>=T)
        cnt=0;
    if(cnt>=duty)
    {
        P0=0x00;
        P2=P2&0x1F|0x80;
        P2&=0x1F;
    }
    else
    {
        P0=0xff;
        P2=P2&0x1F|0x80;
        P2&=0x1F;
    }
    if(++pwm_time>=200)
    {
        if(duty_flag==1)
            duty--;
        else if (duty_flag==0)
        {
            duty++;
        }
        if(duty>=T)
            duty_flag=1;
        else if(duty<=0)
            duty_flag=0;
        pwm_time=0;
    }
}

uint8_t time10ms=0;
void Timer1_Init(void)		//1毫秒@12.000MHz
{
	AUXR |= 0x40;			//定时器时钟1T模式
	TMOD &= 0x0F;			//设置定时器模式
	TL1 = 0x20;				//设置定时初始值
	TH1 = 0xD1;				//设置定时初始值
	TF1 = 0;				//清除TF1标志
	TR1 = 1;				//定时器1开始计时
	ET1 = 1;				//使能定时器1中断
    EA=1;
}

uint8_t mode=0;
bit pwm_flag=0;
void key_handle(void)
{
    if(key_value==7&&key_state==5)
    {
        pwm_flag=1;
        cnt=0;
        duty=0;
    }
    else if(key_value==6&&key_state==5)
    {
        pwm_flag=0;
        P0=0xff;
        P2=P2&0x1F|0x80;
        P2&=0x1F;
    }
    else if(key_value==5&&key_state==5)
    {
        if(++mode>=2)
            mode=0;
    }
}

void dig_handle(void)
{
    if(mode==0)
    {
    dig_buf[mode][0]=ne555_freq/10000%10;
    dig_buf[mode][1]=ne555_freq/1000%10;
    dig_buf[mode][2]=ne555_freq/100%10;
    dig_buf[mode][3]=ne555_freq/10%10;
    dig_buf[mode][4]=ne555_freq%10;
    }
    else if(mode==1)
    {
        dig_buf[mode][1]=dis/100%10;
        dig_buf[mode][2]=dis/10%10;
        dig_buf[mode][3]=dis%10;
    }
}


void main(void)
{
    Timer0_Init();
    Timer1_Init();
    pca_init();
    Uart1_Init();
    SendString("Hello World!\n");
    while(1)
    {
        ne555_detect();

        if(time10ms>=10)
        {
            key_scan();
            dig_handle();
            key_handle();
            time10ms=0;
        }
        if(dis_time>=250)
        {
            dis_time=0;
            rd_dis();
        }
        if(uart_flag==1&&index!=0)
        {
            strcpy(uart_tx_buf,uart_buf);
            SendString(uart_tx_buf);
            uart_flag=0;
        }
    }
}
void Timer1_Isr(void) interrupt 3
{
    time10ms++;
    dis_time++;
    dig_show();
    if(pwm_flag==1)
        pwm_control();
    ne555_time++;
}
void Delay13us(void)	//@12.000MHz
{
	unsigned char data i;

	_nop_();
	_nop_();
	i = 36;
	while (--i);
}

#ifndef __MAIN_H_
#define __MAIN_H_
#include <STC15F2K60S2.H>
#include "SMG.h"
#include "onewire.h"
#include "intrins.h"
#include "ds1302.h"
#include "iic.h"




void Timer5Init(void);
void Timer0Init(void);		//0΢��@12.000MHz
uchar rd_key();//����
uchar rd_keybo();//����
void rd_fre();
void rd_ds1302();
void wri_ds1302();
void PCA_init();
void rd_dis();
#endif
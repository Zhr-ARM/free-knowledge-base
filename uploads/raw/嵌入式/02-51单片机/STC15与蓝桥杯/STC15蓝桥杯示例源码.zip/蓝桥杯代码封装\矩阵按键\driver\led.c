#include "led.h"
/*������������*/
unsigned char  ucled=0xff;
unsigned char control=0;
void led_control()
{
	if(control==1) 
	{
		ucled=ucled<<1;
		control=0;
	}
	if(control==2) 
	{
		ucled=ucled>>1;
		control=0;
	}
	P0=0x00;
	P0=ucled;
	P2=P2&0x1F|0x80;
	P2&=0x1F;
}





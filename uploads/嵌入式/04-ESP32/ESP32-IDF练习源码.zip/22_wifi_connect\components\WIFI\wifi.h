#ifndef __WIFI_H__
#define __WIFI_H__

#include "lcd.h"
#include "esp_wifi.h"
#include "esp_event.h"
#include <netdb.h>
#include "freertos/event_groups.h"

/* 链接wifi名称 */
#define DEFAULT_SSID        "TP-LINK_E5B4"
/* wifi密码 */
#define DEFAULT_PWD         "zhr13881112752"
#define WIFI_CONNECTED_BIT  BIT0
#define WIFI_FAIL_BIT       BIT1
/* WIFI默认配置 */
#define WIFICONFIG()   {                            \
    .sta = {                                        \
        .ssid = DEFAULT_SSID,                       \
        .password = DEFAULT_PWD,                    \
        .threshold.authmode = WIFI_AUTH_WPA2_PSK,   \
    },                                              \
}

void wifi_sta_init(void);

#endif
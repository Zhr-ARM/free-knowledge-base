#ifndef __LED_H__
#define __LED_H__
#include <STC15F2K60S2.H>
extern unsigned char led;
extern unsigned int  Timer01s;
void Timer0Init(void);
void Timer0Service();
void led_control(unsigned char command);
#endif 
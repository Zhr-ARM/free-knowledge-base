#include "main.h"
#include "hardware.h"
#include "i2c.h"

uint8_t xdata led=0xff;
uint8_t xdata buzzer_flag=OFF;
uint8_t xdata relay_flag=OFF;

uint32_t xdata pcfv;
uint8_t xdata mode=F;

void Timer0Init(void)		//@12.000MHz
{
	TMOD &= 0xF0;		//���ö�ʱ��ģʽ
	TMOD |= 0X04;
	TL0 = 0x00;		//���ö�ʱ��ֵ
	TH0 = 0x00;		//���ö�ʱ��ֵ
	TF0 = 0;		//���TF0��־
	TR0 = 1;		//��ʱ��0��ʼ��ʱ
}
uint32_t xdata temp=0;
uint8_t xdata ne555_time=0;
uint32_t xdata freq=0;
uint32_t xdata time=0;
void ne555_detect(void)
{
	unsigned int ne555_temp=0;
	if(ne555_time>=100)
	{
		ne555_time=0;
		
		TR0=0;
		
		ne555_temp = TL0 | ((unsigned int)TH0 <<8);
		
		TL0= 0X00;
		TH0= 0X00;
		
		TR0=1;
		
		freq=ne555_temp*10;
		time=1000000/freq;
	}
	
}

uint8_t xdata time1_10ms;
uint8_t xdata time1_200ms;

void Timer1Init(void)		//1����@12.000MHz
{
	AUXR |= 0x40;		//��ʱ��ʱ��1Tģʽ
	TMOD &= 0x0F;		//���ö�ʱ��ģʽ
	TL1 = 0x20;		//���ö�ʱ��ֵ
	TH1 = 0xD1;		//���ö�ʱ��ֵ
	TF1 = 0;		//���TF1��־
	TR1 = 1;		//��ʱ��1��ʼ��ʱ
	
	ET1=1;
	EA=1;
}
uint8_t xdata flag=1;
void mode_select(void)
{
	if(mode==F)
	{
		dig_buf[mode][0]=24;
		if(freq>=10000)
			dig_buf[mode][3]=freq/10000%10;
		else
			dig_buf[mode][3]=16;
		if(freq>=1000)
			dig_buf[mode][4]=freq/1000%10;
		else
			dig_buf[mode][4]=16;
		if(freq>=100)
			dig_buf[mode][5]=freq/100%10;
		else              
			dig_buf[mode][5]=16;
		if(freq>=10)
			dig_buf[mode][6]=freq/10%10;
		else              
			dig_buf[mode][6]=16;
		if(freq>=0)
			dig_buf[mode][7]=freq%10;
		else              
			dig_buf[mode][7]=16;
	}
	else if(mode==N)
	{
		dig_buf[mode][0]=22;
		if(time>=10000)
			dig_buf[mode][3]=time/10000%10;
		else
			dig_buf[mode][3]=16;
		if(time>=1000)
			dig_buf[mode][4]=time/1000%10;
		else
			dig_buf[mode][4]=16;
		if(time>=100)
			dig_buf[mode][5]=time/100%10;
		else              
			dig_buf[mode][5]=16;
		if(time>=10)
			dig_buf[mode][6]=time/10%10;
		else              
			dig_buf[mode][6]=16;
		if(time>=0)
			dig_buf[mode][7]=time%10;
		else              
			dig_buf[mode][7]=16;
	}
	else if(mode==U)
	{
		dig_buf[mode][0]=25;
		dig_buf[mode][1]=17;
		dig_buf[mode][2]=flag;
		
		dig_buf[mode][5]=pcfv/100%10+32;
		dig_buf[mode][6]=pcfv/10%10;
		dig_buf[mode][7]=pcfv%10;
		
	}
}
uint32_t xdata u_buf;
uint32_t xdata f_buf;
uint8_t xdata led_flag=1;
void key_handle(void)
{
	if(key_value==6&&key_state==5)
	{
		u_buf=pcfv;
	}
	else if(key_value==7)
	{
		if(key_state==5)
		{
			f_buf=pcfv;
		}
		else if(key_state==100)
		{
			if(led_flag==ON)
				led_flag=OFF;
			else
				led_flag=ON;
		}
	}
	else if(key_value==5&&key_state==5)
	{
		if(mode==U)
		{
			if(flag==1) flag=3;
			else        flag=1;
		}
	}
	else if(key_value==4&&key_state==5)
	{
		if(++mode==3) mode=0;
		flag=1;
	}
}
void led_handle(void)
{
	if(mode==F)	led&=~0x04;
	else 		led|=0x04;
	if(mode==N) led&=~0x08;
	else        led|=0x08;
	if(mode==U) led&=~0x10;
	else        led|=0x10;
	if(pcfv>u_buf)	led&=~0x01;
	else 			led|=0x01;
	if(freq>f_buf)	led&=~0x02;
	else 			led|=0x02;
}
void main(void)
{
	led=0xff;
	buzzer_flag=OFF;
	relay_flag=OFF;
	Timer0Init();
	Timer1Init();
	while(1)
	{
		
		if(time1_10ms>=10)
		{
			key_scan();
			key_handle();
			led_handle();
			mode_select();
			time1_10ms=0;
		}
		if(time1_200ms>=200)
		{
			pcfv=pcf8591_read(flag)/0.51+0.5;
			time1_200ms=0;
		}
	}
	
}
void Timer1_Serveice(void)	interrupt 3
{
	if(led_flag==ON)
		led_output(led);
	else
		led_output(0xff);
	relay_buzzer(relay_flag,buzzer_flag);
	dig_show();
	time1_10ms++;
	time1_200ms++;
	ne555_time++;
	ne555_detect();
}

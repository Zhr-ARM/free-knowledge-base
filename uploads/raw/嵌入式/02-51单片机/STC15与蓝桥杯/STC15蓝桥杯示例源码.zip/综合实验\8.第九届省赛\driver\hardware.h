#ifndef __HARDWARE_H__
#define __HARDWARE_H__

#include "main.h"

void led_output(uint8_t value);
void relay_buzzer(uint8_t relay_value,uint8_t buzzer_value);
void dig_show(void);
void key_scan(void);
extern uint8_t xdata dig_buf[8];
extern uint8_t xdata key_value;
extern uint8_t xdata key_state;

#endif 
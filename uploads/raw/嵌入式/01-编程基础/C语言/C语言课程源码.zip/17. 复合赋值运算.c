#include <stdio.h>

int main() {
    int a = 10;
    
    printf("初始值: a = %d\n", a);
    
    // 加法赋值 +=
    a += 5;                    // 等价于 a = a + 5;
    printf("a += 5 后: a = %d\n", a);
    
    // 减法赋值 -=
    a -= 3;                    // 等价于 a = a - 3;
    printf("a -= 3 后: a = %d\n", a);
    
    // 乘法赋值 *=
    a *= 2;                    // 等价于 a = a * 2;
    printf("a *= 2 后: a = %d\n", a);
    
    // 除法赋值 /=
    a /= 4;                    // 等价于 a = a / 4;
    printf("a /= 4 后: a = %d\n", a);
    
    // 取模赋值 %=
    a %= 3;                    // 等价于 a = a % 3;
    printf("a %%= 3 后: a = %d\n", a);
    
    return 0;
}
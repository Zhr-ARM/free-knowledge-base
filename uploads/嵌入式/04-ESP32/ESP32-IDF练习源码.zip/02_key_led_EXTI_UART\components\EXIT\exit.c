#include "exit.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "led.h"

static void IRAM_ATTR exit_gpio_isr_handler(void *arg)
{
    uint32_t gpio_num = (uint32_t) arg;

    if(gpio_num == KEY1_INT_GPIO_PIN)
    {
        LED_TOGGLE();
    }
}

void exit_init(void)
{
    gpio_config_t gpio_init_struct;

    gpio_init_struct.mode = GPIO_MODE_INPUT;
    gpio_init_struct.pull_down_en = GPIO_PULLDOWN_DISABLE;
    gpio_init_struct.pull_up_en = GPIO_PULLUP_ENABLE;
    gpio_init_struct.intr_type = GPIO_INTR_NEGEDGE;
    gpio_init_struct.pin_bit_mask = 1ull << KEY1_INT_GPIO_PIN;;
    gpio_config(&gpio_init_struct);

    /* 注册中断服务 */
    gpio_install_isr_service(ESP_INTR_FLAG_EDGE);
    /* 设置GPIO的中断回调函数 */
    gpio_isr_handler_add(KEY1_INT_GPIO_PIN, exit_gpio_isr_handler,(void*)KEY1_INT_GPIO_PIN);
    /* 使能GPIO模块中断信号 */
    gpio_intr_enable(KEY1_INT_GPIO_PIN);
}
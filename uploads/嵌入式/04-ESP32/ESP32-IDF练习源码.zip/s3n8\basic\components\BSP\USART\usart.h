#ifndef __USART_H__
#define __USART_H__

#include "driver/uart.h"

void usart1_init(void);


#endif
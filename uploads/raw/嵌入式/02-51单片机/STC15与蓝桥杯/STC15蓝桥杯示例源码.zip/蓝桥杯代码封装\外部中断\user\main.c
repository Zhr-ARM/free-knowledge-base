#include <STC15F2K60S2.H>
#include <intrins.h>
#include "led.h"
void Delay500ms()		//@12.000MHz
{
	unsigned char i, j, k;

	_nop_();
	_nop_();
	i = 23;
	j = 205;
	k = 120;
	do
	{
		do
		{
			while (--k);
		} while (--j);
	} while (--i);
}

void Init_INT1()
{
	IT1=1;
	EX1=1;
	EA=1;
	
	
}
void ServiceINT1() interrupt 2/*ʹ���ж���1�ǰ���S4�ж�
	                              �ж���0�ǰ�S5�ж�*/
{
	  Delay500ms();
		led_control(0x55);
		P0=0x00;
		P0=0x10;
		P2=P2&0x1F|0xA0;
		P2&=0x1F;
	  P0=0x00;
		P0=0x40;
		P2=P2&0x1F|0xA0;
		P2&=0x1F;
	  Delay500ms();
	}
void main()
{
	Init_INT1();
	Timer0Init();
	while(1)
	{
		led_control(led);
	}
}
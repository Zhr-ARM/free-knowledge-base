#ifndef __HARDWARE_H__
#define __HARDWARE_H__

#include "main.h"

void dig_show(void);
void key_scan(void);
extern uint8_t key_value;
extern uint8_t key_state;
extern uint8_t dig_buf[][8];

#endif
#ifndef __MAIN_H__
#define __MAIN_H__

#include <STC15F2K60S2.H>
#include "intrins.h"

#define ON   1
#define OFF  0

#define uint8_t unsigned char 
#define uint32_t unsigned int

#define FREQ  0
#define PCFV  1

extern uint8_t xdata mode;

#endif 
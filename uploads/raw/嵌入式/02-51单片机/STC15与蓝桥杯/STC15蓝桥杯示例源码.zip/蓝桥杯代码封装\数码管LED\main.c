#include <STC15F2K60S2.H>
#include "hardware.h"
void main()
{
	unsigned char cnt=0;
	
	Timer1Init();
	
	while(1)
	{
		if(timer1s >=1000)
		{
			timer1s = 0;
			led_buf ^= 0x40;

			
			cnt++;
			
			dig_buf[5] = cnt/100;
			dig_buf[6] = cnt/10%10;
			dig_buf[7] = cnt % 10;
		}
	}
}

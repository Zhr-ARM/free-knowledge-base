#ifndef __HARDWARE_H__
#define __HARDWARE_H__

#include <STC15F2K60S2.H>
extern unsigned char key_value;
extern unsigned char key_state;
extern unsigned char  R;
extern unsigned char  C;
extern unsigned char code key_pad_value_all[4][4];

void key_scan();
#endif
#include "main.h"
#include "hardware.h"
#include "iic.h"

void Delay13us(void)	//@12.000MHz
{
	unsigned char data i;

	_nop_();
	_nop_();
	i = 36;
	while (--i);
}


uint8_t xdata led=0xff;
uint8_t xdata relay_flag=OFF;
uint8_t xdata buzzer_flag=OFF;
uint8_t xdata mode=0;
uint32_t xdata pcfv=0;
uint8_t xdata dis_max=60;
uint8_t xdata dis_min=10;
uint8_t xdata alarm_time=0;

uint8_t xdata time_10ms=0;
uint32_t xdata time_200ms=0;
void Timer1_Init(void)		//100΢��@12.000MHz
{
	AUXR |= 0x40;			//��ʱ��ʱ��1Tģʽ
	TMOD &= 0x0F;			//���ö�ʱ��ģʽ
	TL1 = 0x50;				//���ö�ʱ��ʼֵ
	TH1 = 0xFB;				//���ö�ʱ��ʼֵ
	TF1 = 0;				//���TF1��־
	TR1 = 1;				//��ʱ��1��ʼ��ʱ
	ET1 = 1;				//ʹ�ܶ�ʱ��1�ж�
	
	EA=1;
}

sbit TX=P1^0;
sbit RX=P1^1;
bit dis_flag=0;
uint32_t xdata distance=0;
uint32_t xdata last_distance=0;
uint32_t xdata time_us=0;
uint32_t xdata cnt_dis=0;
uint8_t xdata flag=1;
void pca_init(void)
{
	P_SW1&=0XcF;
	CCON=0;
	CMOD=0x01;
	CCAPM0=0X10;
}

void rd_distance(void)
{
	uint8_t i=8;
	CCAPM0|=0X01;
	CH=CL=0;
	CCAP0L=CCAP0H=0;
	CF=CCF0=0;
	CR=1;
	EA=0;
	last_distance=distance;
	do
	{
		TX=1;
		Delay13us();
		TX=0;
		Delay13us();
	}while(i--);
	EA=1;
	if(dis_flag==1)
	{
		dis_flag=0;
		distance=999;
	}
	else if(dis_flag==0)
	{
		dis_flag=0;
		distance=time_us*0.017+0.5;
	}
}
uint8_t pcfv_flag=0;
void key_handle(void)
{
	if(key_value==4&&key_state==5)
	{
		if(++mode==3)
			mode=0;
	}
	if(key_value==5&&key_state==5)
	{
		if(mode==MODE2)
		{
			if(flag==1)
				flag=2;
			else
				flag=1;
		}
		if(mode==MODE3)
		{
			alarm_time=0;
		}
	}
	if(key_value==8&&key_state==5)
	{
		if(mode==MODE2&&flag==1)
		{
			if(dis_min<40)	dis_min+=10;
			else	dis_min=0;
		}
		else if(mode==MODE2)
		{
			pcfv_flag=0;
		}
	}
	if(key_value==9&&key_state==5)
	{
		if(mode==MODE2&&flag==1)
		{
			if(dis_max<90)	dis_max+=10;
			else	dis_max=50;
		}
				else if(mode==MODE2)
		{
			pcfv_flag=1;
		}
	}
}
void mode_select(void)
{
	if(mode==MODE1)
	{
		dig_buf[mode][0]=10;
		if(distance>100)
			dig_buf[mode][5]=distance/100%10+32;
		else
			dig_buf[mode][5]=16;
		if(distance>10)
			dig_buf[mode][6]=distance/10%10;
		else
			dig_buf[mode][6]=16;
		if(distance>0)
			dig_buf[mode][7]=distance%10;
		else
			dig_buf[mode][7]=16;
	}
	else if(mode==MODE2)
	{
		dig_buf[mode][0]=24;
		dig_buf[mode][1]=flag;
		dig_buf[mode][3]=dis_min/10%10;
		dig_buf[mode][4]=dis_min%10;
		dig_buf[mode][5]=17;
		dig_buf[mode][6]=dis_max/10%10;
		dig_buf[mode][7]=dis_max%10;
	}
	else if(mode==MODE3)
	{
		dig_buf[mode][0]=14;
		if(alarm_time<10)
			dig_buf[mode][7]=alarm_time;
		else
			dig_buf[mode][7]=17;
	}
}

void mode_handle(void)
{
	if((distance<dis_min||distance>dis_max)&&(last_distance>=dis_min&&last_distance<=dis_max))
	{
		alarm_time++;
	}
}
void pcfv_handle(void)
{
	if(pcfv_flag==0&&flag==2)
	{
		if(pcfv<100)
			dis_min=0;
		else if(pcfv<200)
			dis_min=10;
		else if(pcfv<300)
			dis_min=20;
		else if(pcfv<400)
			dis_min=30;
		else if(pcfv<500)
			dis_min=40;
	}
	else if(pcfv_flag==1&&flag==2)
	{
		if(pcfv<100)
			dis_max=50;
		else if(pcfv<200)
			dis_max=60;
		else if(pcfv<300)
			dis_max=70;
		else if(pcfv<400)
			dis_max=80;
		else if(pcfv<500)
			dis_max=90;
	}
}
bit led_flag=0;
bit led_bline=0;
uint8_t xdata led_time=0;
void led_handle(void)
{
	if(mode==MODE1)
		led&=~0x01;
	else
		led|=0x01;
	if(mode==MODE2)
		led&=~0x02;
	else
		led|=0x02;
	if(mode==MODE3)
		led&=~0x04;
	else
		led|=0x04;
	if(distance>=dis_min&&distance<=dis_max)
	{
		led&=~0x80;
		led_flag=0;
	}
	else
	{
		led_flag=1;
	}
	if(led_flag==1&&led_bline==1)
		led&=~0x80;
	else if(led_flag==1&&led_bline==0)
		led|=0x80;
}

void main(void)
{
	rd_distance();
	pca_init();
	Timer1_Init();
	while(1)
	{
		if(time_10ms>=10)
		{
			key_scan();
			key_handle();

			mode_select();
			time_10ms=0;
		}
		if(time_200ms>=200)
		{
			pcfv=pcf8591_read(3)/0.51+0.5;
			pcfv_handle();
			mode_handle();
     		led_handle();
			time_200ms=0;
		}
		if(cnt_dis>=250)
		{
			rd_distance();
			cnt_dis=0;
		}
		if(led_time>=100)
		{
			if(led_bline==1)
				led_bline=0;
			else
				led_bline=1;
			led_time=0;
		}
	}
}

void Timer1_Isr(void) interrupt 3
{
	led_output(led);
	relay_buzzer(relay_flag,buzzer_flag);
	dig_show();
	time_10ms++;
	time_200ms++;
	cnt_dis++;
	if(led_flag==1)
		led_time++;
	else
		led_time=0;
}

void pca_ire(void) interrupt 7
{
	CCAPM0&=~0X01;
	CR=0;
	if(CF)
	{
		CF=0;
		dis_flag=1;
	}
	else if(CCF0)
	{
		CCF0=0;
		time_us=(int)(CCAP0H<<8)|CCAP0L;
		dis_flag=0;
	}
}

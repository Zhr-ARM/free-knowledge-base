#include <stdio.h>
#include <stdlib.h>
#include <time.h>

int main()
{
    srand(time(NULL));	//使用当前时间作为种子
    int num = rand() % 5 + 1;  //0~4  1~4
    printf("随机数：%d\n", num);
    return 0;
}
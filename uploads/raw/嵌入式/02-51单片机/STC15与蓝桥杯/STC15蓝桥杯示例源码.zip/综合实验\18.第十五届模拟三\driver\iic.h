#ifndef __IIC_H__
#define __IIC_H__

#include "main.h"

uint32_t pcf8591_read(uint8_t addr);


#endif
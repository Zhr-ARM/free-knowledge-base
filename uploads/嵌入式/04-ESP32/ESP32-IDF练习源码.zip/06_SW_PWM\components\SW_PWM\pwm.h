#ifndef PWM_H
#define PWM_H

#include <driver/ledc.h>
#include "driver/gpio.h"

#define LEDC_PWM_TIMER        LEDC_TIMER_1
#define LEDC_PWM_CH0_GPIO     GPIO_NUM_1
#define LEDC_PWM_CH0_CHANNEL  LEDC_CHANNEL_1

void pwm_init(uint8_t resolution, uint16_t freq);
void pwm_set_duty(uint32_t duty);

#endif // PWM_H
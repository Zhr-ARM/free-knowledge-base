#ifndef __MAIN_H__
#define __MAIN_H__

#include <STC15F2K60S2.H>
#include "intrins.h"

#define uint8_t unsigned char
#define uint32_t unsigned int
	
#define ON  1
#define OFF 0

#define TEMP_MODE 0
#define TIME_MODE 1
#define AT_MODE   2
#define PCFV_MODE 3

extern uint8_t xdata mode;

#endif
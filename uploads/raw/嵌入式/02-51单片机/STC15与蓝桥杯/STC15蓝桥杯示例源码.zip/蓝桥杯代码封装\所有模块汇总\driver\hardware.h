#ifndef __HARDWARE_H__
#define __HARDWARE_H__

#include "main.h"


extern uint8_t key_value;
extern uint8_t key_state;
extern uint8_t xdata dig_buf[6][8] ;

void dig_show(void);
void led_output(uint8_t value);
void relay_buzzer(uint8_t relay, uint8_t buzzer);
void key_scan(void);

#endif
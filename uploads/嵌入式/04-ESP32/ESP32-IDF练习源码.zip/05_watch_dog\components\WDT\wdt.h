#ifndef __WDT_H__
#define __WDT_H__

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_timer.h"

/* 参数定义 */
#define TWDT_TIMEOUT_MS         3000
#define TASK_RESET_PERIOD_MS    2000
#define MAIN_DELAY_MS           10000

/* 函数声明 */
void wdt_init(uint16_t arr, uint64_t tps);  /* 初始化独立看门狗 */
void restart_timer(uint64_t timeout);       /*  */
void IRAM_ATTR wdt_isr_handler(void *arg);

#endif /* __WDT_H__ */
#ifndef __ONEWIRE_H__
#define __ONEWIRE_H__
#include <STC15F2K60S2.H>

unsigned int rd_temperature(void);
#endif
#ifndef __HARDWARE_H__
#define __HARDWARE_H__

#include "main.h"

#define key1 1
#define key2 2
#define key3 3
#define key4 4
#define nokey 0

extern uint8_t key_value;
extern uint8_t key_state;

void key_scan(void);

#endif
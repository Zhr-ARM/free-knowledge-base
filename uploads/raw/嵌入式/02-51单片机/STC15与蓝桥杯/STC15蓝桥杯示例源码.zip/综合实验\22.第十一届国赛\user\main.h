#ifndef __MAIN_H__
#define __MAIN_H__

#include <STC15F2K60S2.H>
#include "intrins.h"

#define uint8_t unsigned char
#define uint32_t unsigned int

#define ON 1
#define OFF 0

#define TIME        0
#define TEMP        1
#define LIGHT       2
#define TIME_CONFIG 3
#define TEMP_CONFIG 4
#define LED_CONFIG  5

#endif 
#ifndef __MOTOR_H__
#define __MOTOR_H__

#include "ti_msp_dl_config.h"

void motor_set(int16_t left_motor, int16_t right_motor);
int16_t myabs(int16_t x);

#endif
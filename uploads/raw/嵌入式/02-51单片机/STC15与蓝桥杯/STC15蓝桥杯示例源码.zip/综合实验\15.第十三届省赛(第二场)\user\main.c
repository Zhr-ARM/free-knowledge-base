#include "main.h"
#include "hardware.h"
#include "i2c.h"

uint8_t xdata led=0xff;
uint8_t xdata relay_flag=OFF;
uint8_t xdata buzzer_flag=OFF;
uint8_t xdata mode=MODE1;
uint32_t xdata pcfv3;
uint32_t xdata pcfv1;
uint8_t xdata pcfv1_buf;
uint32_t xdata pcfv_max=450;
uint32_t xdata pcfv_min=50;
uint32_t xdata pcfv_maxbuf=450;
uint32_t xdata pcfv_minbuf=50;
uint8_t xdata  pcfv_flag=1;
uint8_t xdata detect_flag=ON;
uint32_t xdata  distance;

uint8_t xdata time_10ms=0;
uint8_t xdata time_200ms=0;

sbit TX=P1^0;
sbit RX=P1^1;
uint32_t xdata tim_us;
uint8_t xdata dis_flag=0;
void Delay13us(void)	//@12.000MHz
{
	unsigned char data i;

	_nop_();
	_nop_();
	i = 36;
	while (--i);
}

void PCA_init(void)
{
	P_SW1&=0xcf;
	CCON=0;
	CMOD=0x01;
	CCAPM0=0x10;
}
void rd_dis(void)
{
	uint8_t i=8;
	CF=CCF0=0;
	CH=CL=0;
	CCAP0L=CCAP0H=0;
	CCAPM0|=0x01;
	CR=1;
	EA=0;
	do
	{
		TX=1;
		Delay13us();
		TX=0;
		Delay13us();
	}while(i--);
	EA=1;
	if(dis_flag)
	{
		dis_flag=0;
		distance=999;
	}
	else
	{
		distance=tim_us*0.017+0.5;
	}
}
void PCA_ire() interrupt 7
{
	CCAPM0&=0xfe;
	CR=0;
	if(CF)
	{
		dis_flag=1;
		CF=0;
	}
	else if(CCF0)
	{
		CCF0=0;
		tim_us=(int)(CCAP0H<<8)|CCAP0L;
		dis_flag=0;
	}
}

void Timer1_Init(void)		//1����@12.000MHz
{
	AUXR |= 0x40;			//��ʱ��ʱ��1Tģʽ
	TMOD &= 0x0F;			//���ö�ʱ��ģʽ
	TL1 = 0x20;				//���ö�ʱ��ʼֵ
	TH1 = 0xD1;				//���ö�ʱ��ʼֵ
	TF1 = 0;				//���TF1��־
	TR1 = 1;				//��ʱ��1��ʼ��ʱ
	ET1 = 1;				//ʹ�ܶ�ʱ��1�ж�
	EA=1;
}

void key_handle(void)
{
	if(key_value==4&&key_state==5)
	{
		if(mode==0) mode++;
		else if(mode==1) 
		{
			mode++;
		}
		else if(mode==2)
		{	
			pcfv_flag=1;
			pcfv_max=pcfv_maxbuf;
			pcfv_min=pcfv_minbuf;			
			mode=0;
		}
	}
	if(key_value==5&&key_state==5)
	{
		if(pcfv_flag==0)
			pcfv_flag=1;
		else
			pcfv_flag=0;
	}
	if(key_value==6&&key_state==5)
	{
		if(mode==MODE3)
		{
			if(pcfv_flag==1)
			{
				if(pcfv_maxbuf<=450)
					pcfv_maxbuf+=50;
				else
					pcfv_maxbuf=50;
			}
			else
			{
				if(pcfv_minbuf<=450)
					pcfv_minbuf+=50;
				else
					pcfv_minbuf=50;
			}
		}
	}
	if(key_value==7&&key_state==5)
	{
		if(mode==MODE3)
		{
			if(pcfv_flag==1)
			{
				if(pcfv_maxbuf>0)
					pcfv_maxbuf-=50;
				else
					pcfv_maxbuf=500;
			}
			else
			{
				if(pcfv_minbuf>0)
					pcfv_minbuf-=50;
				else
					pcfv_minbuf=500;
			}
		}
	}
}

void mode_select(void)
{
	if(mode==MODE1)
	{
		dig_buf[mode][0]=25;
		dig_buf[mode][5]=pcfv3/100%10+32;
		dig_buf[mode][6]=pcfv3/10%10;
		dig_buf[mode][7]=pcfv3%10;
	}
	if(mode==MODE3)
	{
		dig_buf[mode][0]=24;
		dig_buf[mode][3]=pcfv_maxbuf/100%10+32;
		dig_buf[mode][4]=pcfv_maxbuf/10%10;
		dig_buf[mode][6]=pcfv_minbuf/100%10+32;
		dig_buf[mode][7]=pcfv_minbuf/10%10;
	}
	if(mode==MODE2)
	{
		if(detect_flag==ON)
		{
			dig_buf[mode][0]=21;
			if(distance>=100)
				dig_buf[mode][5]=distance/100%10;
			else
				dig_buf[mode][5]=16;
			dig_buf[mode][6]=distance/10%10;
			dig_buf[mode][7]=distance%10;
		}
		else
		{
			dig_buf[mode][0]=21;
			dig_buf[mode][5]=10;
			dig_buf[mode][6]=10;
			dig_buf[mode][7]=10;
		}
	}
}
void detect_handle(void)
{
	if(pcfv3>=pcfv_min&&pcfv3<=pcfv_max)
	{
		detect_flag=1;
		if(distance<=20)
			pcfv1_buf=51;
		else if(distance<=80)
		{
			pcfv1_buf=(17*distance/5)-17;
		}
		else
			pcfv1_buf=255;
		pcf8591_write(pcfv1_buf);
	}
	else
	{
		detect_flag=0;
		pcf8591_write(0);
	}
}
uint8_t xdata led_flag=0;
uint8_t xdata led_time=0;
uint8_t xdata led_mode=0;
void led_handle(void)
{
	if(mode==MODE1)
		led&=~0x01;
	else
		led|=0x01;
	if(mode==MODE2)
		led&=~0x02;
	else
		led|=0x02;
	if(mode==MODE3)
		led&=~0x04;
	else
		led|=0x04;
	if(detect_flag==1)
	{
		led_flag=1;
	}
	else
	{
		led_flag=0;
		led_mode=0;
	}
	if(led_mode==1)
		led&=~0x80;
	else
		led|=0x80;
}

void main(void)
{
	pcf8591_write(255);
	Timer1_Init();
	PCA_init();
	while(1)
	{
		if(time_10ms>=10)
		{
			key_scan();
			key_handle();
			mode_select();
			led_handle();
			time_10ms=0;
		}
		if(time_200ms>=200)
		{
			pcfv3=pcf8591_read(3)/0.51+0.5;
			pcfv1=pcf8591_read(0)/0.51+0.5;
			rd_dis();
			detect_handle();
			time_200ms=0;
		}
		if(led_time>=100)
		{
			if(led_mode==1)
				led_mode=0;
			else
				led_mode=1;
			led_time=0;
		}
	}
}

void Timer1_Isr(void) interrupt 3
{
	led_output(led);
	relay_buzzer(relay_flag,buzzer_flag);
	dig_show();
	time_10ms++;
   time_200ms++;
	if(led_flag==1)
		led_time++;
}

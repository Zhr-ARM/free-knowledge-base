#ifndef __MAIN_H__
#define __MAIN_H__

#include <REGX51.H>

typedef unsigned char uint8_t;
typedef unsigned int  uint32_t;

#endif
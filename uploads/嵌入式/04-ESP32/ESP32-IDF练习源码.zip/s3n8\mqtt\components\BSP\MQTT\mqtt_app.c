/**
 * @file mqtt_app.c
 * @brief MQTT应用模块实现 (巴法云)
 */

#include <string.h>
#include <stdio.h>
#include "mqtt_app.h"
#include "esp_log.h"
#include "mqtt_client.h"
#include "cJSON.h"

static const char *TAG = "MQTT";

// MQTT客户端句柄
static esp_mqtt_client_handle_t s_mqtt_client = NULL;

// MQTT连接状态
static mqtt_status_t s_mqtt_status = MQTT_STATUS_DISCONNECTED;

// 消息回调函数
static mqtt_message_callback_t s_message_callback = NULL;

// 配置参数
static char s_broker_uri[128] = {0};
static char s_client_id[64] = {0};
static char s_username[64] = {0};
static char s_password[64] = {0};

// 巴法云主题名称 (需要用户在巴法云创建)
static char s_temp_topic[32] = "temp001";       // 温度主题
static char s_humidity_topic[32] = "hum001";    // 湿度主题
static char s_data_topic[32] = "sensor001";     // 综合数据主题

/**
 * @brief MQTT事件处理函数
 * @param handler_args 用户参数
 * @param base 事件基
 * @param event_id 事件ID
 * @param event_data 事件数据
 */
static void mqtt_event_handler(void *handler_args, esp_event_base_t base,
                                int32_t event_id, void *event_data)
{
    esp_mqtt_event_handle_t event = (esp_mqtt_event_handle_t)event_data;
    
    switch (event->event_id) {
        case MQTT_EVENT_CONNECTED:
            ESP_LOGI(TAG, "MQTT连接成功");
            s_mqtt_status = MQTT_STATUS_CONNECTED;
            break;
            
        case MQTT_EVENT_DISCONNECTED:
            ESP_LOGW(TAG, "MQTT连接断开");
            s_mqtt_status = MQTT_STATUS_DISCONNECTED;
            break;
            
        case MQTT_EVENT_SUBSCRIBED:
            ESP_LOGI(TAG, "订阅成功, msg_id=%d", event->msg_id);
            break;
            
        case MQTT_EVENT_UNSUBSCRIBED:
            ESP_LOGI(TAG, "取消订阅成功, msg_id=%d", event->msg_id);
            break;
            
        case MQTT_EVENT_PUBLISHED:
            ESP_LOGD(TAG, "消息发布成功, msg_id=%d", event->msg_id);
            break;
            
        case MQTT_EVENT_DATA:
            ESP_LOGI(TAG, "收到消息: topic=%.*s, data=%.*s",
                     event->topic_len, event->topic,
                     event->data_len, event->data);
            if (s_message_callback != NULL) {
                char topic[128] = {0};
                char data[512] = {0};
                strncpy(topic, event->topic, event->topic_len < sizeof(topic) ? event->topic_len : sizeof(topic) - 1);
                strncpy(data, event->data, event->data_len < sizeof(data) ? event->data_len : sizeof(data) - 1);
                s_message_callback(topic, data, (int)strlen(data));
            }
            break;
            
        case MQTT_EVENT_ERROR:
            ESP_LOGE(TAG, "MQTT错误事件");
            s_mqtt_status = MQTT_STATUS_FAILED;
            break;
            
        default:
            ESP_LOGD(TAG, "其他MQTT事件: %d", event->event_id);
            break;
    }
}

esp_err_t mqtt_init(const mqtt_config_params_t *config)
{
    if (config == NULL) {
        ESP_LOGE(TAG, "配置参数为空");
        return ESP_ERR_INVALID_ARG;
    }

    strncpy(s_broker_uri, config->broker_uri, sizeof(s_broker_uri) - 1);
    strncpy(s_client_id, config->client_id, sizeof(s_client_id) - 1);
    strncpy(s_username, config->username, sizeof(s_username) - 1);
    if (config->password != NULL) {
        strncpy(s_password, config->password, sizeof(s_password) - 1);
    }

    esp_mqtt_client_config_t mqtt_cfg = {0};
    
    mqtt_cfg.broker.address.uri = s_broker_uri;
    mqtt_cfg.credentials.client_id = s_client_id;
    mqtt_cfg.credentials.username = s_username;
    mqtt_cfg.credentials.authentication.password = s_password;
    mqtt_cfg.session.keepalive = config->keepalive > 0 ? config->keepalive : 120;
    mqtt_cfg.network.reconnect_timeout_ms = 5000;
    mqtt_cfg.network.timeout_ms = 10000;

    s_mqtt_client = esp_mqtt_client_init(&mqtt_cfg);
    if (s_mqtt_client == NULL) {
        ESP_LOGE(TAG, "创建MQTT客户端失败");
        return ESP_FAIL;
    }

    esp_mqtt_client_register_event(s_mqtt_client, ESP_EVENT_ANY_ID, mqtt_event_handler, NULL);

    ESP_LOGI(TAG, "MQTT初始化完成, Broker: %s", s_broker_uri);
    return ESP_OK;
}

esp_err_t mqtt_start(void)
{
    if (s_mqtt_client == NULL) {
        ESP_LOGE(TAG, "MQTT未初始化");
        return ESP_ERR_INVALID_STATE;
    }

    ESP_LOGI(TAG, "正在连接MQTT服务器...");
    s_mqtt_status = MQTT_STATUS_CONNECTING;
    
    esp_err_t ret = esp_mqtt_client_start(s_mqtt_client);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "启动MQTT连接失败: %s", esp_err_to_name(ret));
        s_mqtt_status = MQTT_STATUS_FAILED;
        return ret;
    }

    return ESP_OK;
}

esp_err_t mqtt_stop(void)
{
    if (s_mqtt_client == NULL) {
        return ESP_OK;
    }

    s_mqtt_status = MQTT_STATUS_DISCONNECTED;
    return esp_mqtt_client_stop(s_mqtt_client);
}

mqtt_status_t mqtt_get_status(void)
{
    return s_mqtt_status;
}

bool mqtt_is_connected(void)
{
    return s_mqtt_status == MQTT_STATUS_CONNECTED;
}

esp_err_t mqtt_publish(const char *topic, const char *data, int len, int qos, bool retain)
{
    if (s_mqtt_client == NULL || !mqtt_is_connected()) {
        ESP_LOGE(TAG, "MQTT未连接");
        return ESP_ERR_INVALID_STATE;
    }

    if (topic == NULL || data == NULL) {
        return ESP_ERR_INVALID_ARG;
    }

    int data_len = (len == 0) ? (int)strlen(data) : len;

    int msg_id = esp_mqtt_client_publish(s_mqtt_client, topic, data, data_len, qos, retain);
    if (msg_id < 0) {
        ESP_LOGE(TAG, "发布消息失败");
        return ESP_FAIL;
    }

    ESP_LOGD(TAG, "发布消息: topic=%s, msg_id=%d", topic, msg_id);
    return ESP_OK;
}

esp_err_t mqtt_subscribe(const char *topic, int qos)
{
    if (s_mqtt_client == NULL || !mqtt_is_connected()) {
        ESP_LOGE(TAG, "MQTT未连接");
        return ESP_ERR_INVALID_STATE;
    }

    if (topic == NULL) {
        return ESP_ERR_INVALID_ARG;
    }

    // 使用 esp_mqtt_client_subscribe_single 函数避免 _Generic 宏的类型问题
    int msg_id = esp_mqtt_client_subscribe_single(s_mqtt_client, (char *)topic, qos);
    if (msg_id < 0) {
        ESP_LOGE(TAG, "订阅主题失败: %s", topic);
        return ESP_FAIL;
    }

    ESP_LOGI(TAG, "订阅主题: %s, msg_id=%d", topic, msg_id);
    return ESP_OK;
}

esp_err_t mqtt_unsubscribe(const char *topic)
{
    if (s_mqtt_client == NULL || !mqtt_is_connected()) {
        ESP_LOGE(TAG, "MQTT未连接");
        return ESP_ERR_INVALID_STATE;
    }

    if (topic == NULL) {
        return ESP_ERR_INVALID_ARG;
    }

    int msg_id = esp_mqtt_client_unsubscribe(s_mqtt_client, topic);
    if (msg_id < 0) {
        ESP_LOGE(TAG, "取消订阅失败: %s", topic);
        return ESP_FAIL;
    }

    ESP_LOGI(TAG, "取消订阅: %s, msg_id=%d", topic, msg_id);
    return ESP_OK;
}

esp_err_t mqtt_set_message_callback(mqtt_message_callback_t callback)
{
    s_message_callback = callback;
    return ESP_OK;
}

esp_err_t mqtt_publish_temperature(float temperature)
{
    char data[32] = {0};
    snprintf(data, sizeof(data), "%.1f", temperature);
    return mqtt_publish(s_temp_topic, data, 0, 0, false);
}

esp_err_t mqtt_publish_humidity(float humidity)
{
    char data[32] = {0};
    snprintf(data, sizeof(data), "%.1f", humidity);
    return mqtt_publish(s_humidity_topic, data, 0, 0, false);
}

esp_err_t mqtt_publish_temp_humidity(float temperature, float humidity)
{
    cJSON *root = cJSON_CreateObject();
    if (root == NULL) {
        ESP_LOGE(TAG, "创建JSON对象失败");
        return ESP_FAIL;
    }

    cJSON_AddNumberToObject(root, "temperature", temperature);
    cJSON_AddNumberToObject(root, "humidity", humidity);

    char *json_str = cJSON_PrintUnformatted(root);
    cJSON_Delete(root);

    if (json_str == NULL) {
        ESP_LOGE(TAG, "JSON序列化失败");
        return ESP_FAIL;
    }

    esp_err_t ret = mqtt_publish(s_data_topic, json_str, 0, 0, false);
    
    free(json_str);
    
    return ret;
}

esp_err_t mqtt_set_temp_topic(const char *topic)
{
    if (topic == NULL) {
        return ESP_ERR_INVALID_ARG;
    }
    strncpy(s_temp_topic, topic, sizeof(s_temp_topic) - 1);
    ESP_LOGI(TAG, "温度主题设置为: %s", s_temp_topic);
    return ESP_OK;
}

esp_err_t mqtt_set_humidity_topic(const char *topic)
{
    if (topic == NULL) {
        return ESP_ERR_INVALID_ARG;
    }
    strncpy(s_humidity_topic, topic, sizeof(s_humidity_topic) - 1);
    ESP_LOGI(TAG, "湿度主题设置为: %s", s_humidity_topic);
    return ESP_OK;
}

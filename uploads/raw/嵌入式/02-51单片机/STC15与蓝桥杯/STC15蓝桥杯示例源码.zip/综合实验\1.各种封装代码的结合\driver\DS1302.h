#ifndef __DS1302_H__
#define __DS1302_H__
#include "stdint.h"
extern uint8_t ds1302_buf[];
void write_ds1302(void);
void read_ds1302(void);
#endif
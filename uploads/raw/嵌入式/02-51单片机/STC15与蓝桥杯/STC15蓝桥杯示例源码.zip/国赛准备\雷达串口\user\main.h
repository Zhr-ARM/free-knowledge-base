#ifndef __MAIN_H__
#define __MAIN_H__

#include <STC15F2K60S2.H>
#include "string.h"
#include "intrins.h"
#include <stdio.h>

#define uint8_t unsigned char
#define uint32_t unsigned int

void Delay13us(void);
extern uint8_t mode;

#endif
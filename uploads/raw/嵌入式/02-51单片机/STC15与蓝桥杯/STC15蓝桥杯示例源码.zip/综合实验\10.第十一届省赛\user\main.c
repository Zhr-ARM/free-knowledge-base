#include "main.h"
#include "hardware.h"
#include "i2c.h"

uint8_t xdata led=0xff;
uint8_t xdata relay_flag=OFF;
uint8_t xdata buzzer_flag=OFF;

uint8_t xdata at_tx_buf[3];
uint8_t xdata at_rx_buf[3];

uint8_t xdata mode=0;

uint32_t xdata pcfv = 0;
uint32_t xdata pcfv_buf = 500;
		 
uint32_t xdata cnt=0;
uint32_t xdata flag=0;

uint8_t xdata time1_10ms=0;
uint8_t xdata time1_90ms=0;
uint32_t xdata time1_5s=0;
void Timer1Init(void)		//1����@12.000MHz
{
	AUXR |= 0x40;		//��ʱ��ʱ��1Tģʽ
	TMOD &= 0x0F;		//���ö�ʱ��ģʽ
	TL1 = 0x20;		//���ö�ʱ��ֵ
	TH1 = 0xD1;		//���ö�ʱ��ֵ
	TF1 = 0;		//���TF1��־
	TR1 = 1;		//��ʱ��1��ʼ��ʱ
	
	ET1=1;
	EA=1;
}
void mode_handle(void)
{
	if(mode==U)
	{
		dig_buf[mode][0]=25;
		dig_buf[mode][5]=pcfv/100%10+32;
		dig_buf[mode][6]=pcfv/10%10;
		dig_buf[mode][7]=pcfv%10;
	}
	else if(mode==P)
	{
		dig_buf[mode][0]=24;
		dig_buf[mode][5]=pcfv_buf/100%10+32;
		dig_buf[mode][6]=pcfv_buf/10%10;
		dig_buf[mode][7]=pcfv_buf%10;
	}
	else if(mode==N)
	{
		dig_buf[mode][0]=22;
		
		if(cnt>=1000)
			dig_buf[mode][4]=cnt/1000%10;
		else
			dig_buf[mode][4]=16;
		if(cnt>=100)
			dig_buf[mode][5]=cnt/100%10;
		else
			dig_buf[mode][5]=16;
		if(cnt>=10)
			dig_buf[mode][6]=cnt/10%10;
		else
			dig_buf[mode][6]=16;
		if(cnt>=0)
			dig_buf[mode][7]=cnt%10;
		else
			dig_buf[mode][7]=16;
		
	}
}
uint8_t xdata temp=0;
uint8_t xdata buf=0;
void led_handle(void)
{
	if(pcfv<pcfv_buf) temp=1;
	else 			  temp=0;	
	if(cnt%2==1)      led&=~0x02;
	else  			  led|=0x02;
	if(buf>=3)        led&=~0x04;
}

void key_handle(void)
{
	if(key_value==12&&key_state==5)
	{
		if(++mode>=3) mode=0;
		buf=0;
	}
	else if(key_value==13&&key_state==5)
	{
		if(mode==N)
		{			
			cnt=0;
			buf=0;
		}
		else        buf++;
	}
	else if(key_value==16&&key_state==5)
	{
		if(mode==P)
		{
			if(pcfv_buf<=450)
			{
				pcfv_buf+=50;
				buf=0;
			}
			else
				pcfv_buf=0;
			at_tx_buf[0]=pcfv_buf/10;
			at24c02_write(0x00,at_tx_buf,1);
		}
		else        buf++;
	}
	else if(key_value==17&&key_state==5)
	{
		if(mode==P)
		{
			if(pcfv_buf>=50)
			{
				pcfv_buf-=50;
				buf=0;
			}
			else
				pcfv_buf=500;
			at_tx_buf[0]=pcfv_buf/10;
			at24c02_write(0x00,at_tx_buf,1);
		}
		else        buf++;
	}
}

void main(void)
{
	flag=0;
	temp=0;
	cnt=0;
	Timer1Init();
	led=0Xff;
	relay_flag=OFF;
	buzzer_flag=OFF;
	pcfv_buf=at24c02_read(0x00)*10;
	while(1)
	{
		if(time1_10ms>=10)
		{
			key_scan();
			key_handle();
			mode_handle();
			led_handle();
		    if(flag==0)
		    {
		    	if(pcfv<pcfv_buf)
		    	{
		    		cnt++;
		    		flag=1;
		    	}
		    }
		    else if(flag==1)
		    {
		    	if(pcfv>pcfv_buf)
		    	{
		    		cnt++;
		    		flag=0;
		    	}
		    }
			time1_10ms=0;
		}
		if(time1_90ms>=90)
		{
			pcfv = pcf8591_read(3)/0.51+0.5;
			time1_90ms=0;
		}
		
		if(time1_5s>=5000)
			led&=~0x01;
		else 
			led|=0x01;
		
	}
}

void Timer1_Serveice(void) interrupt 3
{
	led_output(led);
	relay_buzzer(relay_flag,buzzer_flag);
	dig_show();
	time1_10ms++;
	time1_90ms++;
	if(temp==1)
		time1_5s++;
	else
		time1_5s=0;
}

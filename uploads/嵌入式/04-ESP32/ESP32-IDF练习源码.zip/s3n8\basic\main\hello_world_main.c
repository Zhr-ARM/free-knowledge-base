/*
 * SPDX-FileCopyrightText: 2010-2022 Espressif Systems (Shanghai) CO LTD
 *
 * SPDX-License-Identifier: CC0-1.0
 */

#include <stdio.h>
#include <inttypes.h>
#include "sdkconfig.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_chip_info.h"
#include "esp_flash.h"

#include "stdio.h"
#include "string.h"

#include "usart.h"
#include "delay.h"
#include "led.h"

void uart_task(void *arg)
{
    uint8_t rx_data[200]={0};
    usart1_init();
    while (1)
    {
        //接收串口数据收到的数据长度
        int rx_bytes = uart_read_bytes(UART_NUM_1, rx_data, sizeof(rx_data)-1, 10 / portTICK_PERIOD_MS);
        if( rx_bytes > 0 )//数据长度大于0，说明接收到数据
        {
            rx_data[rx_bytes] = 0;//将串口数据的最后一个设置为0，形成字符串
            //通过串口1输出接受到的数据
            uart_write_bytes(UART_NUM_1, (const char*)"uart1 received : ", strlen("uart1 received : "));
            uart_write_bytes(UART_NUM_1, (const char*)rx_data, rx_bytes); // 修复：使用rx_bytes而不是strlen
            //UART环缓冲区刷新。丢弃UART RX缓冲区中的所有数据，准备下次接收
            uart_flush(UART_NUM_1); 
        }
        delay_ms(100);
    }
}

void app_main(void)
{
    led_init();
    printf("Hello world!\n");

    /* Print chip information */
    esp_chip_info_t chip_info;
    uint32_t flash_size;
    esp_chip_info(&chip_info);
    printf("This is %s chip with %d CPU core(s), %s%s%s%s, ",
           CONFIG_IDF_TARGET,
           chip_info.cores,
           (chip_info.features & CHIP_FEATURE_WIFI_BGN) ? "WiFi/" : "",
           (chip_info.features & CHIP_FEATURE_BT) ? "BT" : "",
           (chip_info.features & CHIP_FEATURE_BLE) ? "BLE" : "",
           (chip_info.features & CHIP_FEATURE_IEEE802154) ? ", 802.15.4 (Zigbee/Thread)" : "");

    unsigned major_rev = chip_info.revision / 100;
    unsigned minor_rev = chip_info.revision % 100;
    printf("silicon revision v%d.%d, ", major_rev, minor_rev);
    if(esp_flash_get_size(NULL, &flash_size) != ESP_OK) {
        printf("Get flash size failed");
        return;
    }

    printf("%" PRIu32 "MB %s flash\n", flash_size / (uint32_t)(1024 * 1024),
           (chip_info.features & CHIP_FEATURE_EMB_FLASH) ? "embedded" : "external");

    printf("Minimum free heap size: %" PRIu32 " bytes\n", esp_get_minimum_free_heap_size());

    // 创建串口读取任务
    xTaskCreate(uart_task, "uart_task", 4096, NULL, configMAX_PRIORITIES-1, NULL);

    for (int i = 10; i >= 0; i--) {
        printf("Restarting in %d seconds...\n", i);
        led_on();
        vTaskDelay(500);
        led_off();
        vTaskDelay(500);
    }
    printf("Restarting now.\n");
    fflush(stdout);
    esp_restart();
}

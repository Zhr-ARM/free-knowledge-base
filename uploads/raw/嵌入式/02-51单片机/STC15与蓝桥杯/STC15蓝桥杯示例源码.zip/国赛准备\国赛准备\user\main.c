#include "hardware.h"
#include "main.h"
#include "iic.h"
#include "ds1302.h"
#include "onewire.h"

uint8_t xdata led=0xff;
uint8_t xdata relay_data=ON;
uint8_t xdata beep_data=OFF;
uint8_t xdata at_write_buf[3]={20,66,99};
uint8_t xdata at_read_buf[3]={0};
uint32_t xdata pcfv_buf[3]={0,1,3};
uint32_t xdata freq;
uint32_t xdata dis;

uint32_t xdata temp=0;
uint8_t xdata mode=0;

uint8_t xdata pwm_time=0;
uint32_t xdata cnt=0;
uint32_t xdata T=20;
uint32_t xdata duty=0;
bit duty_flag=1;

uint8_t xdata time10ms=0;
uint8_t xdata time200ms=0;
uint8_t xdata time250ms=0;

sbit TX=P1^0;
sbit RX=P1^1;
bit dis_flag=0;
uint32_t xdata time_us=0;
uint32_t xdata dis=0;

uint8_t xdata uart_buf[10];
uint8_t xdata uart_tx_buf[10]={0};
uint8_t xdata index=0;
bit uart_flag=0;

void Uart1_Init(void)	//9600bps@12.000MHz
{
	SCON = 0x50;		//8λ����,�ɱ䲨����
	AUXR |= 0x01;		//����1ѡ��ʱ��2Ϊ�����ʷ�����
	AUXR |= 0x04;		//��ʱ��ʱ��1Tģʽ
	T2L = 0xC7;			//���ö�ʱ��ʼֵ
	T2H = 0xFE;			//���ö�ʱ��ʼֵ
	AUXR |= 0x10;		//��ʱ��2��ʼ��ʱ
	ES = 1;				//ʹ�ܴ���1�ж�
	EA=1;
}


void pca_init(void)
{
	P_SW1&=0xcF; //��S1_S1,S1_S0���㣬����S1(���ڣ���P3.0,P3.1
	CCON=0;		//���CCF0�жϱ�־λ
	CMOD=0X01; //����CFλ���ж�
	CCAPM0=0X10;	//�����½��ز���
}

void rd_dis(void)
{
	uint8_t xdata i=8;
	CF=CCF0=0; //���CF,CCF0��־λ
	CH=CL=0; //��pca�����װ��ֵ����
	CCAP0L=CCAP0H=0; //���㲶׽����ֵ
	CCAPM0 |= 0x01; //ʹ��ccf0�ж�
	CR=1; //����pca���п���λ
	EA=0;
	do
	{
		TX=1;
		Delay14us();
		TX=0;
		Delay14us();
	}while(i--);
	EA=1;
	if(dis_flag)
	{
		dis_flag=0;
		dis=999;
	}
	else 
	{
		dis=time_us*0.017+0.5;
	}
}

void Timer1_Init(void)		//1����@12.000MHz
{
	AUXR |= 0x40;			//��ʱ��ʱ��1Tģʽ
	TMOD &= 0x0F;			//���ö�ʱ��ģʽ
	TL1 = 0x20;				//���ö�ʱ��ʼֵ
	TH1 = 0xD1;				//���ö�ʱ��ʼֵ
	TF1 = 0;				//���TF1��־
	TR1 = 1;				//��ʱ��1��ʼ��ʱ
	
	ET1=1;
	EA=1;
}

void key_handle(void)
{
	if(key_value==10&&key_state==5)
		led=0x00;
	else if(key_value==11&&key_state==5)
		led=0xff;
	else if(key_value==9&&key_state==5)
	{
		if(++mode>=7)
			mode=0;
		at_read_buf[0]=at24c02_read(0x01);
		at_read_buf[1]=at24c02_read(0x02);
		at_read_buf[2]=at24c02_read(0x03);
	}
}

void Timer0_Init(void)		//100΢��@12.000MHz
{
	TMOD &= 0xF0;			//���ö�ʱ��ģʽ
	TMOD |= 0x04;
	TL0 = 0x00;				//���ö�ʱ��ʼֵ
	TH0 = 0x00;				//���ö�ʱ��ʼֵ
	TF0 = 0;				//���TF0��־
	TR0 = 1;				//��ʱ��0��ʼ��ʱ
}

void ne555_detect(void)
{
	uint32_t xdata ne555_temp=0;
	TR0=0;
	
	ne555_temp = TL0 | ((uint32_t) TH0 << 8);
	
	TL0=0X00;
	TH0=0X00;
	
	TR0=1;
	
	freq=ne555_temp*5;
}

void dig_handle(void)
{
	dig_buf[TIME_READ][0]=ds1302_buf[0]/0x10;
	dig_buf[TIME_READ][1]=ds1302_buf[0]%0x10;
	dig_buf[TIME_READ][2]=17;
	dig_buf[TIME_READ][3]=ds1302_buf[1]/0x10;
	dig_buf[TIME_READ][4]=ds1302_buf[1]%0x10;
	dig_buf[TIME_READ][5]=17;
	dig_buf[TIME_READ][6]=ds1302_buf[2]/0x10;
	dig_buf[TIME_READ][7]=ds1302_buf[2]%0x10;
	
	dig_buf[TEMP_READ][4]=temp/1000%10;
	dig_buf[TEMP_READ][5]=temp/100%10+32;
	dig_buf[TEMP_READ][6]=temp/10%10;
	dig_buf[TEMP_READ][7]=temp%10;
	
	dig_buf[PCFV_READ][0]=pcfv_buf[0]/100%10+32;
	dig_buf[PCFV_READ][1]=pcfv_buf[0]/10%10;
	dig_buf[PCFV_READ][2]=17;
	dig_buf[PCFV_READ][3]=pcfv_buf[1]/100%10+32;
	dig_buf[PCFV_READ][4]=pcfv_buf[1]/10%10;
	dig_buf[PCFV_READ][5]=17;
	dig_buf[PCFV_READ][6]=pcfv_buf[2]/100%10+32;
	dig_buf[PCFV_READ][7]=pcfv_buf[2]/10%10;
	
	dig_buf[AT_READ][0]=at_read_buf[0]/10;
	dig_buf[AT_READ][1]=at_read_buf[0]%10;
	dig_buf[AT_READ][2]=17;
	dig_buf[AT_READ][3]=at_read_buf[1]/10;
	dig_buf[AT_READ][4]=at_read_buf[1]%10;
	dig_buf[AT_READ][5]=17;
	dig_buf[AT_READ][6]=at_read_buf[2]/10;
	dig_buf[AT_READ][7]=at_read_buf[2]%10;
	
	dig_buf[FREQ_READ][0]=freq/10000%10;
	dig_buf[FREQ_READ][1]=freq/1000%10;
	dig_buf[FREQ_READ][2]=freq/100%10;
	dig_buf[FREQ_READ][3]=freq/10%10;
	dig_buf[FREQ_READ][4]=freq%10;

	dig_buf[DIS_READ][4]=dis/1000%10;
	dig_buf[DIS_READ][5]=dis/100%10+32;
	dig_buf[DIS_READ][6]=dis/10%10;
	dig_buf[DIS_READ][7]=dis%10;
	
	dig_buf[UART_RECV][0]=uart_buf[0];
	dig_buf[UART_RECV][1]=uart_buf[1];
	dig_buf[UART_RECV][2]=uart_buf[2];
	dig_buf[UART_RECV][3]=uart_buf[3];
	dig_buf[UART_RECV][4]=uart_buf[4];
	dig_buf[UART_RECV][5]=uart_buf[5];
	dig_buf[UART_RECV][6]=uart_buf[6];
	dig_buf[UART_RECV][7]=uart_buf[7];
}

void pwm_control(void)
{
	if(++cnt>=T)
		cnt=0;
	if(cnt<duty)
		led&=~0x20;
	else 
		led|=0x20;
	if(++pwm_time>=100)
	{
		if(duty_flag==0)
			duty--;
		else 
			duty++;
		if(duty==0)
			duty_flag=1;
		else if(duty==20)
			duty_flag=0;
		pwm_time=0;
	}
}
void main(void)
{
	P2&=0x1F;
	rd_temperature();
	Delay14us();
	ds1302_write();
	pcf8591_write(120);
	at24c02_write(at_write_buf,3,0x01);
	Timer1_Init();
	Timer0_Init();
	pca_init();
	Uart1_Init();
	SendString("Hello world");
    while(1)
    {
		if(time10ms>=10)
		{
			key_scan();
			key_handle();
			dig_handle();
			time10ms=0;
		}
		if(time200ms>=200)
		{
			temp=rd_temperature();
			ds1302_read();
			pcfv_buf[0]=pcfv8591_read(0)/0.51 + 0.5;
			pcfv_buf[1]=pcfv8591_read(1)/0.51 + 0.5;
			pcfv_buf[2]=pcfv8591_read(3)/0.51 + 0.5;
			
			ne555_detect();
			time200ms=0;
		}
		if(time250ms>=250)
		{
			rd_dis();
			time250ms=0;
		}
		if(uart_flag==1&&index!=0)
		{
			strcpy(uart_tx_buf, uart_buf);  // Copies uart_buf into uart_tx_buf
			SendString(uart_tx_buf);
			uart_flag=0;
		}
    }
}

void Timer1_Isr(void) interrupt 3
{
	time10ms++;
	time200ms++;
	time250ms++;
	led_control(led);
	beep_relay(beep_data,relay_data);
	dig_show();
	pwm_control();
}

void Delay14us(void)	//@12.000MHz
{
	unsigned char data i;

	_nop_();
	_nop_();
	i = 39;
	while (--i);
}

void pca_ire(void) interrupt 7
{
	CCAPM0&=~0X01;
	CR=0;
	
	if(CF)
	{
		dis_flag=1;
		CF=0;
	}
	else if(CCF0)

	
	{
		CCF0=0;
		dis_flag=0;
		time_us=(int)(CCAP0H<<8)|CCAP0L;
	}
}

void Uart1_Isr(void) interrupt 4
{
	if (RI)				//��⴮��1�����ж�
	{
		if(SBUF!='\n')
			uart_buf[index++]=SBUF;
		else
		{
			uart_flag=1;
		}
		RI = 0;			//�������1�����ж�����λ
	}
}
void SendByte(uint8_t dat)
{
	ES=0;
	SBUF=dat;
	while(TI==0);
		TI=0;
	ES=1;
}

void SendString(uint8_t *dat)
{
	while(*dat!='\0')
	{
		SendByte(*dat++);
	}
	index=0;
}
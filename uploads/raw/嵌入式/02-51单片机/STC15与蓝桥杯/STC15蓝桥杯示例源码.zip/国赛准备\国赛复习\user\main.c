#include "main.h"
#include "hardware.h"
#include "i2c.h"
#include "onewire.h"
#include "ds1302.h"

uint8_t xdata led=0xff;
uint8_t xdata beep_value=OFF;
uint8_t xdata relay_value=OFF;
uint32_t xdata temp;
uint32_t xdata pcfv1=0;
uint32_t xdata pcfv2=0;
uint32_t xdata pcfv3=0;
uint8_t xdata at_write_buf[3]={21,12,54};
uint8_t xdata at_read_buf[3]={0};

uint8_t xdata mode=0;

uint8_t xdata time10ms;
uint8_t xdata time200ms;

uint32_t xdata cnt=0;
uint32_t xdata T=20;
uint32_t xdata dat=0;
uint8_t xdata pwm_time=0;
bit pwm_flag=0;
void Timer1_Init(void)		//1����@12.000MHz
{
	AUXR |= 0x40;			//��ʱ��ʱ��1Tģʽ
	TMOD &= 0x0F;			//���ö�ʱ��ģʽ
	TL1 = 0x20;				//���ö�ʱ��ʼֵ
	TH1 = 0xD1;				//���ö�ʱ��ʼֵ
	TF1 = 0;				//���TF1��־
	TR1 = 1;				//��ʱ��1��ʼ��ʱ
	ET1 = 1;				//ʹ�ܶ�ʱ��1�ж�
	
	EA=1;
}

void key_handle(void)
{
	if(key_value==7&&key_state==5)
		led=0x00;
	else if(key_value==6&&key_state==5)
		led=0xff;
	else if(key_value==5&&key_state==5)
	{
		at_read_buf[0]=at24c02_read(0x00);
		at_read_buf[1]=at24c02_read(0x01);
		at_read_buf[2]=at24c02_read(0x02);
		if(++mode>=4)
			mode=0;
	}
}

void mode_select(void)
{
	if(mode==TEMP_MODE)
	{
		dig_buf[TEMP_MODE][4]=temp/1000%10;
		dig_buf[TEMP_MODE][5]=temp/100%10+32;
		dig_buf[TEMP_MODE][6]=temp/10%10;
		dig_buf[TEMP_MODE][7]=temp%10;
	}
	else if(mode==PCFV_MODE)
	{
		dig_buf[PCFV_MODE][0]=pcfv1/100%10+32;
		dig_buf[PCFV_MODE][1]=pcfv1/10%10;

		dig_buf[PCFV_MODE][3]=pcfv2/100%10+32;
		dig_buf[PCFV_MODE][4]=pcfv2/10%10;

		dig_buf[PCFV_MODE][6]=pcfv3/100%10+32;
		dig_buf[PCFV_MODE][7]=pcfv3/10%10;
	}
	else if(mode==TIME_MODE)
	{
		dig_buf[TIME_MODE][0]=ds1302_buf[0]/0x10;
		dig_buf[TIME_MODE][1]=ds1302_buf[0]%0x10;
		dig_buf[TIME_MODE][2]=17;
		dig_buf[TIME_MODE][3]=ds1302_buf[1]/0x10;
		dig_buf[TIME_MODE][4]=ds1302_buf[1]%0x10;
		dig_buf[TIME_MODE][5]=17;
		dig_buf[TIME_MODE][6]=ds1302_buf[2]/0x10;
		dig_buf[TIME_MODE][7]=ds1302_buf[2]%0x10;
	}
	else if (mode==AT_MODE)
	{
		dig_buf[AT_MODE][0]=at_read_buf[0]/10%10;
		dig_buf[AT_MODE][1]=at_read_buf[0]%10;

		dig_buf[AT_MODE][3]=at_read_buf[1]/10%10;
		dig_buf[AT_MODE][4]=at_read_buf[1]%10;

		dig_buf[AT_MODE][6]=at_read_buf[2]/10%10;
		dig_buf[AT_MODE][7]=at_read_buf[2]%10;
	}
}

void pwm_control(void)
{
	if(cnt++>=T)
		cnt=0;
	if(cnt>dat)
		led&=~0x04;
	else
		led|=0x04;
	if(pwm_time>=200)
	{
		pwm_time=0;
		if(pwm_flag==1)
			dat--;
		else if(pwm_flag==0)
			dat++;
		if(dat>T)
			pwm_flag=1;
		else if(dat==0)
			pwm_flag=0;
	}
}
void main(void)
{
	P2&=0x1F;
	Timer1_Init();
	ds1302_write();
	pcf8591_write(120);
	at24c02_write(0x00,at_write_buf,3);
	while(1)
	{
		if(time10ms>=10)
		{
			key_scan();
			key_handle();
			
			time10ms=0;
		}
		if(time200ms>=200)
		{
			temp=rd_temperature();
			pcfv1=pcf8591_read(0)/0.51+0.5;
			pcfv2=pcf8591_read(1)/0.51+0.5;
			pcfv3=pcf8591_read(3)/0.51+0.5;
			ds1302_read();
			mode_select();
			time200ms=0;
		}
	}
}
void Timer1_Isr(void) interrupt 3
{
	time10ms++;
	time200ms++;
	pwm_time++;
	led_control(led);
	beep_relay(beep_value,relay_value);
	dig_show();
	pwm_control();
}

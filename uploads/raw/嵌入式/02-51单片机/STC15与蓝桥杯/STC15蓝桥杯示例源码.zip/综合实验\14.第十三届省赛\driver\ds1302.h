#ifndef __DS1302_H__
#define __DS1302_H__

#include "main.h"

void ds1302_read(void);
void ds1302_write(void);

extern uint8_t ds1302_buf[3];

#endif 
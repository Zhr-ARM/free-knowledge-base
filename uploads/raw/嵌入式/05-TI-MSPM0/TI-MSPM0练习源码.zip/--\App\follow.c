#include "follow.h"

uint8_t detect[9]={0};
int8_t detect_number[8]={-2,-1,-1,-1,1,1,1,2};
void light_detect(void)//���߸ߵ�ƽ����
{
	if(DL_GPIO_readPins(LIGHT_DETECT_OUT1_PORT,LIGHT_DETECT_OUT1_PIN)==0)
	{
		detect[0]=0;
	}
	else
	{
		detect[0]=1;
	}
	if(DL_GPIO_readPins(LIGHT_DETECT_OUT2_PORT,LIGHT_DETECT_OUT2_PIN)==0)
	{
		detect[1]=0;
	}
	else
	{
		detect[1]=1;
	}
		if(DL_GPIO_readPins(LIGHT_DETECT_OUT3_PORT,LIGHT_DETECT_OUT3_PIN)==0)
	{
		detect[2]=0;
	}
	else
	{
		detect[2]=1;
	}
	if(DL_GPIO_readPins(LIGHT_DETECT_OUT4_PORT,LIGHT_DETECT_OUT4_PIN)==0)
	{
		detect[3]=0;
	}
	else
	{
		detect[3]=1;
	}
		if(DL_GPIO_readPins(LIGHT_DETECT_OUT5_PORT,LIGHT_DETECT_OUT5_PIN)==0)
	{
		detect[4]=0;
	}
	else
	{
		detect[4]=1;
	}
		if(DL_GPIO_readPins(LIGHT_DETECT_OUT6_PORT,LIGHT_DETECT_OUT6_PIN)==0)
	{
		detect[5]=0;
	}
	else
	{
		detect[5]=1;
	}
	
		if(DL_GPIO_readPins(LIGHT_DETECT_OUT7_PORT,LIGHT_DETECT_OUT7_PIN)==0)
	{
		detect[6]=0;
	}
	else
	{
		detect[6]=1;
	}
	if(DL_GPIO_readPins(LIGHT_DETECT_OUT8_PORT,LIGHT_DETECT_OUT8_PIN)==0)
	{
		detect[7]=0;
	}
	else
	{
		detect[7]=1;
	}
	if(DL_GPIO_readPins(GPIOA,DL_GPIO_PIN_2)==0)
	{
		detect[8]=0;
	}
	else
	{
		detect[8]=1;
	}

}
int8_t delta=0;
void detect_handle(void)
{
	int8_t i=0;
	delta = 0;
	for(i = 0;i<8;i++)
	{
		delta+=detect_number[i]*detect[i];
	}
}
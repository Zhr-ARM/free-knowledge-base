#include "driver/gpio.h"
#include "led.h"

/**
 * @brief 初始化LED引脚
 * @note  配置GPIO为输出模式，无上拉/下拉，无中断
 */
void led_init(void)
{
    gpio_config_t led_config;
    led_config.pin_bit_mask = (1ULL << LED_PIN);
    led_config.mode = GPIO_MODE_OUTPUT;
    led_config.pull_up_en = GPIO_PULLUP_DISABLE;
    led_config.pull_down_en = GPIO_PULLDOWN_DISABLE;
    led_config.intr_type = GPIO_INTR_DISABLE;
    gpio_config(&led_config);
    // gpio_reset_pin(LED_PIN); // 复位引脚
    // gpio_set_direction(LED_PIN, GPIO_MODE_OUTPUT); // 设置引脚为输出
}

/**
 * @brief 点亮LED
 * @note  将LED引脚置为高电平
 */
void led_on(void)
{
    gpio_set_level(LED_PIN, 1); // 设置引脚电平为高，点亮LED
}

/**
 * @brief 熄灭LED
 * @note  将LED引脚置为低电平
 */
void led_off(void)
{
    gpio_set_level(LED_PIN, 0); // 设置引脚电平为低，熄灭LED
}

/**
 * @brief 翻转LED状态
 * @note  若LED当前熄灭则点亮，反之熄灭
 */
void led_toggle(void)
{
    if(gpio_get_level(LED_PIN)==0)
        gpio_set_level(LED_PIN,1);
    if(gpio_get_level(LED_PIN)==1)
        gpio_set_level(LED_PIN,0);
}
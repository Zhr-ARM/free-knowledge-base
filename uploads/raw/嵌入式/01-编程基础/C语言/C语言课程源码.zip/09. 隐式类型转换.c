#include <stdio.h>

int main()
{
    char c = 'A';
    short s = 100;
    int i = 200;
    float f = 3.14f;
    double d = 2.718;
    
    // char和int类型运算，char自动转换成int
    int result1 = c + i;	//65+200 = 265
    
    //short和int运算 --> int
    int result2 = s + i;	//100+200=300
    
    // int  float -> float
    float result3 = i + f;	//200.0+3.14 = 203.14
    
    //float double -> double
    double result4 = f + d;	//3.14 + 2.718 = 5.858
    
    printf("result1 = %d\n", result1);
    printf("result2 = %d\n", result2);
    printf("result3 = %f\n", result3);
    printf("result4 = %f\n", result4);
    
    
    return 0;
}
#include "main.h"
#include "onewire.h"
#include "hardware.h"
#include "ds1302.h"

uint8_t xdata led=0xff;
uint8_t xdata relay_flag=OFF;
uint8_t xdata buzzer_flag=OFF;
uint32_t xdata temp;
uint8_t xdata mode=MODE1;

uint8_t xdata time_10ms;
uint8_t xdata time_200ms;
void Timer1Init(void)		//1����@12.000MHz
{
	AUXR |= 0x40;		//��ʱ��ʱ��1Tģʽ
	TMOD &= 0x0F;		//���ö�ʱ��ģʽ
	TL1 = 0x20;		//���ö�ʱ��ֵ
	TH1 = 0xD1;		//���ö�ʱ��ֵ
	TF1 = 0;		//���TF1��־
	TR1 = 1;		//��ʱ��1��ʼ��ʱ
	
	ET1=1;
	EA=1;
}
uint8_t xdata temp_buf=23;
uint8_t xdata time_flag=0;
void mode_select(void)
{
	if(mode==MODE1)
	{
		dig_buf[mode][0]=25;
		dig_buf[mode][1]=1;
		
		dig_buf[mode][5]=temp/1000%10;
		dig_buf[mode][6]=temp/100%10+32;
		dig_buf[mode][7]=temp/10%10;
	}
	else if(mode==MODE2)
	{
		dig_buf[mode][0]=25;
		dig_buf[mode][1]=2;
		if(time_flag==0)
		{
			dig_buf[mode][3]=ds1302_buf[0]/0x10;
			dig_buf[mode][4]=ds1302_buf[0]%0x10;
			dig_buf[mode][5]=17;
			dig_buf[mode][6]=ds1302_buf[1]/0x10;
			dig_buf[mode][7]=ds1302_buf[1]%0x10;
		}
		else
		{
			dig_buf[mode][3]=ds1302_buf[1]/0x10;
			dig_buf[mode][4]=ds1302_buf[1]%0x10;
			dig_buf[mode][5]=17;
			dig_buf[mode][6]=ds1302_buf[2]/0x10;
			dig_buf[mode][7]=ds1302_buf[2]%0x10;
		}
	}
	else if(mode==MODE3)
	{
		dig_buf[mode][0]=25;
		dig_buf[mode][1]=3;
		
		dig_buf[mode][6]=temp_buf/10%10;
		dig_buf[mode][7]=temp_buf%10;
	}
}
uint8_t xdata relay_mode=0;
void key_handle(void)
{
	if(key_value==12&&key_state==5)
	{
		if(++mode>=3) mode=0;
	}
    if(key_value==16&&key_state==5)
	{
		if(mode==MODE3)
		{
			if(temp_buf<99)
				temp_buf++;
			else
				temp_buf=10;
		}
	}
   if(key_value==17&&key_state==5)
	{
		if(mode==MODE3)
		{
			if(temp_buf>10)
			  temp_buf--;
			else
				temp_buf=99;
		}
	}
   if(key_value==17)
	{
		if(mode==MODE2)
		{
			time_flag=1;
		}
	}
	else
		time_flag=0;
	if(key_value==13&&key_state==5)
	{
		if(relay_mode==0)
		{
			relay_mode=1;
			relay_flag=OFF;
		}
		else
		{
			relay_mode=0;
			relay_flag=OFF;
		}
	}
}

uint32_t xdata relay_time=0;
uint8_t xdata relay_buf=0;
void relay_handle(void)
{
	if(relay_mode==0)
	{
		if(temp>temp_buf*100)
		{
			relay_flag=ON;
			relay_buf=1;
		}
		else
		{
			relay_flag=OFF;
			relay_buf=0;
		}
	}
	else
	{
		if(((ds1302_buf[1]/0x10)==0)&&((ds1302_buf[1]%0x10)==0)&&((ds1302_buf[2]/0x10)==0)&&((ds1302_buf[2]%0x10)==0))
		{
			relay_buf=1;
			relay_flag=ON;
		}
	}
}

uint8_t xdata led_buf=0;
uint32_t xdata led_time=0;
uint8_t xdata led_flag=0;
uint8_t xdata led_relaytime=0;
uint8_t xdata led_relayflag=0;
void led_handle(void)
{
	if(relay_mode==0)
		led&=~0x02;
	else
		led|=0x02;
	if(((ds1302_buf[1]/0x10)==0)&&((ds1302_buf[1]%0x10)==0)&&((ds1302_buf[2]/0x10)==0)&&((ds1302_buf[2]%0x10)==0))
	{
		led_buf=1;
		led&=~0x01;
	}
	if(relay_buf==1)
	{
		led_relayflag=1;
		if(led_flag==1)
			led&=~0x04;
		else
			led|=0x04;
	}
	else
	{
		led_relayflag=0;
		led|=0x04;
	}
}

void main(void)
{
	
	rd_temperature();
	P2&=0x1F;
	Timer1Init();
	ds1302_write();
	while(1)
	{
		if(time_10ms>=10)
		{
			key_scan();
			key_handle();
			mode_select();
			relay_handle();
			led_handle();
			time_10ms=0;
		}
		if(time_200ms>=200)
		{
			
			ds1302_read();
			temp=rd_temperature();
			time_200ms=0;
		}
		if(relay_time>=5000)
		{
			relay_flag=OFF;
			relay_time=0;
			relay_buf=0;
		}
		if(led_time>=5000)
		{
			led|=0x01;
			led_buf=0;
			led_time=0;
		}
		if(led_relaytime>=100)
		{
			if(led_flag==1)
				led_flag=0;
			else
				led_flag=1;
			led_relaytime=0;
		}
	}
}

void Time1Serveice(void) interrupt 3
{
	led_output(led);
	relay_buzzer(relay_flag,buzzer_flag);
	dig_show();
	time_10ms++;
	time_200ms++;
	if(relay_buf==1)
		relay_time++;
	if(led_buf==1)
		led_time++;
	if(led_relayflag==1)
		led_relaytime++;
}



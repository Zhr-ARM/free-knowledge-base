/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: clark_test.h
 *
 * Code generated for Simulink model 'clark_test'.
 *
 * Model version                  : 1.8
 * Simulink Coder version         : 25.2 (R2025b) 28-Jul-2025
 * C/C++ source code generated on : Thu Jan  1 21:16:48 2026
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex-M
 * Code generation objectives:
 *    1. Execution efficiency
 *    2. RAM efficiency
 * Validation result: Not run
 */

#ifndef clark_test_h_
#define clark_test_h_
#ifndef clark_test_COMMON_INCLUDES_
#define clark_test_COMMON_INCLUDES_
#include "rtwtypes.h"
#endif                                 /* clark_test_COMMON_INCLUDES_ */

/* Block signals and states (default storage) for system '<Root>' */
typedef struct {
  real_T DiscreteTimeIntegrator_DSTATE;/* '<S3>/Discrete-Time Integrator' */
} DW;

/* External outputs (root outports fed by signals with default storage) */
typedef struct {
  real32_T ialpha;                     /* '<Root>/ialpha' */
  real32_T ibeta;                      /* '<Root>/ibeta' */
} ExtY;

/* Block signals and states (default storage) */
extern DW rtDW;

/* External outputs (root outports fed by signals with default storage) */
extern ExtY rtY;

/*
 * Exported Global Signals
 *
 * Note: Exported global signals are block signals with an exported global
 * storage class designation.  Code generation will declare the memory for
 * these signals and export their symbols.
 *
 */
extern real32_T ia;                    /* '<S3>/Trigonometric Function' */
extern real32_T ib;                    /* '<S3>/Trigonometric Function1' */
extern real32_T ic;                    /* '<S3>/Trigonometric Function2' */

/* Model entry point functions */
extern void clark_test_initialize(void);
extern void clark_test_step(void);

/*-
 * These blocks were eliminated from the model due to optimizations:
 *
 * Block '<S3>/Scope' : Unused code path elimination
 */

/*-
 * The generated code includes comments that allow you to trace directly
 * back to the appropriate location in the model.  The basic format
 * is <system>/block_name, where system is the system number (uniquely
 * assigned by Simulink) and block_name is the name of the block.
 *
 * Note that this particular code originates from a subsystem build,
 * and has its own system numbers different from the parent model.
 * Refer to the system hierarchy for this subsystem below, and use the
 * MATLAB hilite_system command to trace the generated code back
 * to the parent model.  For example,
 *
 * hilite_system('clark/clark_test')    - opens subsystem clark/clark_test
 * hilite_system('clark/clark_test/Kp') - opens and selects block Kp
 *
 * Here is the system hierarchy for this model
 *
 * '<Root>' : 'clark'
 * '<S1>'   : 'clark/clark_test'
 * '<S2>'   : 'clark/clark_test/Clark transform'
 * '<S3>'   : 'clark/clark_test/ThreeCurrGenerator'
 */
#endif                                 /* clark_test_h_ */

/*
 * File trailer for generated code.
 *
 * [EOF]
 */

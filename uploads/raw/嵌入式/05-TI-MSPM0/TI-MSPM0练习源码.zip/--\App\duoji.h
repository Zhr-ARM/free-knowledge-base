#ifndef __DUOJI_H__
#define __DUOJI_H__


#include "ti_msp_dl_config.h"
#include "system.h"

void x_duoji_control(uint16_t value);
void y_duoji_control(uint16_t value);

#endif
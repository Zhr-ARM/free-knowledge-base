#ifndef __HARDWARE_H__
#define __HARDWARE_H__
#include <STC15F2K60S2.H>
extern unsigned char key_value;
extern unsigned char key_state;
void key_scan();
#endif

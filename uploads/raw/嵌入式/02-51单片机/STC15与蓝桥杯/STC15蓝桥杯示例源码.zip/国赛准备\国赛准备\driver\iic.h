#ifndef __IIC_H__
#define __IIC_H__

#include "main.h"

void pcf8591_write(uint8_t value);
uint32_t pcfv8591_read(uint8_t addr);
void at24c02_write(uint8_t *dat,uint8_t len,uint8_t addr);
uint8_t at24c02_read(uint8_t addr);

#endif

#ifndef _IIC_H__
#define _IIC_H__

#include "main.h"

void pcf8591_write(uint8_t v);
uint32_t pcf8591_read(uint8_t addr);

#endif 
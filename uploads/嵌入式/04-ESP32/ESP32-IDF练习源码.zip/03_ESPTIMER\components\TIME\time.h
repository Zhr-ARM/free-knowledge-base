#ifndef __TIME_H__
#define __TIME_H__

#include "esp_timer.h"

void esptim_int_init(uint64_t tps);
void esptim_callback(void *arg);

#endif
/*
 * Academic License - for use in teaching, academic research, and meeting
 * course requirements at degree granting institutions only.  Not for
 * government, commercial, or other organizational use.
 *
 * File: clark_test.c
 *
 * Code generated for Simulink model 'clark_test'.
 *
 * Model version                  : 1.8
 * Simulink Coder version         : 25.2 (R2025b) 28-Jul-2025
 * C/C++ source code generated on : Thu Jan  1 21:16:48 2026
 *
 * Target selection: ert.tlc
 * Embedded hardware selection: ARM Compatible->ARM Cortex-M
 * Code generation objectives:
 *    1. Execution efficiency
 *    2. RAM efficiency
 * Validation result: Not run
 */

#include "clark_test.h"
#include <math.h>
#include "rtwtypes.h"
#include <float.h>

/* Exported block signals */
real32_T ia;                           /* '<S3>/Trigonometric Function' */
real32_T ib;                           /* '<S3>/Trigonometric Function1' */
real32_T ic;                           /* '<S3>/Trigonometric Function2' */

/* Block signals and states (default storage) */
DW rtDW;

/* External outputs (root outports fed by signals with default storage) */
ExtY rtY;
extern real_T rt_modd(real_T u0, real_T u1);
real_T rt_modd(real_T u0, real_T u1)
{
  real_T y;
  y = u0;
  if (u1 == 0.0) {
    if (u0 == 0.0) {
      y = u1;
    }
  } else if (u0 == 0.0) {
    y = 0.0 / u1;
  } else {
    boolean_T yEq;
    y = fmod(u0, u1);
    yEq = (y == 0.0);
    if ((!yEq) && (u1 > floor(u1))) {
      real_T q;
      q = fabs(u0 / u1);
      yEq = (fabs(q - floor(q + 0.5)) <= DBL_EPSILON * q);
    }

    if (yEq) {
      y = 0.0;
    } else if ((u0 < 0.0) != (u1 < 0.0)) {
      y += u1;
    }
  }

  return y;
}

/* Model step function */
void clark_test_step(void)
{
  real_T rtb_Sum2;

  /* Outputs for Atomic SubSystem: '<Root>/clark_test' */
  /* Math: '<S3>/Math Function' incorporates:
   *  Constant: '<S3>/Constant2'
   *  DiscreteIntegrator: '<S3>/Discrete-Time Integrator'
   */
  rtb_Sum2 = rt_modd(rtDW.DiscreteTimeIntegrator_DSTATE, 6.2831853071795862);

  /* Trigonometry: '<S3>/Trigonometric Function' incorporates:
   *  DataTypeConversion: '<S3>/Data Type Conversion2'
   *  Sum: '<S3>/Sum1'
   */
  ia = sinf((real32_T)rtb_Sum2);

  /* Trigonometry: '<S3>/Trigonometric Function1' incorporates:
   *  DataTypeConversion: '<S3>/Data Type Conversion'
   *  Sum: '<S3>/Sum'
   */
  ib = sinf((real32_T)(rtb_Sum2 - 2.0943951023931953));

  /* Trigonometry: '<S3>/Trigonometric Function2' incorporates:
   *  Constant: '<S3>/Constant5'
   *  DataTypeConversion: '<S3>/Data Type Conversion1'
   *  Sum: '<S3>/Sum2'
   */
  ic = sinf((real32_T)(rtb_Sum2 + 2.0943951023931953));

  /* Update for DiscreteIntegrator: '<S3>/Discrete-Time Integrator' */
  rtDW.DiscreteTimeIntegrator_DSTATE += 0.00062831853071795862;

  /* Outport: '<Root>/ialpha' incorporates:
   *  Gain: '<S2>/Gain'
   *  Gain: '<S2>/Gain1'
   *  Sum: '<S2>/Sum'
   *  Sum: '<S2>/Sum2'
   */
  rtY.ialpha = 0.666666687F * ia - (ib + ic) * 0.333333343F;

  /* Outport: '<Root>/ibeta' incorporates:
   *  Gain: '<S2>/Gain2'
   *  Sum: '<S2>/Sum1'
   */
  rtY.ibeta = (ib - ic) * 0.577350259F;

  /* End of Outputs for SubSystem: '<Root>/clark_test' */
}

/* Model initialize function */
void clark_test_initialize(void)
{
  /* (no initialization code required) */
}

/*
 * File trailer for generated code.
 *
 * [EOF]
 */

#include <STC15F2K60S2.H>
#include "hardware.h"
#include "onewire.h"
#include "DS1302.h"
#include "I2C.h"
/******��������******/
uint32_t time10ms=0;
uint32_t time191ms=0;
uint32_t temp=0;
uint8_t  at_temp=0;
uint8_t  pc_temp=0;
/*******��������******/

/******ѡ��ģ�麯��********/
void mode_select(void)
{
//	if(key_value==7&&key_state==2)    buzzer(ON);
//	if(key_value==6&&key_state==2)    relay(ON);
	if(key_value==5&&key_state==2)    buzzer(OFF);
	if(key_value==4&&key_state==2)    relay(ON);
	if(key_value==7&&key_state==100)  mode=0;
	if(key_value==6&&key_state==100)  mode=1;
	if(key_value==11&&key_state==100) mode=2;
	if(key_value==9&&key_state==100)  mode=3;
}
/*******ģ�鴦������*********/
void mode_solve(void)
{
	if (mode==0)
	{
		dig_buf[0][0]=10;
		dig_buf[0][4]=temp/1000;
		dig_buf[0][5]=temp/100%10+32;
		dig_buf[0][6]=temp/10%10;
		dig_buf[0][7]=temp%10;
		led=0x0f;
	}
	if (mode==1)
	{
		
		
		dig_buf[1][0]=11;
		dig_buf[1][3]=ds1302_buf[1]/0x10;
		dig_buf[1][4]=ds1302_buf[1]%0x10;
		dig_buf[1][5]=17;
		dig_buf[1][6]=ds1302_buf[2]/0x10;
		dig_buf[1][7]=ds1302_buf[2]%0x10;
		led=0xF0;
	}
	if(mode==2)
	{
		dig_buf[2][5]=at_temp/100%10;
		dig_buf[2][6]=at_temp/10%10;
		dig_buf[2][7]=at_temp%10;
	}
	if(mode==3)
	{
		dig_buf[3][5]=pc_temp/100%10;
		dig_buf[3][6]=pc_temp/10%10;
		dig_buf[3][7]=pc_temp%10;
	}
	
}


/*******��ʱ��0*******/
void Timer0Init(void)		//1����@12.000MHz
{
	AUXR |= 0x80;		//��ʱ��ʱ��1Tģʽ
	TMOD &= 0xF0;		//���ö�ʱ��ģʽ
	TL0 = 0x20;		//���ö�ʱ��ֵ
	TH0 = 0xD1;		//���ö�ʱ��ֵ
	TF0 = 0;		//���TF0��־
	TR0 = 1;		//��ʱ��0��ʼ��ʱ
	
	EA=1;
	ET0=1;
}
void Timer0Service(void) interrupt 1
{
	show_smg();
	show_led();
	time10ms++;
	time191ms++;
}

void main(void)
{
	P2&=0x1f;
	Timer0Init();
	write_ds1302();
	write_at24c02(0x44,66);
	while(1)
	{
		if(time10ms>=10)
	 {
		key_scan_all();
		mode_select();
		time10ms=0;
	 }
	    if(time191ms>=191)
	 {
		temp=rd_tempereture();
		read_ds1302();
		at_temp=read_at24c02(0x44);
		pc_temp=read_pcf8591(3);
		time191ms=0;
	 }
		mode_solve();	
	}
}
#ifndef __HARDWARE_H__
#define __HARDWARE_H__
#include "stdint.h"
extern uint8_t mode;
extern uint8_t dig_buf[4][8];
extern uint8_t led;
extern uint8_t key_value;
extern uint8_t key_state;
void show_smg(void);
void show_led(void);
void buzzer(uint8_t value);
void relay(uint8_t value);
void key_scan_all(void);
void key_scan(void);
#endif

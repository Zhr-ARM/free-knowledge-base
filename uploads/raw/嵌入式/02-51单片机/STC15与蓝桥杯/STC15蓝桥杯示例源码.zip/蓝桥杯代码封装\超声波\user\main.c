#include <STC15F2K60S2.H>
#include "main.h"
#include "intrins.h"
void dig_show(void);
uint8_t xdata time_250ms=0;
uint8_t xdata time_10ms=0;
void Timer1_Isr(void) interrupt 3
{
	time_250ms++;
	dig_show();
	time_10ms++;
}

void Timer1_Init(void)		//1����@12.000MHz
{
	AUXR |= 0x40;			//��ʱ��ʱ��1Tģʽ
	TMOD &= 0x0F;			//���ö�ʱ��ģʽ
	TL1 = 0x20;				//���ö�ʱ��ʼֵ
	TH1 = 0xD1;				//���ö�ʱ��ʼֵ
	TF1 = 0;				//���TF1��־
	TR1 = 1;				//��ʱ��1��ʼ��ʱ
	ET1 = 1;				//ʹ�ܶ�ʱ��1�ж�
	
	EA=1;
}
uint8_t code t_display[]={                       //��׼�ֿ�
//   0    1    2    3    4    5    6    7    8    9    A    B    C    D    E    F
    0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x6F,0x77,0x7C,0x39,0x5E,0x79,0x71,
//black  -     H    J    K    L    N    o   P    U     t    G    Q    r   M    y
    0x00,0x40,0x76,0x1E,0x70,0x38,0x37,0x5C,0x73,0x3E,0x78,0x3d,0x67,0x50,0x37,0x6e,
    0xBF,0x86,0xDB,0xCF,0xE6,0xED,0xFD,0x87,0xFF,0xEF,0x46};    //0. 1. 2. 3. 4. 5. 6. 7. 8. 9. -1

uint8_t code T_COM[]={0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80};      //λ��
uint8_t xdata dig_buf[8]={16,16,16,16,16,16,16,16};
void dig_show(void)
{
	static uint8_t xdata dig_com=0;
	P0=0xff;
	P2=P2&0x0F|0xC0;
	P2&=0x0F;
	
	P0=~t_display[dig_buf[dig_com]];
	P2=P2&0x0F|0xE0;
	P2&=0x0F;
	
	P0=T_COM[dig_com];
	P2=P2&0x0F|0xC0;
	P2&=0x0F;
	
	if(++dig_com>=8) dig_com=0;
}

void Delay13us(void)	//@12.000MHz
{
	unsigned char data i;

	_nop_();
	_nop_();
	i = 36;
	while (--i);
}

void pca_init(void)
{
	P_SW1&=0Xcf;
	CCON=0;
	CMOD=0x01;
	CCAPM0=0x10;
}
sbit TX=P1^0;
sbit RX=P1^1;
uint8_t xdata cnt_dis;
uint32_t xdata tim_us;
uint32_t xdata dis;
bit dis_flag;
void rd_dis(void)
{
	uint8_t xdata i=8;
	CF=CCF0=0;
	CH=CL=0;
	CCAP0L=CCAP0H=0;
	CCAPM0|=0X01;
	CR=1;
	EA=0;
	do
	{
		TX=1;
		Delay13us();
		TX=0;
		Delay13us();
	}while(i--);
	EA=1;
	if(dis_flag)
	{
		dis_flag=0;
		dis=999;
	}
	else
	{
		dis=tim_us*0.017+0.5;
	}
}

void pca_ire(void) interrupt 7
{
	CCAPM0&=~0x01;
	CR=0;
	
	if(CF)
	{
		dis_flag=1;
		CF=0;
	}
	else if(CCF0)
	{
		CCF0=0;
		dis_flag=0;
		tim_us=(int)(CCAP0H<<8)|CCAP0L;
	}
}
void main(void)
{
	P2&=0x0F;
	Timer1_Init();
	pca_init();
	while(1)
	{
		if(time_250ms>=250)
		{
			rd_dis();
			time_250ms=0;
		}
		if(time_10ms>=10)
		{
			dig_buf[0]=dis/100%10+32;
			dig_buf[1]=dis/10%10;
			dig_buf[2]=dis%10;
			time_10ms=0;
		}
	}
}

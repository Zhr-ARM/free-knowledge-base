#ifndef __ONEWIRE_H_
#define __ONEWIRE_H_

#include "main.h"
sbit DQ=P1^4;
uint rd_temp();
#endif
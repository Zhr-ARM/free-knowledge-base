#ifndef _I2C_H__
#define _I2C_H__
void write_at24c02(unsigned char addr,unsigned char dat);
unsigned char read_at24c02(unsigned char addr);
unsigned char read_pcf8591(unsigned char channle);
#endif 
/*
 * 文件名: pid2.c
 * 日期: 2025.4.13
 * 作者:ZHR
 * 描述: PID控制器实现文件，支持位置式PID算法
 * 版本: v1.0.0
 * 修改:
 *   - v1.0.0 (2025.4.13): 初始版本，实现位置式PID算法
 */

#include "pid.h"
/**
 * @brief       PID2 初始化函数
 * @param       pid: PID2 控制器句柄指针
 *              Kp: 比例系数
 *              Ki: 积分系数
 *              Kd: 微分系数
 *              output: 初始输出值
 *              LocSum: 积分项局部和
 *              min_output: 最小输出值
 *              max_output: 最大输出值
 * @note        此函数应在初始化 PID2 控制器时调用，指定比例、积分和微分系数，以及输出阈值。
 * @retval      无
 */
void pid_init(PID_HandleDef *pid, float Kp, float Ki, float Kd,
               float min_output, float max_output,float alpha)
{
    pid->Kp = Kp;
    pid->Ki = Ki;
    pid->Kd = Kd;
    pid->Error = 0.0f;
    pid->Error_1 = 0.0f;
    pid->Error_2 = 0.0f;
    pid->output = 0.0f;
    pid->LocSum = 0.0f;
    pid->min_output = min_output;
    pid->max_output = max_output;
    pid->alpha = alpha;
}

/**
 * @brief       PID2 控制函数，计算控制输出并实现积分风up保护
 * @param       setpoint: 目标设定值
 *              last_output: 控制器上次的输出值
 *              pid: PID2 控制器句柄指针
 * @note        此函数根据 PID2 算法计算控制输出，使用比例、积分和微分项，并返回计算结果，
 *              同时确保输出值在指定的输出范围内。包含积分风up保护。
 * @retval      控制输出，经过 PID2 计算和范围限制
 */
float pid_result(float setpoint, float last_output, PID_HandleDef *pid,unsigned char turn_flag)
{
    pid->Error = setpoint - last_output;
	if(turn_flag==1)
	{	// 计算误差
		if( pid->Error<-180)
			pid->Error+=360;
		else if(pid->Error>180)
			pid->Error-=360;
	}
	if(turn_flag==0&&pid->Error<=1&& pid->Error>=-1)
		 pid->Error=0;  // 如果误差较小，则归零以避免微小误差影响
    // 应用防止积分风up机制（例如，限制积分和）
    pid->LocSum += pid->Error;

    // 应用积分风up保护（限制 LocSum）
    if (pid->LocSum > pid->max_output / pid->Ki) {
        pid->LocSum = pid->max_output / pid->Ki;  // 如果 LocSum 超过最大输出限制，则限制其值
    } else if (pid->LocSum < pid->min_output / pid->Ki) {
        pid->LocSum = pid->min_output / pid->Ki;  // 如果 LocSum 超过最小输出限制，则限制其值
    }
	if(turn_flag==1&&pid->Error<1&&pid->Error>-1)
	{
		pid->output = 0.05 * pid->Error
                  + pid->Ki * pid->LocSum
                  + pid->Kd * (pid->Error - pid->Error_1);
	}
//	if(turn_flag==1&&pid->Error<15&&pid->Error>-15)
//	{
//		pid->output = 0.1 * pid->Error
//                  + pid->Ki * pid->LocSum
//                  + pid->Kd * (pid->Error - pid->Error_1);
//	}
//	else if(turn_flag==1&&pid->Error<30&&pid->Error>-30)
//	{
//		pid->output = 0.3 * pid->Error
//                  + pid->Ki * pid->LocSum
//                  + pid->Kd * (pid->Error - pid->Error_1);
//	}
//	else if(turn_flag==1&&pid->Error<45&&pid->Error>-45)
//	{
//		pid->output = 0.35 * pid->Error
//                  + pid->Ki * pid->LocSum
//                  + pid->Kd * (pid->Error - pid->Error_1);
//	}
//	else if(turn_flag==1&&pid->Error<60&&pid->Error>-60)
//	{
//		pid->output = 0.45 * pid->Error
//                  + pid->Ki * pid->LocSum
//                  + pid->Kd * (pid->Error - pid->Error_1);
//	}

    // 计算 PID 输出，并进行滤波处理
	else
	{
    pid->output = pid->Kp * pid->Error
                  + pid->Ki * pid->LocSum
                  + pid->Kd * (pid->Error - pid->Error_1);
    }
    // 使用 alpha 进行输出滤波，减少输出波动
    pid->output = pid->alpha * pid->output + (1 - pid->alpha) * last_output;

    // 存储前一次的误差，用于下次微分计算
    pid->Error_1 = pid->Error;

    // 应用附加保护，防止输出超过最小/最大范围
    if (pid->output > pid->max_output) {
        pid->output = pid->max_output;
    } else if (pid->output < pid->min_output) {
        pid->output = pid->min_output;
    }

    // 可选：可以应用积分衰减，使积分项随时间衰减
    // 这对于当误差较小并且系统接近稳态时尤其有用
    if (ABS(pid->Error) < 0.01f) {  // 当误差很小时，轻微衰减积分项
        pid->LocSum *= 0.95f;  // 衰减率（可调）
    }

    return pid->output;  // 返回计算后的并已限制的输出
}





#ifndef __SMG_H__
#define __SMG_H__
unsigned char code t_display[];
unsigned char code T_COM[];
unsigned char smg_buf[];

void show_smg();
#endif
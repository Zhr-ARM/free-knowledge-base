#include <stdio.h>

int main()
{
    int num = 123;
    char name[] = "张三";
    
    printf("没有宽度控制：\n");
    printf("%d\n", num);
    printf("%s\n", name);
    
    printf("\n有宽度控制（宽度为6）：\n");
    printf("%6d\n", num);
    printf("%-6d\n", num);
    printf("%06s\n", name);
    
    return 0;
}
#include "pwm.h"
#include <STC15F2K60S2.H>
extern unsigned char led_buf;
void led_output(void)
{
	P0=led_buf;
	P2=P2&0x1f|0x80;
	P2&=0x1f;
}
#ifndef __PID2_H__
#define __PID2_H__

#define ABS(x)       (((x) > 0) ? (x) : (-(x)))


typedef struct
{
    float Kp;                   // Proportional gain
    float Ki;                   // Integral gain
    float Kd;                   // Derivative gain
    float Error;                // Current error
    float Error_1;           // Last error1
    float Error_2;            // Last error2
    float LocSum;             // Integral term
    float output;              // Output value
    float max_output;           // Maximum output limit
    float min_output;           // Minimum output limit
	float alpha;
} PID_HandleDef;

void pid_init(PID_HandleDef *pid, float Kp, float Ki, float Kd,
               float min_output, float max_output,float alpha);

float pid_result(float setpoint, float last_output, PID_HandleDef *pid,unsigned char turn_flag);

#endif // __PID2_H__

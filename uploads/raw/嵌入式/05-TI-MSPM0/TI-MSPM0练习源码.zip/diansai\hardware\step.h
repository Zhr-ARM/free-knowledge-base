#ifndef __STEP_H__
#define __STEP_H__

#include "ti_msp_dl_config.h"

void Step1_turn(int16_t value,int16_t speed);
void Step2_turn(int16_t value,int16_t speed);

#endif
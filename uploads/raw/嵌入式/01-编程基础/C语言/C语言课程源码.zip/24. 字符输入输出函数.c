#include <stdio.h>

int main()
{
    char ch;
    
    //printf("%c\n", ch);
//    putchar(ch);
//    putchar('\n');
//    
//    putchar('l');
//    putchar('x');
//    putchar('\n');

	ch = getchar();
    putchar(ch);
    putchar('\n');
    
    return 0;
}
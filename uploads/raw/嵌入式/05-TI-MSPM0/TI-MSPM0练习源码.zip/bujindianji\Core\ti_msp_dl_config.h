/*
 * Copyright (c) 2023, Texas Instruments Incorporated - http://www.ti.com
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ============ ti_msp_dl_config.h =============
 *  Configured MSPM0 DriverLib module declarations
 *
 *  DO NOT EDIT - This file is generated for the MSPM0G350X
 *  by the SysConfig tool.
 */
#ifndef ti_msp_dl_config_h
#define ti_msp_dl_config_h

#define CONFIG_MSPM0G350X
#define CONFIG_MSPM0G3507

#if defined(__ti_version__) || defined(__TI_COMPILER_VERSION__)
#define SYSCONFIG_WEAK __attribute__((weak))
#elif defined(__IAR_SYSTEMS_ICC__)
#define SYSCONFIG_WEAK __weak
#elif defined(__GNUC__)
#define SYSCONFIG_WEAK __attribute__((weak))
#endif

#include <ti/devices/msp/msp.h>
#include <ti/driverlib/driverlib.h>
#include <ti/driverlib/m0p/dl_core.h>

#ifdef __cplusplus
extern "C" {
#endif

/*
 *  ======== SYSCFG_DL_init ========
 *  Perform all required MSP DL initialization
 *
 *  This function should be called once at a point before any use of
 *  MSP DL.
 */


/* clang-format off */

#define POWER_STARTUP_DELAY                                                (16)


#define GPIO_HFXT_PORT                                                     GPIOA
#define GPIO_HFXIN_PIN                                             DL_GPIO_PIN_5
#define GPIO_HFXIN_IOMUX                                         (IOMUX_PINCM10)
#define GPIO_HFXOUT_PIN                                            DL_GPIO_PIN_6
#define GPIO_HFXOUT_IOMUX                                        (IOMUX_PINCM11)
#define CPUCLK_FREQ                                                     80000000



/* Defines for motor */
#define motor_INST                                                         TIMA0
#define motor_INST_IRQHandler                                   TIMA0_IRQHandler
#define motor_INST_INT_IRQN                                     (TIMA0_INT_IRQn)
#define motor_INST_CLK_FREQ                                             20000000
/* GPIO defines for channel 0 */
#define GPIO_motor_C0_PORT                                                 GPIOA
#define GPIO_motor_C0_PIN                                          DL_GPIO_PIN_8
#define GPIO_motor_C0_IOMUX                                      (IOMUX_PINCM19)
#define GPIO_motor_C0_IOMUX_FUNC                     IOMUX_PINCM19_PF_TIMA0_CCP0
#define GPIO_motor_C0_IDX                                    DL_TIMER_CC_0_INDEX
/* GPIO defines for channel 1 */
#define GPIO_motor_C1_PORT                                                 GPIOA
#define GPIO_motor_C1_PIN                                          DL_GPIO_PIN_9
#define GPIO_motor_C1_IOMUX                                      (IOMUX_PINCM20)
#define GPIO_motor_C1_IOMUX_FUNC                     IOMUX_PINCM20_PF_TIMA0_CCP1
#define GPIO_motor_C1_IDX                                    DL_TIMER_CC_1_INDEX



/* Defines for UART_0 */
#define UART_0_INST                                                        UART0
#define UART_0_INST_FREQUENCY                                            4000000
#define UART_0_INST_IRQHandler                                  UART0_IRQHandler
#define UART_0_INST_INT_IRQN                                      UART0_INT_IRQn
#define GPIO_UART_0_RX_PORT                                                GPIOA
#define GPIO_UART_0_TX_PORT                                                GPIOA
#define GPIO_UART_0_RX_PIN                                        DL_GPIO_PIN_11
#define GPIO_UART_0_TX_PIN                                        DL_GPIO_PIN_10
#define GPIO_UART_0_IOMUX_RX                                     (IOMUX_PINCM22)
#define GPIO_UART_0_IOMUX_TX                                     (IOMUX_PINCM21)
#define GPIO_UART_0_IOMUX_RX_FUNC                      IOMUX_PINCM22_PF_UART0_RX
#define GPIO_UART_0_IOMUX_TX_FUNC                      IOMUX_PINCM21_PF_UART0_TX
#define UART_0_BAUD_RATE                                                (115200)
#define UART_0_IBRD_4_MHZ_115200_BAUD                                        (2)
#define UART_0_FBRD_4_MHZ_115200_BAUD                                       (11)
/* Defines for UART_2 */
#define UART_2_INST                                                        UART2
#define UART_2_INST_FREQUENCY                                            4000000
#define UART_2_INST_IRQHandler                                  UART2_IRQHandler
#define UART_2_INST_INT_IRQN                                      UART2_INT_IRQn
#define GPIO_UART_2_RX_PORT                                                GPIOB
#define GPIO_UART_2_TX_PORT                                                GPIOB
#define GPIO_UART_2_RX_PIN                                        DL_GPIO_PIN_16
#define GPIO_UART_2_TX_PIN                                        DL_GPIO_PIN_15
#define GPIO_UART_2_IOMUX_RX                                     (IOMUX_PINCM33)
#define GPIO_UART_2_IOMUX_TX                                     (IOMUX_PINCM32)
#define GPIO_UART_2_IOMUX_RX_FUNC                      IOMUX_PINCM33_PF_UART2_RX
#define GPIO_UART_2_IOMUX_TX_FUNC                      IOMUX_PINCM32_PF_UART2_TX
#define UART_2_BAUD_RATE                                                (115200)
#define UART_2_IBRD_4_MHZ_115200_BAUD                                        (2)
#define UART_2_FBRD_4_MHZ_115200_BAUD                                       (11)
/* Defines for UART_1 */
#define UART_1_INST                                                        UART1
#define UART_1_INST_FREQUENCY                                            4000000
#define UART_1_INST_IRQHandler                                  UART1_IRQHandler
#define UART_1_INST_INT_IRQN                                      UART1_INT_IRQn
#define GPIO_UART_1_RX_PORT                                                GPIOB
#define GPIO_UART_1_TX_PORT                                                GPIOB
#define GPIO_UART_1_RX_PIN                                         DL_GPIO_PIN_5
#define GPIO_UART_1_TX_PIN                                         DL_GPIO_PIN_4
#define GPIO_UART_1_IOMUX_RX                                     (IOMUX_PINCM18)
#define GPIO_UART_1_IOMUX_TX                                     (IOMUX_PINCM17)
#define GPIO_UART_1_IOMUX_RX_FUNC                      IOMUX_PINCM18_PF_UART1_RX
#define GPIO_UART_1_IOMUX_TX_FUNC                      IOMUX_PINCM17_PF_UART1_TX
#define UART_1_BAUD_RATE                                                (115200)
#define UART_1_IBRD_4_MHZ_115200_BAUD                                        (2)
#define UART_1_FBRD_4_MHZ_115200_BAUD                                       (11)





/* Port definition for Pin Group LED_GROUP */
#define LED_GROUP_PORT                                                   (GPIOB)

/* Defines for LED_B: GPIOB.22 with pinCMx 50 on package pin 21 */
#define LED_GROUP_LED_B_PIN                                     (DL_GPIO_PIN_22)
#define LED_GROUP_LED_B_IOMUX                                    (IOMUX_PINCM50)
/* Port definition for Pin Group BEEP */
#define BEEP_PORT                                                        (GPIOA)

/* Defines for BEEP1: GPIOA.14 with pinCMx 36 on package pin 7 */
#define BEEP_BEEP1_PIN                                          (DL_GPIO_PIN_14)
#define BEEP_BEEP1_IOMUX                                         (IOMUX_PINCM36)
/* Port definition for Pin Group turn */
#define turn_PORT                                                        (GPIOA)

/* Defines for PIN_0: GPIOA.2 with pinCMx 7 on package pin 42 */
#define turn_PIN_0_PIN                                           (DL_GPIO_PIN_2)
#define turn_PIN_0_IOMUX                                          (IOMUX_PINCM7)
/* Port definition for Pin Group GPIO_GRP_0 */
#define GPIO_GRP_0_PORT                                                  (GPIOA)

/* Defines for BUT: GPIOA.17 with pinCMx 39 on package pin 10 */
#define GPIO_GRP_0_BUT_PIN                                      (DL_GPIO_PIN_17)
#define GPIO_GRP_0_BUT_IOMUX                                     (IOMUX_PINCM39)
/* Port definition for Pin Group LCD */
#define LCD_PORT                                                         (GPIOB)

/* Defines for SCL: GPIOB.9 with pinCMx 26 on package pin 61 */
#define LCD_SCL_PIN                                              (DL_GPIO_PIN_9)
#define LCD_SCL_IOMUX                                            (IOMUX_PINCM26)
/* Defines for SDA: GPIOB.8 with pinCMx 25 on package pin 60 */
#define LCD_SDA_PIN                                              (DL_GPIO_PIN_8)
#define LCD_SDA_IOMUX                                            (IOMUX_PINCM25)
/* Defines for RES: GPIOB.10 with pinCMx 27 on package pin 62 */
#define LCD_RES_PIN                                             (DL_GPIO_PIN_10)
#define LCD_RES_IOMUX                                            (IOMUX_PINCM27)
/* Defines for DC: GPIOB.11 with pinCMx 28 on package pin 63 */
#define LCD_DC_PIN                                              (DL_GPIO_PIN_11)
#define LCD_DC_IOMUX                                             (IOMUX_PINCM28)
/* Defines for BLK: GPIOB.26 with pinCMx 57 on package pin 28 */
#define LCD_BLK_PIN                                             (DL_GPIO_PIN_26)
#define LCD_BLK_IOMUX                                            (IOMUX_PINCM57)
/* Defines for CS: GPIOB.14 with pinCMx 31 on package pin 2 */
#define LCD_CS_PIN                                              (DL_GPIO_PIN_14)
#define LCD_CS_IOMUX                                             (IOMUX_PINCM31)
/* Defines for AIN1: GPIOA.28 with pinCMx 3 on package pin 35 */
#define MOTOR_AIN1_PORT                                                  (GPIOA)
#define MOTOR_AIN1_PIN                                          (DL_GPIO_PIN_28)
#define MOTOR_AIN1_IOMUX                                          (IOMUX_PINCM3)
/* Defines for AIN2: GPIOA.29 with pinCMx 4 on package pin 36 */
#define MOTOR_AIN2_PORT                                                  (GPIOA)
#define MOTOR_AIN2_PIN                                          (DL_GPIO_PIN_29)
#define MOTOR_AIN2_IOMUX                                          (IOMUX_PINCM4)
/* Defines for BIN1: GPIOA.30 with pinCMx 5 on package pin 37 */
#define MOTOR_BIN1_PORT                                                  (GPIOA)
#define MOTOR_BIN1_PIN                                          (DL_GPIO_PIN_30)
#define MOTOR_BIN1_IOMUX                                          (IOMUX_PINCM5)
/* Defines for BIN2: GPIOA.31 with pinCMx 6 on package pin 39 */
#define MOTOR_BIN2_PORT                                                  (GPIOA)
#define MOTOR_BIN2_PIN                                          (DL_GPIO_PIN_31)
#define MOTOR_BIN2_IOMUX                                          (IOMUX_PINCM6)
/* Defines for E1A: GPIOB.0 with pinCMx 12 on package pin 47 */
#define MOTOR_E1A_PORT                                                   (GPIOB)
// pins affected by this interrupt request:["E1A","E1B","E2A","E2B"]
#define MOTOR_INT_IRQN                                          (GPIOB_INT_IRQn)
#define MOTOR_INT_IIDX                          (DL_INTERRUPT_GROUP1_IIDX_GPIOB)
#define MOTOR_E1A_IIDX                                       (DL_GPIO_IIDX_DIO0)
#define MOTOR_E1A_PIN                                            (DL_GPIO_PIN_0)
#define MOTOR_E1A_IOMUX                                          (IOMUX_PINCM12)
/* Defines for E1B: GPIOB.1 with pinCMx 13 on package pin 48 */
#define MOTOR_E1B_PORT                                                   (GPIOB)
#define MOTOR_E1B_IIDX                                       (DL_GPIO_IIDX_DIO1)
#define MOTOR_E1B_PIN                                            (DL_GPIO_PIN_1)
#define MOTOR_E1B_IOMUX                                          (IOMUX_PINCM13)
/* Defines for E2A: GPIOB.2 with pinCMx 15 on package pin 50 */
#define MOTOR_E2A_PORT                                                   (GPIOB)
#define MOTOR_E2A_IIDX                                       (DL_GPIO_IIDX_DIO2)
#define MOTOR_E2A_PIN                                            (DL_GPIO_PIN_2)
#define MOTOR_E2A_IOMUX                                          (IOMUX_PINCM15)
/* Defines for E2B: GPIOB.3 with pinCMx 16 on package pin 51 */
#define MOTOR_E2B_PORT                                                   (GPIOB)
#define MOTOR_E2B_IIDX                                       (DL_GPIO_IIDX_DIO3)
#define MOTOR_E2B_PIN                                            (DL_GPIO_PIN_3)
#define MOTOR_E2B_IOMUX                                          (IOMUX_PINCM16)
/* Defines for STP1: GPIOB.17 with pinCMx 43 on package pin 14 */
#define STEP_STP1_PORT                                                   (GPIOB)
#define STEP_STP1_PIN                                           (DL_GPIO_PIN_17)
#define STEP_STP1_IOMUX                                          (IOMUX_PINCM43)
/* Defines for EN1: GPIOB.12 with pinCMx 29 on package pin 64 */
#define STEP_EN1_PORT                                                    (GPIOB)
#define STEP_EN1_PIN                                            (DL_GPIO_PIN_12)
#define STEP_EN1_IOMUX                                           (IOMUX_PINCM29)
/* Defines for DIR1: GPIOA.0 with pinCMx 1 on package pin 33 */
#define STEP_DIR1_PORT                                                   (GPIOA)
#define STEP_DIR1_PIN                                            (DL_GPIO_PIN_0)
#define STEP_DIR1_IOMUX                                           (IOMUX_PINCM1)
/* Defines for STP2: GPIOB.18 with pinCMx 44 on package pin 15 */
#define STEP_STP2_PORT                                                   (GPIOB)
#define STEP_STP2_PIN                                           (DL_GPIO_PIN_18)
#define STEP_STP2_IOMUX                                          (IOMUX_PINCM44)
/* Defines for DIR2: GPIOA.1 with pinCMx 2 on package pin 34 */
#define STEP_DIR2_PORT                                                   (GPIOA)
#define STEP_DIR2_PIN                                            (DL_GPIO_PIN_1)
#define STEP_DIR2_IOMUX                                           (IOMUX_PINCM2)
/* Defines for EN2: GPIOB.13 with pinCMx 30 on package pin 1 */
#define STEP_EN2_PORT                                                    (GPIOB)
#define STEP_EN2_PIN                                            (DL_GPIO_PIN_13)
#define STEP_EN2_IOMUX                                           (IOMUX_PINCM30)
/* Defines for OUT1: GPIOB.20 with pinCMx 48 on package pin 19 */
#define LIGHT_DETECT_OUT1_PORT                                           (GPIOB)
#define LIGHT_DETECT_OUT1_PIN                                   (DL_GPIO_PIN_20)
#define LIGHT_DETECT_OUT1_IOMUX                                  (IOMUX_PINCM48)
/* Defines for OUT2: GPIOA.22 with pinCMx 47 on package pin 18 */
#define LIGHT_DETECT_OUT2_PORT                                           (GPIOA)
#define LIGHT_DETECT_OUT2_PIN                                   (DL_GPIO_PIN_22)
#define LIGHT_DETECT_OUT2_IOMUX                                  (IOMUX_PINCM47)
/* Defines for OUT3: GPIOB.25 with pinCMx 56 on package pin 27 */
#define LIGHT_DETECT_OUT3_PORT                                           (GPIOB)
#define LIGHT_DETECT_OUT3_PIN                                   (DL_GPIO_PIN_25)
#define LIGHT_DETECT_OUT3_IOMUX                                  (IOMUX_PINCM56)
/* Defines for OUT4: GPIOB.24 with pinCMx 52 on package pin 23 */
#define LIGHT_DETECT_OUT4_PORT                                           (GPIOB)
#define LIGHT_DETECT_OUT4_PIN                                   (DL_GPIO_PIN_24)
#define LIGHT_DETECT_OUT4_IOMUX                                  (IOMUX_PINCM52)
/* Defines for OUT5: GPIOA.25 with pinCMx 55 on package pin 26 */
#define LIGHT_DETECT_OUT5_PORT                                           (GPIOA)
#define LIGHT_DETECT_OUT5_PIN                                   (DL_GPIO_PIN_25)
#define LIGHT_DETECT_OUT5_IOMUX                                  (IOMUX_PINCM55)
/* Defines for OUT6: GPIOA.24 with pinCMx 54 on package pin 25 */
#define LIGHT_DETECT_OUT6_PORT                                           (GPIOA)
#define LIGHT_DETECT_OUT6_PIN                                   (DL_GPIO_PIN_24)
#define LIGHT_DETECT_OUT6_IOMUX                                  (IOMUX_PINCM54)
/* Defines for OUT7: GPIOA.27 with pinCMx 60 on package pin 31 */
#define LIGHT_DETECT_OUT7_PORT                                           (GPIOA)
#define LIGHT_DETECT_OUT7_PIN                                   (DL_GPIO_PIN_27)
#define LIGHT_DETECT_OUT7_IOMUX                                  (IOMUX_PINCM60)
/* Defines for OUT8: GPIOA.26 with pinCMx 59 on package pin 30 */
#define LIGHT_DETECT_OUT8_PORT                                           (GPIOA)
#define LIGHT_DETECT_OUT8_PIN                                   (DL_GPIO_PIN_26)
#define LIGHT_DETECT_OUT8_IOMUX                                  (IOMUX_PINCM59)
/* Defines for R: GPIOA.7 with pinCMx 14 on package pin 49 */
#define RGB_R_PORT                                                       (GPIOA)
#define RGB_R_PIN                                                (DL_GPIO_PIN_7)
#define RGB_R_IOMUX                                              (IOMUX_PINCM14)
/* Defines for B: GPIOB.21 with pinCMx 49 on package pin 20 */
#define RGB_B_PORT                                                       (GPIOB)
#define RGB_B_PIN                                               (DL_GPIO_PIN_21)
#define RGB_B_IOMUX                                              (IOMUX_PINCM49)
/* Defines for G: GPIOA.18 with pinCMx 40 on package pin 11 */
#define RGB_G_PORT                                                       (GPIOA)
#define RGB_G_PIN                                               (DL_GPIO_PIN_18)
#define RGB_G_IOMUX                                              (IOMUX_PINCM40)
/* Port definition for Pin Group KEY */
#define KEY_PORT                                                         (GPIOB)

/* Defines for KEY1: GPIOB.27 with pinCMx 58 on package pin 29 */
#define KEY_KEY1_PIN                                            (DL_GPIO_PIN_27)
#define KEY_KEY1_IOMUX                                           (IOMUX_PINCM58)
/* Defines for KEY2: GPIOB.23 with pinCMx 51 on package pin 22 */
#define KEY_KEY2_PIN                                            (DL_GPIO_PIN_23)
#define KEY_KEY2_IOMUX                                           (IOMUX_PINCM51)



/* clang-format on */

void SYSCFG_DL_init(void);
void SYSCFG_DL_initPower(void);
void SYSCFG_DL_GPIO_init(void);
void SYSCFG_DL_SYSCTL_init(void);
void SYSCFG_DL_SYSCTL_CLK_init(void);
void SYSCFG_DL_motor_init(void);
void SYSCFG_DL_UART_0_init(void);
void SYSCFG_DL_UART_2_init(void);
void SYSCFG_DL_UART_1_init(void);

void SYSCFG_DL_SYSTICK_init(void);

bool SYSCFG_DL_saveConfiguration(void);
bool SYSCFG_DL_restoreConfiguration(void);

#ifdef __cplusplus
}
#endif

#endif /* ti_msp_dl_config_h */

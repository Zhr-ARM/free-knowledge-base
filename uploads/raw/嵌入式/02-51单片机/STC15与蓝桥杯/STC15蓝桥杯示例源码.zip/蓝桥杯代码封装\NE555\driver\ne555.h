#ifndef __NE555_H__
#define __NE555_H__

extern unsigned int time_200ms;
extern unsigned int ne555_freq;
void Timer0Init(void);
void ne555_dect(void);

#endif
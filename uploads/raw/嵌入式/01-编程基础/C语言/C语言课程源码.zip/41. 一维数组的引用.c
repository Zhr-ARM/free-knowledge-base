#include <stdio.h>

int main()
{
    int scores[5] = {85, 92, 78, 96, 88};
    int index = 2;
    
    printf("第一个学生的成绩：%d\n", scores[5]);
    printf("第二个学生的成绩：%d\n", scores[-1]);
    
    printf("scores[%d] = %d\n", index, scores[index]);
    printf("scores[%d] = %d\n", index+2, scores[index+2]);
    
    scores[1] = 95;
    printf("[修改后]第二个学生的成绩：%d\n", scores[1]);
    
    return 0;
}
#ifndef __FOLLOW_H__
#define __FOLLOW_H__

#include "ti_msp_dl_config.h"

extern int8_t delta;
extern uint8_t detect[8];
void light_detect(void);
void detect_handle(void);

#endif
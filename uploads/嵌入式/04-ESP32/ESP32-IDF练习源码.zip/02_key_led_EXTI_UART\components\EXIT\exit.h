#ifndef __EXIT_H__
#define __EXIT_H__

#include "driver/gpio.h"

#define KEY1_INT_GPIO_PIN GPIO_NUM_0
#define KEY1 gpio_get_level(KEY1_INT_GPIO_PIN)
void exit_init(void);

#endif
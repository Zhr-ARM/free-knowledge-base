#include "dht11.h"
#include "delay_us.h"
#include "stm32f1xx_hal.h"
#include "FreeRTOS.h"
#include "task.h"

/*============================================================================
 *                         GPIO 操作抽象层
 *===========================================================================*/

/**
 * @brief  设置GPIO为输出模式
 * @param  dev: 设备句柄指针
 */
static void DHT11_SetOutput(DHT11_Handle_t *dev)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    GPIO_InitStruct.Pin = dev->pin;
    GPIO_InitStruct.Mode = GPIO_MODE_OUTPUT_PP;
    GPIO_InitStruct.Speed = GPIO_SPEED_FREQ_HIGH;
    HAL_GPIO_Init(dev->port, &GPIO_InitStruct);
}

/**
 * @brief  设置GPIO为输入模式（上拉）
 * @param  dev: 设备句柄指针
 */
static void DHT11_SetInput(DHT11_Handle_t *dev)
{
    GPIO_InitTypeDef GPIO_InitStruct = {0};

    GPIO_InitStruct.Pin = dev->pin;
    GPIO_InitStruct.Mode = GPIO_MODE_INPUT;
    GPIO_InitStruct.Pull = GPIO_PULLUP;
    HAL_GPIO_Init(dev->port, &GPIO_InitStruct);
}

/**
 * @brief  写GPIO电平
 * @param  dev: 设备句柄指针
 * @param  level: 0=低电平, 1=高电平
 */
static void DHT11_WritePin(DHT11_Handle_t *dev, uint8_t level)
{
    if (level)
    {
        HAL_GPIO_WritePin(dev->port, dev->pin, GPIO_PIN_SET);
    }
    else
    {
        HAL_GPIO_WritePin(dev->port, dev->pin, GPIO_PIN_RESET);
    }
}

/**
 * @brief  读GPIO电平
 * @param  dev: 设备句柄指针
 * @retval 0=低电平, 1=高电平
 */
static uint8_t DHT11_ReadPin(DHT11_Handle_t *dev)
{
    return HAL_GPIO_ReadPin(dev->port, dev->pin) == GPIO_PIN_SET ? 1 : 0;
}

/*============================================================================
 *                         等待函数（带超时）
 *===========================================================================*/

/**
 * @brief  等待GPIO变为指定电平
 * @param  dev: 设备句柄指针
 * @param  level: 目标电平 (0=低电平, 1=高电平)
 * @param  timeout_us: 超时时间（微秒）
 * @retval 0=成功, 非0=超时
 */
static uint8_t DHT11_WaitForLevel(DHT11_Handle_t *dev, uint8_t level, uint32_t timeout_us)
{
    uint32_t count = 0;

    while (DHT11_ReadPin(dev) != level)
    {
        if (++count > timeout_us)
        {
            return 1;
        }
        delay_us(1);
    }
    return 0;
}

/**
 * @brief  测量高电平持续时间
 * @param  dev: 设备句柄指针
 * @param  timeout_us: 超时时间（微秒）
 * @retval 高电平持续时间（微秒），超时返回0
 */
static uint32_t DHT11_MeasureHighPulse(DHT11_Handle_t *dev, uint32_t timeout_us)
{
    uint32_t count = 0;

    while (DHT11_ReadPin(dev) == 1)
    {
        if (++count > timeout_us)
        {
            return 0;
        }
        delay_us(1);
    }
    return count;
}

/*============================================================================
 *                         DHT11 核心功能
 *===========================================================================*/

/**
 * @brief  初始化DHT11传感器
 * @param  dev: 设备句柄指针
 * @retval 0: 成功, 非0: 失败
 */
uint8_t DHT11_Init(DHT11_Handle_t *dev)
{
    if (!dev) return 1;

    DHT11_SetOutput(dev);
    DHT11_WritePin(dev, 1);

    delay_us(1000000);

    return 0;
}

/**
 * @brief  读取DHT11温湿度数据
 * @param  dev: 设备句柄指针
 * @param  data: 温湿度数据结构体指针
 * @retval 0: 成功, 非0: 失败
 */
uint8_t DHT11_ReadData(DHT11_Handle_t *dev, DHT11_Data_t *data)
{
    uint8_t buffer[5] = {0};
    uint8_t i, j;
    uint32_t pulse_width;
    uint8_t result = 0;

    if (!dev || !data) return 1;

    DHT11_SetOutput(dev);

    DHT11_WritePin(dev, 0);
    delay_us(DHT11_START_LOW_US);

    DHT11_WritePin(dev, 1);
    delay_us(DHT11_START_HIGH_US);

    DHT11_SetInput(dev);

    /* 进入临界区，防止FreeRTOS任务切换破坏时序 */
    taskENTER_CRITICAL();

    delay_us(40);

    if (DHT11_WaitForLevel(dev, 0, DHT11_WAIT_TIMEOUT_US) != 0)
    {
        result = 2;
        goto exit;
    }

    if (DHT11_WaitForLevel(dev, 1, DHT11_WAIT_TIMEOUT_US) != 0)
    {
        result = 3;
        goto exit;
    }

    if (DHT11_WaitForLevel(dev, 0, DHT11_WAIT_TIMEOUT_US) != 0)
    {
        result = 4;
        goto exit;
    }

    for (i = 0; i < 5; i++)
    {
        for (j = 0; j < 8; j++)
        {
            if (DHT11_WaitForLevel(dev, 1, DHT11_WAIT_TIMEOUT_US) != 0)
            {
                result = 5;
                goto exit;
            }

            pulse_width = DHT11_MeasureHighPulse(dev, DHT11_PULSE_TIMEOUT_US);
            if (pulse_width == 0)
            {
                result = 6;
                goto exit;
            }

            buffer[i] <<= 1;
            if (pulse_width > DHT11_BIT_THRESHOLD_US)
            {
                buffer[i] |= 1;
            }
        }
    }

exit:
    /* 退出临界区 */
    taskEXIT_CRITICAL();

    DHT11_SetOutput(dev);
    DHT11_WritePin(dev, 1);

    if (result != 0)
    {
        return result;
    }

    if ((uint8_t)(buffer[0] + buffer[1] + buffer[2] + buffer[3]) != buffer[4])
    {
        return 7;
    }

    data->humidity_int = buffer[0];
    data->humidity_dec = buffer[1];
    data->temperature_int = buffer[2];
    data->temperature_dec = buffer[3];

    return 0;
}

#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_system.h"
#include "nvs_flash.h"
#include "led.h"
#include "lcd.h"
#include "sensor.h"


i2c_obj_t i2c0_master;

/**
 * @brief       程序入口
 * @param       无
 * @retval      无
 */
void app_main(void)
{
    int16_t temp;
    esp_err_t ret;

    ret = nvs_flash_init();                                                     /* 初始化NVS */

    if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND)
    {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ret = nvs_flash_init();
    }

    led_init();                                                                 /* 初始化LED */
    i2c0_master = iic_init(I2C_NUM_0);                                          /* 初始化IIC0 */
    spi2_init();                                                                /* 初始化SPI2 */
    xl9555_init(i2c0_master);                                                   /* 初始化XL9555 */
    lcd_init();                                                                 /* 初始化LCD */
    temperature_sensor_init();                                                  /* 初始化内部温度传感器 */
    
    lcd_show_string(30, 50, 200, 16, 16, "ESP32", RED);
    lcd_show_string(30, 70, 200, 16, 16, "Temperature TEST", RED);
    lcd_show_string(30, 90, 200, 16, 16, "ATOM@ALIENTEK", RED);
    lcd_show_string(30, 120, 200, 16, 16, "TEMPERATE: 00.00C", BLUE);

    while(1)
    {
        temp = sensor_get_temperature();                                        /* 得到温度值 */

        if (temp < 0)
        {
            temp = -temp;
            lcd_show_string(30 + 10 * 8, 120, 16, 16, 16, "-", BLUE);           /* 显示符号 */
        }
        else
        {
            lcd_show_string(30 + 10 * 8, 120, 16, 16, 16, " ", BLUE);           /* 无符号 */
        }
        lcd_show_xnum(30 + 11 * 8, 120, temp, 2, 16, 0, BLUE);                  /* 显示整数部分 */
        lcd_show_xnum(30 + 14 * 8, 120, temp * 100 % 100, 2, 16, 0x80, BLUE);   /* 显示小数部分 */
        
        LED_TOGGLE();                                                           /* LED闪烁,提示程序运行 */
        vTaskDelay(250);
    }
}

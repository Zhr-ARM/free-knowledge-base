/**
 * @file hello_world_main.c
 * @brief 物联网温湿度监测系统主程序
 * @description 通过MQTT连接巴法云，定时上报温湿度数据
 */

#include <stdio.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_log.h"
#include "esp_system.h"
#include "esp_chip_info.h"
#include "esp_flash.h"

// BSP模块头文件
#include "wifi.h"
#include "mqtt_app.h"
#include "sensor_sim.h"
#include "led.h"
#include "delay.h"

static const char *TAG = "MAIN";

// ==================== 用户配置区域 ====================
// WiFi配置 (请修改为你的WiFi信息)
#define WIFI_SSID           "TP-LINK_E5B4"
#define WIFI_PASSWORD       "zhr13881112752"

// 巴法云配置 (请修改为你的巴法云账号信息)
// 登录 https://cloud.bemfa.com/ 获取你的账号ID
#define BEMFA_BROKER_URI    "mqtt://bemfa.com:9501"
#define BEMFA_CLIENT_ID     "48c75a1d701a9ceeffc61736b1a80b50"
#define BEMFA_USERNAME      "你的账号ID"
#define BEMFA_PASSWORD      ""

// 数据上报间隔 (毫秒)
#define PUBLISH_INTERVAL_MS 10000

// 温湿度主题 (需要在巴法云创建这些主题)
#define TEMP_TOPIC          "temperature"
#define HUMIDITY_TOPIC      "humity"
// =====================================================

/**
 * @brief MQTT消息接收回调函数
 * @param topic 主题
 * @param payload 消息内容
 * @param len 消息长度
 */
static void mqtt_message_callback(const char *topic, const char *payload, int len)
{
    ESP_LOGI(TAG, "收到MQTT消息: [%s] %s", topic, payload);
    
    if (strcmp(topic, "cmd001") == 0) {
        if (strcmp(payload, "led_on") == 0) {
            led_on();
            ESP_LOGI(TAG, "LED已打开");
        } else if (strcmp(payload, "led_off") == 0) {
            led_off();
            ESP_LOGI(TAG, "LED已关闭");
        }
    }
}

/**
 * @brief 温湿度数据上报任务
 * @param arg 任务参数
 */
static void sensor_publish_task(void *arg)
{
    sensor_data_t sensor_data;
    
    ESP_LOGI(TAG, "温湿度数据上报任务已启动");
    
    while (1) {
        if (!wifi_is_connected()) {
            ESP_LOGW(TAG, "WiFi未连接，等待重连...");
            vTaskDelay(5000 / portTICK_PERIOD_MS);
            continue;
        }
        
        if (!mqtt_is_connected()) {
            ESP_LOGW(TAG, "MQTT未连接，等待重连...");
            vTaskDelay(5000 / portTICK_PERIOD_MS);
            continue;
        }
        
        if (sensor_sim_read(&sensor_data) == ESP_OK) {
            ESP_LOGI(TAG, "温湿度数据: 温度=%.1f℃, 湿度=%.1f%%",
                     sensor_data.temperature, sensor_data.humidity);
            
            esp_err_t ret1 = mqtt_publish_temperature(sensor_data.temperature);
            esp_err_t ret2 = mqtt_publish_humidity(sensor_data.humidity);
            
            if (ret1 == ESP_OK && ret2 == ESP_OK) {
                ESP_LOGI(TAG, "数据上报成功");
                led_on();
                delay_ms(100);
                led_off();
            } else {
                ESP_LOGE(TAG, "数据上报失败");
            }
        }
        
        vTaskDelay(PUBLISH_INTERVAL_MS / portTICK_PERIOD_MS);
    }
}

/**
 * @brief 系统初始化
 * @return ESP_OK: 成功, 其他: 失败
 */
static esp_err_t system_init(void)
{
    ESP_LOGI(TAG, "系统初始化开始...");
    
    led_init();
    ESP_LOGI(TAG, "LED初始化完成");
    
    sensor_sim_init();
    ESP_LOGI(TAG, "模拟传感器初始化完成");
    
    wifi_config_params_t wifi_config = {
        .ssid = WIFI_SSID,
        .password = WIFI_PASSWORD,
        .retry_interval_ms = 5000,
        .max_retry_count = 0,
    };
    
    if (wifi_init_module(&wifi_config) != ESP_OK) {
        ESP_LOGE(TAG, "WiFi初始化失败");
        return ESP_FAIL;
    }
    ESP_LOGI(TAG, "WiFi初始化完成");
    
    ESP_LOGI(TAG, "正在连接WiFi...");
    if (wifi_start_connect() != ESP_OK) {
        ESP_LOGE(TAG, "WiFi连接失败");
        return ESP_FAIL;
    }
    
    char ip_str[16] = {0};
    if (wifi_get_ip_str(ip_str) == ESP_OK) {
        ESP_LOGI(TAG, "本机IP: %s", ip_str);
    }
    
    mqtt_config_params_t mqtt_config = {
        .broker_uri = BEMFA_BROKER_URI,
        .port = 9501,
        .client_id = BEMFA_CLIENT_ID,
        .username = BEMFA_USERNAME,
        .password = BEMFA_PASSWORD,
        .keepalive = 120,
    };
    
    if (mqtt_init(&mqtt_config) != ESP_OK) {
        ESP_LOGE(TAG, "MQTT初始化失败");
        return ESP_FAIL;
    }
    ESP_LOGI(TAG, "MQTT初始化完成");
    
    // 设置温湿度主题
    mqtt_set_temp_topic(TEMP_TOPIC);
    mqtt_set_humidity_topic(HUMIDITY_TOPIC);
    
    mqtt_set_message_callback(mqtt_message_callback);
    
    ESP_LOGI(TAG, "正在连接MQTT服务器...");
    if (mqtt_start() != ESP_OK) {
        ESP_LOGE(TAG, "MQTT连接失败");
        return ESP_FAIL;
    }
    
    ESP_LOGI(TAG, "系统初始化完成!");
    return ESP_OK;
}

/**
 * @brief 主函数
 */
void app_main(void)
{
    ESP_LOGI(TAG, "========================================");
    ESP_LOGI(TAG, "  物联网温湿度监测系统 v1.0");
    ESP_LOGI(TAG, "  平台: ESP32-S3 + 巴法云");
    ESP_LOGI(TAG, "========================================");
    
    esp_chip_info_t chip_info;
    esp_chip_info(&chip_info);
    ESP_LOGI(TAG, "芯片: %s, CPU核心数: %d", CONFIG_IDF_TARGET, chip_info.cores);
    ESP_LOGI(TAG, "WiFi%s, BLE%s",
             (chip_info.features & CHIP_FEATURE_WIFI_BGN) ? "支持" : "不支持",
             (chip_info.features & CHIP_FEATURE_BLE) ? "支持" : "不支持");
    
    if (system_init() != ESP_OK) {
        ESP_LOGE(TAG, "系统初始化失败，5秒后重启...");
        vTaskDelay(5000 / portTICK_PERIOD_MS);
        esp_restart();
    }
    
    xTaskCreate(sensor_publish_task, "sensor_task", 4096, NULL, 5, NULL);
    
    ESP_LOGI(TAG, "系统启动完成，开始上报温湿度数据...");
    ESP_LOGI(TAG, "请使用手机APP订阅主题查看数据:");
    ESP_LOGI(TAG, "  温度主题: %s", TEMP_TOPIC);
    ESP_LOGI(TAG, "  湿度主题: %s", HUMIDITY_TOPIC);
}

/**
 * @file wifi.h
 * @brief WiFi连接模块头文件
 * @description 提供WiFi连接、断线重连、状态查询等功能
 */

#ifndef __WIFI_H__
#define __WIFI_H__

#include <stdint.h>
#include <stdbool.h>
#include "esp_err.h"

/**
 * @brief WiFi连接状态枚举
 */
typedef enum {
    WIFI_STATUS_DISCONNECTED = 0,   // 未连接
    WIFI_STATUS_CONNECTING,         // 连接中
    WIFI_STATUS_CONNECTED,          // 已连接
    WIFI_STATUS_FAILED              // 连接失败
} wifi_status_t;

/**
 * @brief WiFi配置结构体
 */
typedef struct {
    const char *ssid;               // WiFi名称
    const char *password;           // WiFi密码
    uint32_t retry_interval_ms;     // 重试间隔(毫秒)
    uint8_t max_retry_count;        // 最大重试次数(0表示无限重试)
} wifi_config_params_t;

/**
 * @brief 初始化WiFi连接模块
 * @param config WiFi配置参数
 * @return ESP_OK: 成功, 其他: 失败
 */
esp_err_t wifi_init_module(const wifi_config_params_t *config);

/**
 * @brief 启动WiFi连接
 * @return ESP_OK: 成功, 其他: 失败
 */
esp_err_t wifi_start_connect(void);

/**
 * @brief 断开WiFi连接
 * @return ESP_OK: 成功, 其他: 失败
 */
esp_err_t wifi_stop_connect(void);

/**
 * @brief 获取当前WiFi连接状态
 * @return wifi_status_t 连接状态
 */
wifi_status_t wifi_get_status(void);

/**
 * @brief 检查WiFi是否已连接
 * @return true: 已连接, false: 未连接
 */
bool wifi_is_connected(void);

/**
 * @brief 获取本机IP地址字符串
 * @param ip_str 存储IP地址的缓冲区(至少16字节)
 * @return ESP_OK: 成功, 其他: 失败
 */
esp_err_t wifi_get_ip_str(char *ip_str);

#endif // __WIFI_H__

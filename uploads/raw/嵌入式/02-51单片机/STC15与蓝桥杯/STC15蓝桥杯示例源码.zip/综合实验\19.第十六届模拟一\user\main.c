#include "main.h"
#include "hardware.h"
#include "onewire.h"

uint8_t xdata led=0xff;
uint8_t xdata relay_flag=OFF;
uint8_t xdata buzzer_flag=OFF;
uint8_t xdata mode=0;
int xdata temp=0;
char xdata temp_flag=26;
char xdata temp_delta=0;
bit detect_flag=1;

uint8_t xdata time_10ms=0;
uint8_t xdata time_200ms=0;
void Timer1_Init(void)		//1����@12.000MHz
{
	AUXR |= 0x40;			//��ʱ��ʱ��1Tģʽ
	TMOD &= 0x0F;			//���ö�ʱ��ģʽ
	TL1 = 0x20;				//���ö�ʱ��ʼֵ
	TH1 = 0xD1;				//���ö�ʱ��ʼֵ
	TF1 = 0;				//���TF1��־
	TR1 = 1;				//��ʱ��1��ʼ��ʱ
	ET1 = 1;				//ʹ�ܶ�ʱ��1�ж�
}

void key_handle(void)
{
	if(key_value==4&&key_state==5)
	{
		if(++mode==3)
			mode=0;
	}
	if(key_value==5&&key_state==5)
	{
		if(detect_flag==1)
			detect_flag=0;
		else
			detect_flag=1;
	}
	if(key_value==8&&key_state==5)
	{
		if(mode==MODE2)
		{
			if(temp_delta>-99)
				temp_delta--;
			else
				temp_delta=99;
		}
		else if(mode==MODE3)
		{
			if(temp_flag>-99)
				temp_flag--;
			else
				temp_flag=99;
		}
	}
	if(key_value==9&&key_state==5)
	{
		if(mode==MODE2)
		{
			if(temp_delta<99)
				temp_delta++;
			else
				temp_delta=-99;
		}
		else if(mode==MODE3)
		{
			if(temp_flag<99)
				temp_flag++;
			else
				temp_flag=-99;
		}
	}
}

void mode_select(void)
{
	if(mode==MODE1)
	{
		dig_buf[mode][0]=12;
		dig_buf[mode][5]=temp/1000%10;
		dig_buf[mode][6]=temp/100%10+32;
		dig_buf[mode][7]=temp/10%10;
	}
	else if(mode==MODE2)
	{
		if(temp_delta>=0&&temp_delta<10)
		{
			dig_buf[mode][0]=14;
			dig_buf[mode][5]=16;
			dig_buf[mode][6]=16;
			dig_buf[mode][7]=temp_delta;
		}
		else if(temp_delta>10)
		{
			dig_buf[mode][0]=14;
			dig_buf[mode][5]=16;
			dig_buf[mode][6]=temp_delta/10%10;
			dig_buf[mode][7]=temp_delta%10;
		}
		else if(temp_delta>-10&&temp_delta<0)
		{
			dig_buf[mode][0]=14;
			dig_buf[mode][5]=16;
			dig_buf[mode][6]=17;
			dig_buf[mode][7]=-temp_delta;
		}
		else if(temp_delta<=-10)
		{
			dig_buf[mode][0]=14;
			dig_buf[mode][5]=17;
			dig_buf[mode][6]=-temp_delta/10%10;
			dig_buf[mode][7]=-temp_delta%10;
		}
	}
	else if(mode==MODE3)
	{
		
		dig_buf[mode][0]=18;
		dig_buf[mode][6]=temp_flag/10%10;
		dig_buf[mode][7]=temp_flag%10;
	}
}

void detect_handle(void)
{
	if(detect_flag==1)
	{
		if(temp>(temp_flag*100))
			led&=~0x80;
		else
			led|=0x80;
	}
	if(detect_flag==0)
	{
		if(temp<(temp_flag*100))
			led&=~0x80;
		else
			led|=0x80;
	}
}

void led_handle(void)
{
	if(mode==MODE1)
		led&=~0x01;
	else
		led|=0x01;
	if(mode==MODE2)
		led&=~0x02;
	else
		led|=0x02;
	if(mode==MODE3)
		led&=~0x04;
	else
		led|=0x04;
	if(detect_flag==1)
		led&=~0x08;
	else
		led|=0x08;
	if(detect_flag==0)
		led&=~0x10;
	else
		led|=0x10;
}

void main(void)
{
	Timer1_Init();
	rd_temperature();
	while(1)
	{
		if(time_10ms>=10)
		{
			key_scan();
			key_handle();
			mode_select();
			led_handle();
			detect_handle();
			time_10ms=0;
		}
		if(time_200ms>=200)
		{
			temp=rd_temperature()+(temp_delta*100);
			time_200ms=0;
		}
	}
}

void Timer1_Isr(void) interrupt 3
{
	led_output(led);
	relay_buzzer(relay_flag,buzzer_flag);
	dig_show();
	time_200ms++;
	time_10ms++;
}
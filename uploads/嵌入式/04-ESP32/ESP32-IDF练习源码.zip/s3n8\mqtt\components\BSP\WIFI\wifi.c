/**
 * @file wifi.c
 * @brief WiFi连接模块实现
 */

#include <string.h>
#include "wifi.h"
#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_log.h"
#include "nvs_flash.h"
#include "freertos/FreeRTOS.h"
#include "freertos/event_groups.h"

static const char *TAG = "WIFI";

// WiFi事件组
static EventGroupHandle_t s_wifi_event_group = NULL;

// 事件位定义
#define WIFI_CONNECTED_BIT      BIT0
#define WIFI_FAIL_BIT           BIT1

// 模块内部状态
static bool s_initialized = false;
static wifi_status_t s_wifi_status = WIFI_STATUS_DISCONNECTED;
static uint8_t s_retry_count = 0;
static uint8_t s_max_retry_count = 5;
static uint32_t s_retry_interval_ms = 5000;
static char s_ssid[64] = {0};
static char s_password[64] = {0};
static esp_netif_t *s_sta_netif = NULL;

/**
 * @brief WiFi事件处理函数
 */
static void wifi_event_handler(void *arg, esp_event_base_t event_base,
                                int32_t event_id, void *event_data)
{
    if (event_base == WIFI_EVENT && event_id == WIFI_EVENT_STA_START) {
        ESP_LOGI(TAG, "WiFi站点已启动");
        s_wifi_status = WIFI_STATUS_CONNECTING;
        esp_wifi_connect();
    }
    else if (event_base == WIFI_EVENT && event_id == WIFI_EVENT_STA_DISCONNECTED) {
        ESP_LOGW(TAG, "WiFi连接断开");
        
        if (s_max_retry_count == 0 || s_retry_count < s_max_retry_count) {
            s_wifi_status = WIFI_STATUS_CONNECTING;
            vTaskDelay(s_retry_interval_ms / portTICK_PERIOD_MS);
            esp_wifi_connect();
            s_retry_count++;
            ESP_LOGI(TAG, "重试连接... (第%d次)", s_retry_count);
        } else {
            s_wifi_status = WIFI_STATUS_FAILED;
            xEventGroupSetBits(s_wifi_event_group, WIFI_FAIL_BIT);
            ESP_LOGE(TAG, "WiFi连接失败，已达最大重试次数");
        }
    }
    else if (event_base == IP_EVENT && event_id == IP_EVENT_STA_GOT_IP) {
        ip_event_got_ip_t *event = (ip_event_got_ip_t *)event_data;
        ESP_LOGI(TAG, "获取到IP: " IPSTR, IP2STR(&event->ip_info.ip));
        
        s_wifi_status = WIFI_STATUS_CONNECTED;
        s_retry_count = 0;
        xEventGroupSetBits(s_wifi_event_group, WIFI_CONNECTED_BIT);
    }
}

esp_err_t wifi_init_module(const wifi_config_params_t *config)
{
    if (config == NULL) {
        ESP_LOGE(TAG, "配置参数为空");
        return ESP_ERR_INVALID_ARG;
    }

    // 如果已经初始化，直接返回成功
    if (s_initialized) {
        ESP_LOGW(TAG, "WiFi模块已初始化，跳过重复初始化");
        return ESP_OK;
    }

    // 保存配置参数
    strncpy(s_ssid, config->ssid, sizeof(s_ssid) - 1);
    strncpy(s_password, config->password, sizeof(s_password) - 1);
    s_retry_interval_ms = config->retry_interval_ms > 0 ? config->retry_interval_ms : 5000;
    s_max_retry_count = config->max_retry_count;

    // 创建事件组
    s_wifi_event_group = xEventGroupCreate();
    if (s_wifi_event_group == NULL) {
        ESP_LOGE(TAG, "创建事件组失败");
        return ESP_ERR_NO_MEM;
    }

    // 初始化NVS
    esp_err_t ret = nvs_flash_init();
    if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND) {
        ESP_LOGW(TAG, "NVS分区需要擦除");
        nvs_flash_erase();
        ret = nvs_flash_init();
    }
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "NVS初始化失败: %s", esp_err_to_name(ret));
        return ret;
    }

    // 初始化TCP/IP协议栈
    ret = esp_netif_init();
    if (ret != ESP_OK && ret != ESP_ERR_INVALID_STATE) {
        ESP_LOGE(TAG, "初始化TCP/IP协议栈失败");
        return ret;
    }

    // 创建默认事件循环
    ret = esp_event_loop_create_default();
    if (ret != ESP_OK && ret != ESP_ERR_INVALID_STATE) {
        ESP_LOGE(TAG, "创建默认事件循环失败");
        return ret;
    }

    // 使用 esp_netif_create 创建 WiFi STA 网络接口，避免重复创建
    if (s_sta_netif == NULL) {
        esp_netif_config_t sta_cfg = ESP_NETIF_DEFAULT_WIFI_STA();
        s_sta_netif = esp_netif_new(&sta_cfg);
        if (s_sta_netif == NULL) {
            ESP_LOGE(TAG, "创建WiFi STA网络接口失败");
            return ESP_FAIL;
        }
    }

    // 初始化WiFi驱动
    wifi_init_config_t cfg = WIFI_INIT_CONFIG_DEFAULT();
    ret = esp_wifi_init(&cfg);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "WiFi驱动初始化失败: %s", esp_err_to_name(ret));
        return ret;
    }

    // 注册事件处理函数
    ret = esp_event_handler_register(WIFI_EVENT, ESP_EVENT_ANY_ID, &wifi_event_handler, NULL);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "注册WiFi事件处理失败");
        return ret;
    }
    
    ret = esp_event_handler_register(IP_EVENT, IP_EVENT_STA_GOT_IP, &wifi_event_handler, NULL);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "注册IP事件处理失败");
        return ret;
    }

    // 绑定WiFi驱动到网络接口
    ret = esp_wifi_set_default_wifi_sta_handlers();
    if (ret != ESP_OK && ret != ESP_ERR_INVALID_STATE) {
        ESP_LOGE(TAG, "设置WiFi STA handlers失败: %s", esp_err_to_name(ret));
        return ret;
    }

    // 配置WiFi参数
    wifi_config_t wifi_cfg = {0};
    strncpy((char *)wifi_cfg.sta.ssid, s_ssid, sizeof(wifi_cfg.sta.ssid) - 1);
    strncpy((char *)wifi_cfg.sta.password, s_password, sizeof(wifi_cfg.sta.password) - 1);
    wifi_cfg.sta.threshold.authmode = WIFI_AUTH_WPA2_PSK;

    ret = esp_wifi_set_mode(WIFI_MODE_STA);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "设置WiFi模式失败");
        return ret;
    }
    
    ret = esp_wifi_set_config(WIFI_IF_STA, &wifi_cfg);
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "设置WiFi配置失败");
        return ret;
    }

    // 将网络接口与WiFi驱动关联
    esp_netif_attach_wifi_station(s_sta_netif);
    esp_wifi_connect();

    s_initialized = true;
    ESP_LOGI(TAG, "WiFi初始化完成, SSID: %s", s_ssid);
    return ESP_OK;
}

esp_err_t wifi_start_connect(void)
{
    if (s_wifi_event_group == NULL || !s_initialized) {
        ESP_LOGE(TAG, "WiFi未初始化");
        return ESP_ERR_INVALID_STATE;
    }

    ESP_LOGI(TAG, "正在连接WiFi: %s", s_ssid);
    s_wifi_status = WIFI_STATUS_CONNECTING;
    s_retry_count = 0;

    esp_err_t ret = esp_wifi_start();
    if (ret != ESP_OK) {
        ESP_LOGE(TAG, "启动WiFi失败: %s", esp_err_to_name(ret));
        return ret;
    }

    EventBits_t bits = xEventGroupWaitBits(s_wifi_event_group,
                                            WIFI_CONNECTED_BIT | WIFI_FAIL_BIT,
                                            pdFALSE,
                                            pdFALSE,
                                            portMAX_DELAY);

    if (bits & WIFI_CONNECTED_BIT) {
        ESP_LOGI(TAG, "WiFi连接成功");
        return ESP_OK;
    } else if (bits & WIFI_FAIL_BIT) {
        ESP_LOGE(TAG, "WiFi连接失败");
        return ESP_FAIL;
    }

    return ESP_FAIL;
}

esp_err_t wifi_stop_connect(void)
{
    s_wifi_status = WIFI_STATUS_DISCONNECTED;
    return esp_wifi_disconnect();
}

wifi_status_t wifi_get_status(void)
{
    return s_wifi_status;
}

bool wifi_is_connected(void)
{
    return s_wifi_status == WIFI_STATUS_CONNECTED;
}

esp_err_t wifi_get_ip_str(char *ip_str)
{
    if (ip_str == NULL) {
        return ESP_ERR_INVALID_ARG;
    }

    if (!wifi_is_connected() || s_sta_netif == NULL) {
        return ESP_ERR_INVALID_STATE;
    }

    esp_netif_ip_info_t ip_info;
    esp_err_t ret = esp_netif_get_ip_info(s_sta_netif, &ip_info);
    if (ret != ESP_OK) {
        return ret;
    }

    snprintf(ip_str, 16, IPSTR, IP2STR(&ip_info.ip));
    return ESP_OK;
}

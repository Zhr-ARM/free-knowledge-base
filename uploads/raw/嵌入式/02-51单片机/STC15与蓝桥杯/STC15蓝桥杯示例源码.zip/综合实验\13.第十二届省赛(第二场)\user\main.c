#include "main.h"
#include "hardware.h"
#include "i2c.h"
#include "onewire.h"

uint8_t xdata relay_flag=OFF;
uint8_t xdata buzzer_flag=OFF;
uint8_t xdata led =0xff;
uint32_t temp=0;
uint32_t pcfv=0;
uint8_t mode=D;

uint8_t xdata time_200ms;
uint8_t xdata time_10ms;
void Timer1Init(void)		//1����@12.000MHz
{
	AUXR |= 0x40;		//��ʱ��ʱ��1Tģʽ
	TMOD &= 0x0F;		//���ö�ʱ��ģʽ
	TL1 = 0x20;		//���ö�ʱ��ֵ
	TH1 = 0xD1;		//���ö�ʱ��ֵ
	TF1 = 0;		//���TF1��־
	TR1 = 1;		//��ʱ��1��ʼ��ʱ
	
	ET1=1;
	EA=1;
}
uint8_t xdata temp_flag=25;
uint8_t xdata temp_buf=25;
uint8_t xdata temp_mode=0;
void mode_select(void)
{
	if(mode==D)
	{
		dig_buf[mode][0]=12;
		dig_buf[mode][4]=temp/1000%10;
		dig_buf[mode][5]=temp/100%10+32;
		dig_buf[mode][6]=temp/10%10;
		dig_buf[mode][7]=temp%10;
	}
	else if(mode==P)
	{
		dig_buf[mode][0]=24;
		dig_buf[mode][6]=temp_buf/10%10;
		dig_buf[mode][7]=temp_buf%10;
		
	}
	else if(mode==A)
	{
		dig_buf[mode][0]=10;
		
		dig_buf[mode][5]=pcfv/100%10+32;
		dig_buf[mode][6]=pcfv/10%10;
		dig_buf[mode][7]=pcfv%10;
	}
}

void key_handle(void)
{
	if(key_value==4&&key_state==5)
	{
		if(mode==D) mode++;
		else if(mode==P) 
		{
			temp_flag=temp_buf;
			mode++;
		}
		else if(mode==A)
			mode=0;
		
	}
	else if(key_value==9&&key_state==5)
	{
		if(mode==P)
		{
			temp_buf++;
		}
	}
	else if(key_value==8&&key_state==5)
	{
		if(mode==P)
		{
			temp_buf--;
		}
	}
	else if(key_value==5&&key_state==5)
	{
		if(temp_mode==1)
			temp_mode=0;
		else
			temp_mode=1;
	}
}
float pcfv_buf;
void temp_handle(void)
{
	if(temp_mode==0)
	{
		if(temp<temp_flag*100)
			pcf8591_write(0);
		else
			pcf8591_write(5);
	}
	else if(temp_mode==1)
	{
		if(temp/100>=20)
		{
			pcfv_buf=(temp/100)*3/20-2;
			pcf8591_write(pcfv_buf);
		}
		else
			pcf8591_write(1);
	}
}
void led_handle(void)
{
	if(temp_mode==0)
		led&=~0x01;
	else
		led|=0x01;
	if(mode==D)
		led&=~0x02;
	else
		led|=0x02;
	if(mode==P)
		led&=~0x04;
	else
		led|=0x04; 
	if(mode==A)
		led&=~0x08;
	else
		led|=0x08;
}
void main(void)
{
	rd_temperature();
	P2&=0x1F;
	Timer1Init();
	
	while(1)
	{
		if(time_10ms>=10)
		{
			key_scan();
			key_handle();
			mode_select();
			temp_handle();
			led_handle();
			time_10ms=0;
		}
		if(time_200ms>=200)
		{
			pcfv=pcf8591_read(0)/0.51+0.5;
			temp=rd_temperature();
			time_200ms=0;
		}
		
	}
}

void Time1_Serveice(void) interrupt 3
{
	led_output(led);
	relay_buzzer(relay_flag,buzzer_flag);
	dig_show();
	time_10ms++;
	time_200ms++;
}

#include <stdio.h>

int main()
{
    for(int i = 0; i < 100; i++)
    {
    	printf("我命由我不由天 %d\n", i);
	}
	
	printf("循环结束！\n");
    
    return 0;
}



#ifndef  __HARDWARE_H__
#define  __HARDWARE_H__

#include "main.h"

#define uint8_t unsigned char
#define uint32_t unsigned int
#define ON 1
#define OFF 0

void led_handle(uint8_t value);
void beep_relay(uint8_t beep_value,uint8_t relay_value);
void key_scan(void);
void dig_show(void);

extern uint8_t dig_buf[][8];
extern uint8_t key_value;
extern uint8_t key_state;

#endif // ! 
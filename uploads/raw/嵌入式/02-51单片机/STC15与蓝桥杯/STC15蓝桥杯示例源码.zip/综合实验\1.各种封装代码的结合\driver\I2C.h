#ifndef __I2C_H__
#define __I2C_H__
#include "stdint.h"
void write_at24c02(uint8_t addr,uint8_t dat);
uint8_t read_at24c02(uint8_t addr);
uint8_t read_pcf8591(uint8_t channel);
#endif
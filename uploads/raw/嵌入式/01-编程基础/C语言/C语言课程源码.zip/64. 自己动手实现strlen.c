#include <stdio.h>

size_t my_strlen(const char *str)
{
	size_t length = 0;
	
	//从字符串开头开始遍历
	while(str[length] != '\0')
	{
		length++;		//每遇到一个非结束字符，长度加1
	}
	
	return length;
}

int main()
{
	char name[] = "良许";
    char *message = "欢迎学习嵌入式";
    
    printf("姓名长度: %zu\n", my_strlen(name));        // 输出可能是4（中文字符编码相关）
    printf("消息长度: %zu\n", my_strlen(message));     // 输出: 12或更多
    printf("常量长度: %zu\n", my_strlen("Hello"));     // 输出: 5
    
    return 0;
}
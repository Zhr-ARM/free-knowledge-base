/*	#   I2C代码片段说明
	1. 	本文件夹中提供的驱动代码供参赛选手完成程序设计参考。
	2. 	参赛选手可以自行编写相关代码或以该代码为基础，根据所选单片机类型、运行速度和试题
		中对单片机时钟频率的要求，进行代码调试和修改。
*/
/****自己添加部分******/
#include <STC15F2K60S2.H>
#include <intrins.h>
#include "i2c.h"

sbit scl=P2^0;
sbit sda=P2^1;
/*********************/
#define DELAY_TIME	5

//I2C总部延时函数
static void I2C_Delay(unsigned char n)
{
    do
    {
        _nop_();_nop_();_nop_();_nop_();_nop_();
        _nop_();_nop_();_nop_();_nop_();_nop_();
        _nop_();_nop_();_nop_();_nop_();_nop_();		
    }
    while(n--);      	
}

//I2C总线启动信号
void I2CStart(void)
{
    sda = 1;
    scl = 1;
	I2C_Delay(DELAY_TIME);
    sda = 0;
	I2C_Delay(DELAY_TIME);
    scl = 0;    
}

//I2C总线停止信号
void I2CStop(void)
{
    sda = 0;
    scl = 1;
	I2C_Delay(DELAY_TIME);
    sda = 1;
	I2C_Delay(DELAY_TIME);
}

//I2C总线发送一个字节数据
void I2CSendByte(unsigned char byt)
{
    unsigned char i;
	
    for(i=0; i<8; i++){
        scl = 0;
		I2C_Delay(DELAY_TIME);
        if(byt & 0x80){
            sda = 1;
        }
        else{
            sda = 0;
        }
		I2C_Delay(DELAY_TIME);
        scl = 1;
        byt <<= 1;
		I2C_Delay(DELAY_TIME);
    }
	
    scl = 0;  
}

//I2C总线接收一个字节数据
unsigned char I2CReceiveByte(void)
{
	unsigned char da;
	unsigned char i;
	for(i=0;i<8;i++){   
		scl = 1;
		I2C_Delay(DELAY_TIME);
		da <<= 1;
		if(sda) 
			da |= 0x01;
		scl = 0;
		I2C_Delay(DELAY_TIME);
	}
	return da;    
}

//等待应答
unsigned char I2CWaitAck(void)
{
	unsigned char ackbit;
	
    scl = 1;
	I2C_Delay(DELAY_TIME);
    ackbit = sda; 
    scl = 0;
	I2C_Delay(DELAY_TIME);
	
	return ackbit;
}

//发送应答或非应答信号
void I2CSendAck(unsigned char ackbit)
 {
    scl = 0;
    sda = ackbit;        //0是应答,1是非应答
	I2C_Delay(DELAY_TIME);
    scl = 1;
	I2C_Delay(DELAY_TIME);
    scl = 0; 
	sda = 1;
	I2C_Delay(DELAY_TIME);
}

//
void write_at24c02(unsigned char addr,unsigned char dat)
{
	I2CStart();         //通过发送启动条件来启动 I2C 通信。
	I2CSendByte(0xA0);  /*发送 AT24C02 的设备地址。地址通常是 0b1010xxxx，其中 xxxx 由芯片上的 A0、A1 和 A2 引脚的状态决定。
	                    如果这三个引脚都接地，地址就是 0b10100000（十六进制为 0xA0）。*/
	I2CWaitAck();        //等待 EEPROM 发送的确认（ACK）信号，表示它已准备好接收数据。
	I2CSendByte(addr);  //发送 EEPROM 中要写入数据的内存地址。
	I2CWaitAck();       //在发送内存地址后再次等待 ACK 信号。
	
	I2CSendByte(dat);   //发送要写入指定内存地址的实际数据字节。
	I2CWaitAck();       //在数据写入后等待最终的 ACK 信号。
	                          
	I2CStop();          //通过发送停止条件来终止 I2C 通信。
}
unsigned char read_at24c02(unsigned char addr)
{
	unsigned char temp; //声明一个临时变量，用于存储从 EEPROM 读取的字节数据。
	I2CStart();         //通过发送启动条件来启动 I2C 通信。
	I2CSendByte(0xA0);  /*发送 AT24C02 的设备地址，写入位设置（最低位为 0）。地址通常是 0b1010xxxx,
	                     其中 xxxx 由芯片上的 A0、A1 和 A2 引脚的状态决定。
	                     如果这三个引脚都接地，地址就是 0b10100000（十六进制为 0xA0）。*/
	I2CWaitAck();       //等待 EEPROM 发送的确认（ACK）信号，表示它已准备好接收数据。
	
	I2CSendByte(addr);  //发送 EEPROM 中要读取数据的内存地址
	I2CWaitAck();       //在发送内存地址后再次等待 ACK 信号
	
	
	I2CStart();         //发送另一个启动条件，将总线切换到读取模式
	I2CSendByte(0xA1);  /*发送 AT24C02 的设备地址，读取位设置（最低位为 1）。
	                     这是必要的，以告诉 EEPROM 主机想要从它那里读取数据。*/
	I2CWaitAck();       //等待 EEPROM 发送的 ACK 信号。
	temp = I2CReceiveByte();//从 EEPROM 读取字节数据并将其存储在 temp 变量中。
	
	I2CSendAck(1);      // 发送非确认（NACK）信号，表示主机已读完数据，不需要另一个字节。参数 1 表示应发送 NACK。
	I2CStop();          //通过发送停止条件来终止 I2C 通信。
	return temp;        //返回读取的字节数据。
}
unsigned char read_pcf8591(unsigned char channle)//写PCF8591
{
	unsigned char buf;//声明一个名为 buf 的变量，用于存储从 ADC 读取的字节数据。
	
	I2CStart();       //通过发送启动条件来启动 I2C 通信。
	I2CSendByte(0x90);/*发送 PCF8591 的设备地址，写入位设置（最低位为 0）。
	                  设备地址通常是 0b10010000，其中最后四位由芯片上的 A0、A1 和 A2 引脚的状态决定。
	                  如果这三个引脚都接地，地址就是 0b10010000（十六进制为 0x90）。*/
	I2CWaitAck();     // 等待 PCF8591 发送的确认（ACK）信号，表示它已准备好接收数据。
	
	I2CSendByte(channle | 0x40);/*发送通道号到 PCF8591，自动递增位设置（第 6 位为 1）。
	                            这允许 ADC 在需要时自动递增通道号进行后续读取。*/
	I2CWaitAck();               //在发送通道号后再次等待 ACK 信号。
	
	I2CStart();       // 发送另一个启动条件，将总线切换到读取模式。
	I2CSendByte(0x91);/*发送 PCF8591 的设备地址，读取位设置（最低位为 1）。
	                  这是必要的，以告诉 ADC 主机想要从它那里读取数据。*/
	I2CWaitAck();     //等待 PCF8591 发送的 ACK 信号。
	I2CReceiveByte(); //读取 ADC 的第一个字节数据，通常是控制字节。
	I2CSendAck(0);    //发送确认（ACK）信号，表示主机想要读取另一个字节。
	buf = I2CReceiveByte();/*读取 ADC 的第二个字节数据，
	                       即实际的 ADC 转换结果，并将其存储在 buf 变量中。*/
	I2CSendAck(1);    //发送非确认（NACK）信号，表示主机已读完数据，不需要另一个字节。
	I2CStop();        //通过发送停止条件来终止 I2C 通信。
	
	return buf;       //返回读取的字节数据，即 ADC 转换结果。
}
#ifndef __MAIN_H__
#define __MAIN_H__

#include <STC15F2K60S2.H>
#include "intrins.h"

#define uint8_t  unsigned char
#define uint32_t unsigned int

#define ON  1
#define OFF 0

#define U   0
#define P   1
#define N   2

extern uint8_t xdata mode;

#endif
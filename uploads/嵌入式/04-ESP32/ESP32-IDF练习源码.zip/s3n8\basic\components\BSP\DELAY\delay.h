#ifndef __DELAY_H__
#define __DELAY_H__

#include "esp_rom_sys.h"
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"

void delay_ms(uint32_t ms);
void delay_us(uint32_t us);

#endif // !
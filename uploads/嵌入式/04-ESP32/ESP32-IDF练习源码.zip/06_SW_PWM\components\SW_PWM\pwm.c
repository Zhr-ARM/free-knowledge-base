#include "pwm.h"

/** 
 * @brief 初始化PWM
 * @param resolution PWM分辨率
 *        freq:      PWM信号频率
 * @retval  无
 */
void pwm_init(uint8_t resolution,uint16_t freq)
{
    ledc_timer_config_t ledc_timer ={0};    /* LEDC定时器句柄*/
    ledc_channel_config_t ledc_channel = {0}; /* LEDC通道句柄 */

    /* 配置LEDC定时器 */
    ledc_timer.duty_resolution = resolution;    /*pwm占空比分辨率*/
    ledc_timer.freq_hz = freq;                   /*pwm频率*/
    ledc_timer.speed_mode = LEDC_LOW_SPEED_MODE;    /*定时器模式*/
    ledc_timer.timer_num = LEDC_PWM_TIMER;      /*定时器序号*/
    ledc_timer.clk_cfg = LEDC_AUTO_CLK;         /*时钟配置*/
    ledc_timer_config(&ledc_timer);             /*配置定时器*/

    /* 配置定时器通道 */
    ledc_channel.gpio_num = LEDC_PWM_CH0_GPIO;  /* LEDC控制器通道对应引脚*/
    ledc_channel.speed_mode = LEDC_LOW_SPEED_MODE; /*LEDC高速模式*/
    ledc_channel.channel = LEDC_PWM_CH0_CHANNEL; /*LEDC通道*/
    ledc_channel.intr_type = LEDC_INTR_DISABLE;  /*LEDC失能中断*/
    ledc_channel.timer_sel = LEDC_PWM_TIMER;     /*LEDC定时器序号*/
    ledc_channel.duty = 0;                       /*初始占空比为0*/
    ledc_channel_config(&ledc_channel);       /*配置LEDC通道*/
}

/**
 * @brief 设置PWM占空比
 * @param duty 占空比值
 * @retval  无
 */
void pwm_set_duty(uint32_t duty)
{
    ledc_set_duty(LEDC_LOW_SPEED_MODE, LEDC_PWM_CH0_CHANNEL, duty); /* 设置PWM占空比 */
    ledc_update_duty(LEDC_LOW_SPEED_MODE, LEDC_PWM_CH0_CHANNEL);    /* 更新PWM占空比 */
}
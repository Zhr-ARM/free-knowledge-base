#ifndef __DS1302_H_
#define __DS1302_H_
#include "main.h"
sbit SCK=P1^7;
sbit RST=P1^3;
sbit SDA=P2^3;

void Write_Ds1302_Byte( unsigned char address,unsigned char dat );
unsigned char Read_Ds1302_Byte( unsigned char address );

#endif
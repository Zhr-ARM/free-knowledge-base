/**
 * @file mqtt_app.h
 * @brief MQTT应用模块头文件
 * @description 提供MQTT连接巴法云、发布订阅等功能
 */

#ifndef __MQTT_APP_H__
#define __MQTT_APP_H__

#include <stdint.h>
#include <stdbool.h>
#include "esp_err.h"

/**
 * @brief MQTT连接状态枚举
 */
typedef enum {
    MQTT_STATUS_DISCONNECTED = 0,   // 未连接
    MQTT_STATUS_CONNECTING,         // 连接中
    MQTT_STATUS_CONNECTED,          // 已连接
    MQTT_STATUS_FAILED              // 连接失败
} mqtt_status_t;

/**
 * @brief MQTT配置结构体 (巴法云配置)
 */
typedef struct {
    const char *broker_uri;         // MQTT服务器地址
    uint16_t port;                  // 端口号
    const char *client_id;          // 客户端ID (巴法云使用账号ID)
    const char *username;           // 用户名 (巴法云使用账号ID)
    const char *password;           // 密码 (巴法云可为空)
    uint32_t keepalive;             // 心跳间隔(秒)
} mqtt_config_params_t;

/**
 * @brief MQTT消息回调函数类型
 * @param topic 主题
 * @param payload 消息内容
 * @param len 消息长度
 */
typedef void (*mqtt_message_callback_t)(const char *topic, const char *payload, int len);

/**
 * @brief 初始化MQTT模块
 * @param config MQTT配置参数
 * @return ESP_OK: 成功, 其他: 失败
 */
esp_err_t mqtt_init(const mqtt_config_params_t *config);

/**
 * @brief 启动MQTT连接
 * @return ESP_OK: 成功, 其他: 失败
 */
esp_err_t mqtt_start(void);

/**
 * @brief 停止MQTT连接
 * @return ESP_OK: 成功, 其他: 失败
 */
esp_err_t mqtt_stop(void);

/**
 * @brief 获取MQTT连接状态
 * @return mqtt_status_t 连接状态
 */
mqtt_status_t mqtt_get_status(void);

/**
 * @brief 检查MQTT是否已连接
 * @return true: 已连接, false: 未连接
 */
bool mqtt_is_connected(void);

/**
 * @brief 发布消息到指定主题
 * @param topic 主题名称
 * @param data 消息数据
 * @param len 消息长度 (0表示使用strlen计算)
 * @param qos QoS级别 (0, 1, 2)
 * @param retain 是否保留消息
 * @return ESP_OK: 成功, 其他: 失败
 */
esp_err_t mqtt_publish(const char *topic, const char *data, int len, int qos, bool retain);

/**
 * @brief 订阅主题
 * @param topic 主题名称
 * @param qos QoS级别 (0, 1, 2)
 * @return ESP_OK: 成功, 其他: 失败
 */
esp_err_t mqtt_subscribe(const char *topic, int qos);

/**
 * @brief 取消订阅主题
 * @param topic 主题名称
 * @return ESP_OK: 成功, 其他: 失败
 */
esp_err_t mqtt_unsubscribe(const char *topic);

/**
 * @brief 注册消息接收回调函数
 * @param callback 回调函数指针
 * @return ESP_OK: 成功, 其他: 失败
 */
esp_err_t mqtt_set_message_callback(mqtt_message_callback_t callback);

/**
 * @brief 发布温度数据到巴法云
 * @param temperature 温度值 (单位: 摄氏度)
 * @return ESP_OK: 成功, 其他: 失败
 */
esp_err_t mqtt_publish_temperature(float temperature);

/**
 * @brief 发布湿度数据到巴法云
 * @param humidity 湿度值 (单位: %)
 * @return ESP_OK: 成功, 其他: 失败
 */
esp_err_t mqtt_publish_humidity(float humidity);

/**
 * @brief 发布温湿度数据到巴法云 (JSON格式)
 * @param temperature 温度值 (单位: 摄氏度)
 * @param humidity 湿度值 (单位: %)
 * @return ESP_OK: 成功, 其他: 失败
 */
esp_err_t mqtt_publish_temp_humidity(float temperature, float humidity);

/**
 * @brief 设置温度主题
 * @param topic 主题名称
 * @return ESP_OK: 成功, 其他: 失败
 */
esp_err_t mqtt_set_temp_topic(const char *topic);

/**
 * @brief 设置湿度主题
 * @param topic 主题名称
 * @return ESP_OK: 成功, 其他: 失败
 */
esp_err_t mqtt_set_humidity_topic(const char *topic);

#endif // __MQTT_APP_H__

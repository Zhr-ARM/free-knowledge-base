#include "pwm.h"

/**
 * @brief 初始化PWM
 * @param resolution PWM分辨率
 *        freq: PWM频率
 * @retval 无
 */
void pwm_init(uint8_t resolution, uint16_t frequency)
{
    ledc_timer_config_t ledc_timer;
    ledc_channel_config_t ledc_channel;

    ledc_timer.duty_resolution = resolution; // 设置PWM分辨率
    ledc_timer.freq_hz = frequency;         // 设置PWM频率
    ledc_timer.speed_mode = LEDC_PWM_MODE;   // 设置为低速模式
    ledc_timer.timer_num = LEDC_PWM_TIMER; // 使用定时器序号
    ledc_timer.clk_cfg = LEDC_AUTO_CLK;    // 自动选择时钟源
    ledc_timer_config(&ledc_timer);

    ledc_channel.gpio_num = LEDC_PWM_CH0_GPIO;       // PWM输出引脚
    ledc_channel.speed_mode = LEDC_PWM_MODE;          // 设置为低速模式
    ledc_channel.channel = LEDC_PWM_CH0_CHANNEL;     // 设置通道
    ledc_channel.intr_type = LEDC_INTR_DISABLE;      // 禁用中断
    ledc_channel.timer_sel = LEDC_PWM_TIMER;         // 选择定时器
    ledc_channel.duty = 0;               // 设置初始占空比
    ledc_channel_config(&ledc_channel);

    ledc_fade_func_install(0);      /* 使能渐变 */
}

void pwm_set_duty(uint32_t duty)
{
    ledc_set_fade_with_time(LEDC_PWM_MODE, LEDC_PWM_CH0_CHANNEL, duty, LEDC_PWM_FADE_TIME); /* 设置占空比及渐变时长 */
    ledc_fade_start(LEDC_PWM_MODE, LEDC_PWM_CH0_CHANNEL, LEDC_FADE_NO_WAIT);                 /* 开始渐变 */
    ledc_set_fade_with_time(LEDC_PWM_MODE, LEDC_PWM_CH0_CHANNEL, 0, LEDC_PWM_FADE_TIME); /* 设置占空比及渐变时长 */
    ledc_fade_start(LEDC_PWM_MODE,LEDC_PWM_CH0_CHANNEL,LEDC_FADE_NO_WAIT);               /* 开始渐变 */
}
#ifndef __DS1302_H__
#define __DS1302_H__
extern unsigned char ds1302_buf[];
void Write_Ds1302(unsigned  char temp);
void Write_Ds1302_Byte( unsigned char address,unsigned char dat);
unsigned char Read_Ds1302_Byte ( unsigned char address );
void write_ds1302();
void read_ds1302();
#endif
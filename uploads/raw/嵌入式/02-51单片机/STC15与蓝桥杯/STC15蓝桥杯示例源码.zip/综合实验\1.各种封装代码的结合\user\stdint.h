#ifndef __STDINT_H__
#define __STDINT_H__
typedef unsigned char   uint8_t;
typedef unsigned int    uint32_t;
#define ON     1
#define OFF    0
#endif
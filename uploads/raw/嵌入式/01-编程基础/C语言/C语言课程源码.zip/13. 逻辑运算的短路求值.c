#include <stdio.h>

int main()
{
    int height = 100;			//一米八大长腿
    int money = 10000;		//一个小目标
    int handsome = 100;			//明星颜值
    
    int marry = (height > 170) || (money++) || (handsome > 80);
    printf("是否可以结婚：%d, money = %d\n", marry, money);	//
	    
    return 0;
}
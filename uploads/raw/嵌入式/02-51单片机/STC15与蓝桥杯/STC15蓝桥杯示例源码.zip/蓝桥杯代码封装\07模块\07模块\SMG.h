#ifndef __SMG_H_
#define __SMG_H_
typedef unsigned char uchar;
typedef unsigned int uint;
#include "main.h"
extern uchar num[8];
void HC138(uchar channel);
void smg_dis();
void cls();
void Delay13us();
#endif
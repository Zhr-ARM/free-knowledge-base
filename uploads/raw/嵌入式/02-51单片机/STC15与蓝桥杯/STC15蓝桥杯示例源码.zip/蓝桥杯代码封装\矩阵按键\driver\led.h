#ifndef __LED_H__
#define __LED_H__

#include <STC15F2K60S2.H>

extern unsigned char  ucled;
extern unsigned char control;
void led_control();
#endif






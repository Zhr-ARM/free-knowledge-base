#include <stdio.h>

int main()
{
    int a = 17, b = 5;
    
    int int_result = a / b;	//3.4
    
    //强制转换为浮点数
    float float_result = (float)a / b;
    float float_result2 = a / (float)b;
    
    //两个操作数都转换
    double double_result = (double)a / (double)b;
    
    printf("整数除法，结果为：%d\n", int_result);
    printf("浮点除法，结果为：%f\n", float_result);
    printf("浮点除法，结果为：%f\n", float_result2);
    printf("双精度除法，结果为：%f\n", double_result);
    
    return 0;
}
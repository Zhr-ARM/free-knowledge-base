#include <stdio.h>

int main()
{
    double pi = 3.141592653;
    double large_num = 123456.789;
    char name[] = "山上村中井上桥边太郎";
    
    printf("pi = %.3f\n", pi);
    printf("pi = %06.3f\n", pi);
    printf("large_num = %.4e\n", large_num);
    printf("name = %.10s\n", name);
    
    return 0;
}
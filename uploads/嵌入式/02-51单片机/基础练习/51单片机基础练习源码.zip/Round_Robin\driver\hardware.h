#ifndef __HARDWARE_H__
#define __HARDWARE_H__

#include <STC15F2K60S2.H>

// BEEP,Relay״̬����
#define ON     1    
#define OFF    0

void LED_Control(unsigned char state);
void BEEP_Relay_Control(unsigned char BEEP_state, unsigned char Relay_state);


#endif
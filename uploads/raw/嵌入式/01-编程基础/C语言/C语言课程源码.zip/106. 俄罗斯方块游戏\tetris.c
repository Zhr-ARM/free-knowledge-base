#include "tetris.h"

//定义7种俄罗斯方块的形状（用7个独立的二维数组）
//每个方块用4*4的二维数组表示，1表示有方块，0表示空

//I型方块（长条）
int tetris_piece_I_shape[4][4] = {
	{0, 0, 0, 0},
	{1, 1, 1, 1},
	{0, 0, 0, 0},
	{0, 0, 0, 0}
};

//O型方块（正方型）
int tetris_piece_O_shape[4][4] = {
	{0, 0, 0, 0},
	{0, 1, 1, 0},
	{0, 1, 1, 0},
	{0, 0, 0, 0}
};

// T型方块（T字形）
int tetris_piece_T_shape[4][4] = {
    {0,0,0,0},
    {0,1,0,0},
    {1,1,1,0},
    {0,0,0,0}
};

// S型方块（S形）
int tetris_piece_S_shape[4][4] = {
    {0,0,0,0},
    {0,1,1,0},
    {1,1,0,0},
    {0,0,0,0}
};

// Z型方块（Z形）
int tetris_piece_Z_shape[4][4] = {
    {0,0,0,0},
    {1,1,0,0},
    {0,1,1,0},
    {0,0,0,0}
};

// J型方块（左钩）
int tetris_piece_J_shape[4][4] = {
    {0,0,0,0},
    {1,0,0,0},
    {1,1,1,0},
    {0,0,0,0}
};

// L型方块（右钩）
int tetris_piece_L_shape[4][4] = {
    {0,0,0,0},
    {0,0,1,0},
    {1,1,1,0},
    {0,0,0,0}
};

//下一个方块
TetrisPiece next_tetris_piece;

// 光标跳转函数
void move_cursor_to_position(int x, int y) {
    COORD position;
    position.X = x + SCREEN_OFFSET_X;
    position.Y = y + SCREEN_OFFSET_Y;
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), position);
}

// 设置控制台颜色
void set_console_color(enum ConsoleColors color_code) {
    SetConsoleTextAttribute(GetStdHandle(STD_OUTPUT_HANDLE), color_code);
}

// 隐藏光标
void hide_console_cursor() {
    CONSOLE_CURSOR_INFO cursor_info;
    GetConsoleCursorInfo(GetStdHandle(STD_OUTPUT_HANDLE), &cursor_info);
    cursor_info.bVisible = 0;
    SetConsoleCursorInfo(GetStdHandle(STD_OUTPUT_HANDLE), &cursor_info);
}

//获取方块类型对应颜色
int get_piece_color(enum PieceType piece_type) {
	switch(piece_type) {
		case PIECE_I:	return COLOR_CYAN;
		case PIECE_O:	return COLOR_ORANGE;
		case PIECE_T:	return COLOR_MAGENTA;
		case PIECE_S:	return COLOR_GREEN;
		case PIECE_Z:	return COLOR_RED;
		case PIECE_J:	return COLOR_BLUE;
		case PIECE_L:	return COLOR_GRAY;
		default: 		return COLOR_WHITE;
	}
}

//初始化游戏数据
void initialize_game_state(TetrisGameState *gameState){
	for(int i = 0; i < GAME_BOARD_HEIGHT; i++) {
		for(int j = 0; j < GAME_BOARD_WIDTH; j++)
			gameState->game_borad[i][j] = CELL_EMPTY;
	}
	
	gameState->current_score = 0;
	gameState->total_lines_cleared = 0;
	gameState->current_level = 1;
	gameState->game_over_flag = 0;
}

//显示文本辅助函数
void display_text(int x, int y, enum ConsoleColors color, const char* text) {
    COORD pos = {x, y};
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), pos);
    set_console_color(color);
    printf("%s", text);
}

//初始化游戏界面
void initialize_game_interface(TetrisGameState *gameState){
	system("cls"); //清屏
	
	set_console_color(COLOR_WHITE);		//设置为白色
	
	//绘制完整的游戏区域边框
	for(int i = 0; i < GAME_BOARD_HEIGHT; i++){
		for(int j = 0; j < GAME_BOARD_WIDTH; j++){
			//顶部、左边、右边、底部边框设置为白色
			if(i == 0 || i == GAME_BOARD_HEIGHT - 1 || j == 0 || j == GAME_BOARD_WIDTH - 1) {
				gameState->game_borad[i][j] = CELL_BORDER;
				move_cursor_to_position(j * 2, i);
				printf("■");
			}
		}
	}
	
	//显示游戏标题
	display_text(INFO_AREA_X, INFO_AREA_Y - 3, COLOR_CYAN, "俄罗斯方块");
	
	//显示得分
	display_text(INFO_AREA_X, INFO_AREA_Y, COLOR_YELLOW, "得分");
	char score_str[20];
	sprintf(score_str, "%d", gameState->current_score);
	display_text(INFO_AREA_X, INFO_AREA_Y + 1, COLOR_BRIGHT_WHITE, score_str);
	
	// 显示消除行
    display_text(INFO_AREA_X, INFO_AREA_Y + 3, COLOR_GREEN, "消除行");
    char lines_str[20];
    sprintf(lines_str, "%d", gameState->total_lines_cleared);
    display_text(INFO_AREA_X, INFO_AREA_Y + 4, COLOR_BRIGHT_WHITE, lines_str);
    
    // 显示级别
    display_text(INFO_AREA_X, INFO_AREA_Y + 6, COLOR_RED, "级别");
    char level_str[20];
    sprintf(level_str, "%d", gameState->current_level);
    display_text(INFO_AREA_X, INFO_AREA_Y + 7, COLOR_BRIGHT_WHITE, level_str);
    
    // 下一个方块标签
    display_text(INFO_AREA_X, INFO_AREA_Y + 9, COLOR_MAGENTA, "下一个");
    
    set_console_color(COLOR_WHITE);
}

//更新游戏信息
void update_score_display(TetrisGameState *gameState){
	//更新得分
	char score_str[20];
	sprintf(score_str, "%-8d", gameState->current_score);
	display_text(INFO_AREA_X, INFO_AREA_Y + 1, COLOR_BRIGHT_WHITE, score_str);
	
	// 更新消除行
    char lines_str[20];
    sprintf(lines_str, "%-8d", gameState->total_lines_cleared);
    display_text(INFO_AREA_X, INFO_AREA_Y + 4, COLOR_BRIGHT_WHITE, lines_str);
    
    // 更新级别
    char level_str[20];
    sprintf(level_str, "%-8d", gameState->current_level);
    display_text(INFO_AREA_X, INFO_AREA_Y + 7, COLOR_BRIGHT_WHITE, level_str);
}

//复制方块形状的辅助函数
void copy_piece_shape(int source[4][4], int target[4][4]){
	for(int i = 0; i < 4; i++){
		for(int j = 0; j < 4; j++){
			target[i][j] = source[i][j];
		}
	}
}

//创建新的俄罗斯方块
void create_new_tetris_piece(TetrisPiece *piece){
	piece->piece_type = rand() % 7;  //0~7
	piece->position_x = PLAYABLE_AREA_WIDTH / 2 - 1;  //在游戏区域中央
	piece->position_y = 0;
	
	switch(piece->piece_type){
		case PIECE_I:	copy_piece_shape(tetris_piece_I_shape, piece->piece_shape);	break;
		case PIECE_O:	copy_piece_shape(tetris_piece_O_shape, piece->piece_shape);	break;
		case PIECE_T:	copy_piece_shape(tetris_piece_T_shape, piece->piece_shape);	break;
		case PIECE_S:	copy_piece_shape(tetris_piece_S_shape, piece->piece_shape);	break;
		case PIECE_Z:	copy_piece_shape(tetris_piece_Z_shape, piece->piece_shape);	break;
		case PIECE_J:	copy_piece_shape(tetris_piece_J_shape, piece->piece_shape);	break;
		case PIECE_L:	copy_piece_shape(tetris_piece_L_shape, piece->piece_shape);	break;
		default:	break;
	}
}

//检查方块是否可以移动到新的位置
int is_piece_movement_valid(TetrisGameState *gameState, TetrisPiece *piece, int new_x, int new_y){
	for(int i = 0; i < 4; i++){
		for(int j = 0; j < 4; j++){
			if(piece->piece_shape[i][j] == 1){
				int board_x = new_x + j + 1;	//+1是因为左边有边框
				int board_y = new_y + i;
				
				//检查边界
				if(board_x <= 0 || board_x >= GAME_BOARD_WIDTH - 1 ||
					board_y >= GAME_BOARD_HEIGHT - 1)
					return 0;
					
				//检查是否与已有的方块碰撞
				if(board_y >= 0 && gameState->game_borad[board_y][board_x] != CELL_EMPTY)
					return 0;
			}
		}
	}
	return 1;
}

//绘制或清除当前方块
void draw_piece(TetrisPiece *piece, int should_draw){
	//设置颜色
	if(should_draw != 0)		//画出方块
		set_console_color(get_piece_color(piece->piece_type));
	else						//擦除方块
		set_console_color(COLOR_WHITE);
		
	for(int i = 0; i < 4; i++){
		for(int j = 0; j < 4; j++){
			if(piece->piece_shape[i][j] == 1){
				int screen_x = (piece->position_x + j + 1) * 2;	//+1是因为左边有边框，*2是因为■占2个字符宽度
				int screen_y = piece->position_y + i;
				
				move_cursor_to_position(screen_x, screen_y);
				if(should_draw != 0)
					printf("■");
				else
					printf("  ");		//2个空格
			}
		}
	}
	set_console_color(COLOR_WHITE);
}

//将方块放置到游戏板上
void place_piece_on_board(TetrisGameState *gameState, TetrisPiece *piece){
	set_console_color(get_piece_color(piece->piece_type));
	
	for(int i = 0; i < 4; i++){
		for(int j = 0; j < 4; j++){
			if(piece->piece_shape[i][j] == 1) {
				int board_x = piece->position_x + j + 1;
				int board_y = piece->position_y + i;
				
				if(board_y >= 0 && board_y < GAME_BOARD_HEIGHT - 1 &&
					board_x > 0 && board_x < GAME_BOARD_WIDTH - 1){
					gameState->game_borad[board_y][board_x] = piece->piece_type;	//直接保存方块类型
					
					//立即在屏幕上绘制这个方块
					move_cursor_to_position(board_x * 2, board_y);
					printf("■");
				}
			}
		}
	}
	
	set_console_color(COLOR_WHITE);
}

//旋转方块
void rotate_tetris_piece(TetrisPiece *piece){
	int temp[4][4];
	int i, j;
	
	for(i = 0; i < 4; i++){
		for(j = 0; j < 4; j++)
			temp[i][j] = piece->piece_shape[i][j];
	}
	
	for(i = 0; i < 4; i++){
		for(j = 0; j < 4; j++)
			piece->piece_shape[i][j] = temp[3 - j][i];	//矩阵旋转
	}
}

//检查某一行是否完整
int is_line_fully_filled(TetrisGameState *gameState, int line_number){
	for(int j = 1; j < GAME_BOARD_WIDTH - 1; j++){
		if(gameState->game_borad[line_number][j] == CELL_EMPTY)
			return 0;
	}
	return 1;
}

//将指定行上方的所有行向下移动一行
void shift_lines_downward(TetrisGameState *gameState, int start_line){
	for(int i = start_line; i > 1; i--){
		for(int j = 1; j < GAME_BOARD_WIDTH - 1; j++){
			gameState->game_borad[i][j] = gameState->game_borad[i - 1][j];
			
			move_cursor_to_position(j * 2, i);
			if(gameState->game_borad[i][j] != CELL_EMPTY){
				set_console_color(get_piece_color(gameState->game_borad[i][j]));
				printf("■");
			}else{
				set_console_color(COLOR_WHITE);
				printf("  ");
			}
		}
	}
	set_console_color(COLOR_WHITE);
}
	
//清除完整的行
void remove_completed_lines(TetrisGameState *gameState){
	int lines_cleared_now = 0;
	
	for(int i = GAME_BOARD_HEIGHT - 2; i >= 1; i--){
		if(is_line_fully_filled(gameState, i)){
			shift_lines_downward(gameState, i);
			i++;		//重新检查这一行
			lines_cleared_now++;
		}
	}
	
	if(lines_cleared_now > 0){
		gameState->total_lines_cleared += lines_cleared_now;
		gameState->current_score += lines_cleared_now * 100 * gameState->current_level;
		gameState->current_level = gameState->total_lines_cleared / 10 + 1;	//消除10行等级加1
		update_score_display(gameState);
	}
}

//显示下一个方块
void display_next_piece(){
	//清除之前的显示
	set_console_color(COLOR_WHITE);
	for(int i = 0; i < 4; i++){
		for(int j = 0; j < 4; j++){
			COORD clear_pos = {INFO_AREA_X, INFO_AREA_Y + 10 + i};
		    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), clear_pos);
		    printf("        ");
		}
	}
	
	//显示新的方块
	set_console_color(get_piece_color(next_tetris_piece.piece_type));
	for(int i = 0; i < 4; i++){
		for(int j = 0; j < 4; j++){
			if(next_tetris_piece.piece_shape[i][j] == 1){
				COORD piece_pos = {INFO_AREA_X + j * 2, INFO_AREA_Y + 10 + i};
			    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), piece_pos);
			    printf("■");
			}
		}
	}
	set_console_color(COLOR_WHITE);
}

//游戏主循环
void run_tetris_game(){
	TetrisGameState gameState;
	TetrisPiece current_piece;
	clock_t last_fall_time;
	int fall_delay;
	
	srand(time(NULL));
	
	//初始化游戏
	initialize_game_state(&gameState);
	initialize_game_interface(&gameState);
	hide_console_cursor();
	
	create_new_tetris_piece(&current_piece);
	create_new_tetris_piece(&next_tetris_piece);
	
	draw_piece(&current_piece, 1);
	display_next_piece();
	
	last_fall_time = clock();
	
	while(!gameState.game_over_flag){
		fall_delay = 1000 - (gameState.current_level - 1) * 100;
		if(fall_delay < 100)	fall_delay = 100;
		
		if(clock() - last_fall_time > fall_delay){
			draw_piece(&current_piece, 0);		//擦除方块
			if(is_piece_movement_valid(&gameState, &current_piece, current_piece.position_x, current_piece.position_y + 1))
				current_piece.position_y++;			//往下掉1格
			else {	//不能往下掉了
				place_piece_on_board(&gameState, &current_piece);	//方块落地
				remove_completed_lines(&gameState);
				
				current_piece = next_tetris_piece;
				create_new_tetris_piece(&next_tetris_piece);
				display_next_piece();
				
				if(!is_piece_movement_valid(&gameState, &current_piece, current_piece.position_x, current_piece.position_y))
					gameState.game_over_flag = 1;
			}
			
			draw_piece(&current_piece, 1);		//显示方块
			last_fall_time = clock();
		}
		
		if(kbhit()){
			char key = getch();
			if(key == KEY_ARROW)
				key = getch();
			
			draw_piece(&current_piece, 0);		//擦除方块
			
			switch(key){
				case KEY_LEFT:
					if(is_piece_movement_valid(&gameState, &current_piece, current_piece.position_x - 1, current_piece.position_y))
						current_piece.position_x--;
					break;
					
				case KEY_RIGHT:
					if(is_piece_movement_valid(&gameState, &current_piece, current_piece.position_x + 1, current_piece.position_y))
						current_piece.position_x++;
					break;
					
				case KEY_DOWN:
					if(is_piece_movement_valid(&gameState, &current_piece, current_piece.position_x, current_piece.position_y + 1)){
						current_piece.position_y++;
						gameState.current_score++;
						update_score_display(&gameState);		//更新右侧信息
					}
						
					break;
					
				case KEY_UP:
				case KEY_SPACE:
					{
						TetrisPiece temp_piece = current_piece;
						rotate_tetris_piece(&temp_piece);
						if(is_piece_movement_valid(&gameState, &temp_piece, temp_piece.position_x, temp_piece.position_y))
							current_piece = temp_piece;
					}
					break;
					
				case KEY_QUIT:
					gameState.game_over_flag = 1;
					break;
			}
			
			draw_piece(&current_piece, 1);		//显示方块
		}
	}
	
	//游戏结束
	COORD end_pos = {0, GAME_BOARD_HEIGHT + SCREEN_OFFSET_Y + 2};
    SetConsoleCursorPosition(GetStdHandle(STD_OUTPUT_HANDLE), end_pos);
    set_console_color(COLOR_RED);
    printf("游戏结束！最终得分：%d\n", gameState.current_score);
    set_console_color(COLOR_WHITE);
    printf("按任意键退出...\n");
    getch();
}

int main()
{
    run_tetris_game();
    //while(1);
    return 0;
}
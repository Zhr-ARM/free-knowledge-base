#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "nvs_flash.h"
#include "pwm.h"

/**
 * @brief 程序入口
 * @param 无
 * @retval 无
 */
void app_main(void)
{
    esp_err_t ret;
    uint8_t dir = 1;
    uint16_t ledpwmval = 0;

    ret = nvs_flash_init();    /* 初始化 NVS */
    if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND)
    {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ret = nvs_flash_init();
    }
    pwm_init(10,1000);
    while(1)
    {
        vTaskDelay(10);
        if(dir==1)
        {
            ledpwmval += 5;
        }
        else
        {
            ledpwmval -= 5;
        }
        if(ledpwmval>=1005)
        {
            dir=0;
        }
        else if(ledpwmval<=5)
        {
            dir=1;
        }
        /* 设置占空比 */
        pwm_set_duty(ledpwmval);
    }
}

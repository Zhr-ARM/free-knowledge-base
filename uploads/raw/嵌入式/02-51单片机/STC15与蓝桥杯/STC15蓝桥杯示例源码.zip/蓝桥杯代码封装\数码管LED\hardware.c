#include "hardware.h"

unsigned char led_buf = 0x01;
unsigned int timer1s=0;
void led_output()
{
	P0=~led_buf;
	P2=P2&0x1F|0x80;
	P2&=0x1F;
}


unsigned char code t_display[]={                       //��׼�ֿ�
//   0    1    2    3    4    5    6    7    8    9    A    B    C    D    E    F
    0x3F,0x06,0x5B,0x4F,0x66,0x6D,0x7D,0x07,0x7F,0x6F,0x77,0x7C,0x39,0x5E,0x79,0x71,
//black  -     H    J    K    L    N    o   P    U     t    G    Q    r   M    y
    0x00,0x40,0x76,0x1E,0x70,0x38,0x37,0x5C,0x73,0x3E,0x78,0x3d,0x67,0x50,0x37,0x6e,
    0xBF,0x86,0xDB,0xCF,0xE6,0xED,0xFD,0x87,0xFF,0xEF,0x46};    //0. 1. 2. 3. 4. 5. 6. 7. 8. 9. -1

unsigned char code T_COM[]={0x01,0x02,0x04,0x08,0x10,0x20,0x40,0x80};      //λ��

unsigned char dig_buf[8]={16,16,16,16,16,16,16,16};
void dig_output()
{
	static unsigned char dig_com=0;
	P0=0x00;   //��Ӱ
	P2=P2&0x1F|0xC0;
	P2&=0x1F;
	
	P0=~t_display[dig_buf[dig_com]];   //��ѡ
	P2=P2&0x1F|0xE0;
	P2&=0x1F;
	
	P0=T_COM[dig_com];   //λѡ
	P2=P2&0x1F|0xC0;
	P2&=0x1F;
	
	if (++dig_com >= 8)
	{
		dig_com=0;
	}
}
void Timer1Init(void)		//1����@12.000MHz
{
	AUXR |= 0x40;		//��ʱ��ʱ��1Tģʽ
	TMOD &= 0x0F;		//���ö�ʱ��ģʽ
	TL1 = 0x20;		//���ö�ʱ��ֵ
	TH1 = 0xD1;		//���ö�ʱ��ֵ
	TF1 = 0;		//���TF1��־
	TR1 = 1;		//��ʱ��1��ʼ��ʱ
	ET1 = 1;
	EA = 1;
}

void Timer1Service() interrupt 3
{
	TL1 = 0x20;		//���ö�ʱ��ֵ
	TH1 = 0xD1;		//���ö�ʱ��ֵ
	led_output();
	dig_output();
	timer1s++;
}

#include <stdio.h>

//#define	PI	3.14

enum gender{
	MALE = 10,
	FEMALE
};

int main(void)
{
	const double PI = 3.14;
	
	//PI = 3.33;
	
    double radius = 5.0;
    double area = PI * radius * radius;
    
    printf("圆的面积为：%.2f\n", area);
    printf("FEMALE的值为：%d\n", FEMALE);
    return 0;
}
/* USER CODE BEGIN Header */
/**
 ******************************************************************************
 * @file           : main.c
 * @brief          : Main program body
 ******************************************************************************
 * @attention
 *
 * Copyright (c) 2025 STMicroelectronics.
 * All rights reserved.
 *
 * This software is licensed under terms that can be found in the LICENSE file
 * in the root directory of this software component.
 * If no LICENSE file comes with this software, it is provided AS-IS.
 *
 ******************************************************************************
 */
/* USER CODE END Header */
/* Includes ------------------------------------------------------------------*/
#include "main.h"
#include "adc.h"
#include "comp.h"
#include "dac.h"
#include "dma.h"
#include "opamp.h"
#include "tim.h"
#include "usart.h"
#include "gpio.h"

/* Private includes ----------------------------------------------------------*/
/* USER CODE BEGIN Includes */

/* USER CODE END Includes */

/* Private typedef -----------------------------------------------------------*/
/* USER CODE BEGIN PTD */

/* USER CODE END PTD */

/* Private define ------------------------------------------------------------*/
/* USER CODE BEGIN PD */
#define RXBUFFERSIZE 256
char RxBuffer[RXBUFFERSIZE];
uint8_t aRxuffer;
uint8_t Uart1_Rx_Cnt = 0;
/* USER CODE END PD */

/* Private macro -------------------------------------------------------------*/
/* USER CODE BEGIN PM */

/* USER CODE END PM */

/* Private variables ---------------------------------------------------------*/

/* USER CODE BEGIN PV */

/* USER CODE END PV */

/* Private function prototypes -----------------------------------------------*/
void SystemClock_Config(void);
/* USER CODE BEGIN PFP */

/* USER CODE END PFP */

/* Private user code ---------------------------------------------------------*/
/* USER CODE BEGIN 0 */
float temp[5] = {0, 0, 0, 0, 0};
float Vbus, Ia, Ib, Ic;
uint16_t IA_Offset, IB_Offset, IC_Offset;
uint16_t adc1_in1, adc1_in2, adc1_in3, Vpoten, adc_vbus;
uint8_t ADC_offset = 0;
float load_data[5] = {0.0f, 0.0f, 0.0f, 0.0f, 0.0f};
uint32_t DAC_wave[100] = {
    2048, 2178, 2307, 2435, 2560, 2682, 2800, 2913, 3020, 3121,
    3215, 3301, 3379, 3448, 3508, 3558, 3598, 3628, 3648, 3657,
    3657, 3648, 3628, 3598, 3558, 3508, 3448, 3379, 3301, 3215,
    3121, 3020, 2913, 2800, 2682, 2560, 2435, 2307, 2178, 2048,
    1917, 1788, 1659, 1531, 1406, 1284, 1166, 1053, 946, 845,
    751, 665, 587, 518, 458, 408, 368, 338, 318, 309,
    309, 318, 338, 368, 408, 458, 518, 587, 665, 751,
    845, 946, 1053, 1166, 1284, 1406, 1531, 1659, 1788, 1917,
    2048, 2178, 2307, 2435, 2560, 2682, 2800, 2913, 3020, 3121,
    3215, 3301, 3379, 3448, 3508, 3558, 3598, 3628, 3648, 3657
};
static uint8_t tempData[24] = {0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0x80, 0x7f};
/* USER CODE END 0 */

/**
 * @brief  The application entry point.
 * @retval int
 */
int main(void)
{

  /* USER CODE BEGIN 1 */

  /* USER CODE END 1 */

  /* MCU Configuration--------------------------------------------------------*/

  /* Reset of all peripherals, Initializes the Flash interface and the Systick. */
  HAL_Init();

  /* USER CODE BEGIN Init */

  /* USER CODE END Init */

  /* Configure the system clock */
  SystemClock_Config();

  /* USER CODE BEGIN SysInit */

  /* USER CODE END SysInit */

  /* Initialize all configured peripherals */
  MX_GPIO_Init();
  MX_DMA_Init();
  MX_USART3_UART_Init();
  MX_ADC1_Init();
  MX_ADC2_Init();
  MX_OPAMP1_Init();
  MX_OPAMP2_Init();
  MX_OPAMP3_Init();
  MX_TIM1_Init();
  MX_COMP1_Init();
  MX_DAC3_Init();
  MX_DAC1_Init();
  /* USER CODE BEGIN 2 */
  HAL_OPAMP_Start(&hopamp1);
  HAL_OPAMP_Start(&hopamp2);
  HAL_OPAMP_Start(&hopamp3);
  HAL_ADCEx_Calibration_Start(&hadc1, ADC_SINGLE_ENDED);
  HAL_ADCEx_Calibration_Start(&hadc2, ADC_SINGLE_ENDED);
  HAL_UART_Receive_IT(&huart3, (uint8_t *)&aRxuffer, 1);
  // TIM1->PSC = 30000;
  TIM1->ARR = 8000 - 1;
  // TIM1->CCR1 = 2000;
  // TIM1->CCR2 = 5000;
  // TIM1->CCR3 = 8000;
  TIM1->CCR4 = 8000 - 2;
  HAL_TIM_Base_Start(&htim1);
  HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_4);
  HAL_ADCEx_InjectedStart_IT(&hadc1);
  HAL_ADCEx_InjectedStart(&hadc2);
  HAL_DAC_Start(&hdac3, DAC_CHANNEL_1);
  HAL_DAC_SetValue(&hdac3, DAC_CHANNEL_1, DAC_ALIGN_12B_R, 3000);
  HAL_COMP_Start(&hcomp1);
  HAL_DAC_Start(&hdac1, DAC_CHANNEL_1); // 确保DAC1通道1已启动
  // HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_1);
  // HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_2);
  // HAL_TIM_PWM_Start(&htim1, TIM_CHANNEL_3);
  // HAL_TIMEx_PWMN_Start(&htim1, TIM_CHANNEL_1);
  // HAL_TIMEx_PWMN_Start(&htim1, TIM_CHANNEL_2);
  // HAL_TIMEx_PWMN_Start(&htim1, TIM_CHANNEL_3);
  /* USER CODE END 2 */

  /* Infinite loop */
  /* USER CODE BEGIN WHILE */
  while (1)
  {
    /* USER CODE END WHILE */

    /* USER CODE BEGIN 3 */
    HAL_ADC_Start(&hadc1);
    HAL_ADC_Start(&hadc2);
    temp[3] = HAL_ADC_GetValue(&hadc1);
    temp[3] = temp[3] * 3.3f / 4096;
    temp[4] = HAL_ADC_GetValue(&hadc2);
    temp[4] = temp[4] * 3.3f / 4096;
    HAL_Delay(10);
    // HAL_ADCEx_InjectedStart_IT(&hadc1);
    // HAL_ADCEx_InjectedStart_IT(&hadc2);
    // temp[0]= HAL_ADC_GetValue(&hadc1);
    // temp[1]= HAL_ADC_GetValue(&hadc2)*0.02094726f;
    // if((GPIOA->IDR & GPIO_PIN_8) !=0)
    // {
    //   temp[0]=1.0f;
    // }
    // else
    // {
    //   temp[0]=0.0f;
    // }
    // if((GPIOA->IDR & GPIO_PIN_9) !=0)
    // {
    //   temp[1]=3.0f;
    // }
    // else
    // {
    //   temp[1]=2.0f;
    // }
    // if((GPIOA->IDR & GPIO_PIN_10) !=0)
    // {
    //   temp[2]=5.0f;
    // }
    // else
    // {
    //   temp[2]=4.0f;
    // }
    // memcpy(tempData, (uint8_t *)temp, sizeof(temp));
    // HAL_UART_Transmit_DMA(&huart3, (uint8_t *)tempData, 24);
    // HAL_Delay(5);
  }
  /* USER CODE END 3 */
}

/**
 * @brief System Clock Configuration
 * @retval None
 */
void SystemClock_Config(void)
{
  RCC_OscInitTypeDef RCC_OscInitStruct = {0};
  RCC_ClkInitTypeDef RCC_ClkInitStruct = {0};

  /** Configure the main internal regulator output voltage
   */
  HAL_PWREx_ControlVoltageScaling(PWR_REGULATOR_VOLTAGE_SCALE1_BOOST);

  /** Initializes the RCC Oscillators according to the specified parameters
   * in the RCC_OscInitTypeDef structure.
   */
  RCC_OscInitStruct.OscillatorType = RCC_OSCILLATORTYPE_HSE;
  RCC_OscInitStruct.HSEState = RCC_HSE_ON;
  RCC_OscInitStruct.PLL.PLLState = RCC_PLL_ON;
  RCC_OscInitStruct.PLL.PLLSource = RCC_PLLSOURCE_HSE;
  RCC_OscInitStruct.PLL.PLLM = RCC_PLLM_DIV6;
  RCC_OscInitStruct.PLL.PLLN = 85;
  RCC_OscInitStruct.PLL.PLLP = RCC_PLLP_DIV2;
  RCC_OscInitStruct.PLL.PLLQ = RCC_PLLQ_DIV2;
  RCC_OscInitStruct.PLL.PLLR = RCC_PLLR_DIV2;
  if (HAL_RCC_OscConfig(&RCC_OscInitStruct) != HAL_OK)
  {
    Error_Handler();
  }

  /** Initializes the CPU, AHB and APB buses clocks
   */
  RCC_ClkInitStruct.ClockType = RCC_CLOCKTYPE_HCLK | RCC_CLOCKTYPE_SYSCLK | RCC_CLOCKTYPE_PCLK1 | RCC_CLOCKTYPE_PCLK2;
  RCC_ClkInitStruct.SYSCLKSource = RCC_SYSCLKSOURCE_PLLCLK;
  RCC_ClkInitStruct.AHBCLKDivider = RCC_SYSCLK_DIV1;
  RCC_ClkInitStruct.APB1CLKDivider = RCC_HCLK_DIV1;
  RCC_ClkInitStruct.APB2CLKDivider = RCC_HCLK_DIV1;

  if (HAL_RCC_ClockConfig(&RCC_ClkInitStruct, FLASH_LATENCY_4) != HAL_OK)
  {
    Error_Handler();
  }
}

/* USER CODE BEGIN 4 */
void HAL_UART_RxCpltCallback(UART_HandleTypeDef *huart)
{
  if (huart->Instance == USART3) // 检查是哪个UART触发的回调
  {
    if (Uart1_Rx_Cnt >= 255)
    {
      Uart1_Rx_Cnt = 0;
      memset(RxBuffer, 0, sizeof(RxBuffer)); // 清空接收缓冲区
      HAL_UART_Transmit(&huart3, (uint8_t *)"?????", 10, HAL_MAX_DELAY);
    }
    else
    {
      RxBuffer[Uart1_Rx_Cnt++] = aRxuffer; // 存储接收到的数据
    }
    HAL_UART_Receive_IT(&huart3, (uint8_t *)&aRxuffer, 1); // 重新开启接收中断
  }
}

void HAL_ADCEx_InjectedConvCpltCallback(ADC_HandleTypeDef *hadc)
{
  static uint8_t cnt = 0;
  static uint8_t i = 0; // 将 i 声明为静态变量以保持其值
  UNUSED(hadc);
  // 在这里处理注入转换完成后的操作
  if (hadc == &hadc1)
  {
    if (ADC_offset == 0)
    {
      cnt++;
      adc1_in1 = hadc1.Instance->JDR1;
      adc1_in2 = hadc2.Instance->JDR1;
      adc1_in3 = hadc1.Instance->JDR2;
      IA_Offset += adc1_in1;
      IB_Offset += adc1_in2;
      IC_Offset += adc1_in3;
      if (cnt >= 10)
      {
        ADC_offset = 1;
        IA_Offset /= 10;
        IB_Offset /= 10;
        IC_Offset /= 10;
      }
    }
    else
    {
      adc1_in1 = hadc1.Instance->JDR1;
      Ia = (adc1_in1 - IA_Offset) * 0.0193359375f;
      adc1_in2 = hadc2.Instance->JDR1;
      Ib = (adc1_in2 - IB_Offset) * 0.0193359375f;
      adc1_in3 = hadc1.Instance->JDR2;
      Ic = (adc1_in3 - IC_Offset) * 0.0193359375f;
      TIM1->CCR1 = 2000;
      TIM1->CCR2 = 4000;
      TIM1->CCR3 = 6000;
      load_data[0] = Ia;
      load_data[1] = Ib;
      load_data[2] = Ic;
      load_data[3] = temp[3];
      load_data[4] = temp[4];
      memcpy(tempData, (uint8_t *)load_data, sizeof(load_data));
      HAL_UART_Transmit_DMA(&huart3, (uint8_t *)tempData, 24);
      i++;
      if (i >= 100) // 确保 i 在 0 到 99 之间循环
      {
        i = 0;
      }
       HAL_DAC_SetValue(&hdac1, DAC_CHANNEL_1, DAC_ALIGN_12B_R, DAC_wave[i]); // 输出正弦波

    }
  }
}
/* USER CODE END 4 */

/**
 * @brief  This function is executed in case of error occurrence.
 * @retval None
 */
void Error_Handler(void)
{
  /* USER CODE BEGIN Error_Handler_Debug */
  /* User can add his own implementation to report the HAL error return state */
  __disable_irq();
  while (1)
  {
  }
  /* USER CODE END Error_Handler_Debug */
}
#ifdef USE_FULL_ASSERT
/**
 * @brief  Reports the name of the source file and the source line number
 *         where the assert_param error has occurred.
 * @param  file: pointer to the source file name
 * @param  line: assert_param error line source number
 * @retval None
 */
void assert_failed(uint8_t *file, uint32_t line)
{
  /* USER CODE BEGIN 6 */
  /* User can add his own implementation to report the file name and line number,
     ex: printf("Wrong parameters value: file %s on line %d\r\n", file, line) */
  /* USER CODE END 6 */
}
#endif /* USE_FULL_ASSERT */

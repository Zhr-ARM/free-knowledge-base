#ifndef __MAIN_H__
#define __MAIN_H__

#include <STC15F2K60S2.H>
#include "intrins.h"

#define uint8_t unsigned char
#define uint32_t unsigned int
	
#define ON 1
#define OFF 0

#define MODE1 0//WENDU
#define MODE2 1//SHIJIAN
#define MODE3 2//CHAOSHENGBO
#define MODE4 3//PINLV
#define MODE5 4//�������
#define MODE6 5//at24

extern uint8_t mode;


#endif
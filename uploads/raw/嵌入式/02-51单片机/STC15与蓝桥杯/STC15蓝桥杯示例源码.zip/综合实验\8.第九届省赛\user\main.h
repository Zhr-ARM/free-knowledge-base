#ifndef __MAIN_H__
#define __MAIN_H__

#include <STC15F2K60S2.H>
#include "intrins.h"

#define uint8_t unsigned char
#define uint32_t unsigned int

#define ON   1
#define OFF  0

#define mode1 	0
#define mode2 	1
#define mode3 	2
#define mode4 	3

#define CONFIG  6
#define RUN     7
#define TIME    8
#define NORMAL  9

#endif
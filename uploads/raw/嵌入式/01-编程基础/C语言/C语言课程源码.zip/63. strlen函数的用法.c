#include <stdio.h>
#include <string.h>

int main()
{
    char name[] = "良许";
    char *message = "欢迎学习嵌入式！";
    
    printf("姓名长度：%zu\n", strlen(name));
    printf("消息长度：%zu\n", strlen(message));
    printf("常量长度：%zu\n", strlen("Hello"));
    
    return 0;
}
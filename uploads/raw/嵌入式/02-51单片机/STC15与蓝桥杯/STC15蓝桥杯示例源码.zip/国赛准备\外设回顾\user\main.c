#include "main.h"
#include "hardware.h"
#include "iic.h"
#include "ds1302.h"
#include "onewire.h"

uint8_t led=0xFF;

uint8_t beep=OFF;
uint8_t relay=OFF;

uint32_t temp=0;

uint32_t pcfv1=0;
uint32_t pcfv2=0;
uint32_t pcfv3=0;

uint8_t at_wr_buf[3]={12,34,56};
uint8_t at_rd_buf[3]={0};

uint8_t mode=0;

uint8_t time10ms=0;
uint8_t time200ms=0;

uint8_t uart_buf[10]={0};
uint8_t uart_tx_buf[10]={0};
uint8_t uart_index=0;
bit uart_flag=0;

void Uart1_Init(void)	//9600bps@12.000MHz
{
	SCON = 0x50;		//8位数据,可变波特率
	AUXR |= 0x01;		//串口1选择定时器2为波特率发生器
	AUXR |= 0x04;		//定时器时钟1T模式
	T2L = 0xC7;			//设置定时初始值
	T2H = 0xFE;			//设置定时初始值
	AUXR |= 0x10;		//定时器2开始计时

    ES=1;
    EA=1;
}

void SendByte(uint8_t dat)
{
    ES=0;
    SBUF = dat;
    while(TI==0);
    TI=0;
    ES=1;
}

void SendString(uint8_t *dat)
{
    while(*dat!='\0')
    {
        SendByte(*dat++);
    }
    uart_index=0;
}

void uart_handle(void)
{
    if(uart_flag==1&&uart_index!=0)
    {
        strcpy(uart_tx_buf,uart_buf);
        SendString(uart_tx_buf);
        uart_flag=0;
    }
    
}

void uart_irq(void) interrupt 4
{
    if(RI)
    {
        if(SBUF!='\n')
            uart_buf[uart_index++]=SBUF;
        else
        {
            uart_flag=1;
        }
        RI = 0;
    }
}


sbit TX=P1^0;
sbit RX=P1^1;
uint32_t timeus=0;
uint32_t dis=0;
uint32_t dis_time=0;
bit dis_flag=0;

void pca_init(void)
{
    CCON=0;
    CMOD=0X01;
    P_SW1&=0XCF;
    CCAPM0=0X10;
}
void rd_dis(void)
{
    uint8_t i=8;
    CCAPM0|=0X01;
    CF=CCF0=0;
    CH=CL=0;
    CCAP0L=CCAP0H=0;
    CR=1;
    EA=0;
    do
    {
        TX=1;
        Delay14us();
        TX=0;
        Delay14us();
    } while (i--);
    EA=1;
    if(dis_flag==0)
    {
        dis=timeus*0.017+0.5;
    }
    else if(dis_flag==1)
    {
        dis=999;
        dis_flag=0;
    }
}

uint32_t freq=0;
uint8_t ne555_time=0;

void Timer0_Init(void)		//100微秒@11.0592MHz
{
	TMOD &= 0xF0;			//设置定时器模式
    TMOD |= 0X04;
	TL0 = 0x00;				//设置定时初始值
	TH0 = 0x00;				//设置定时初始值
	TF0 = 0;				//清除TF0标志
	TR0 = 1;				//定时器0开始计时
}

void ne555_detect(void)
{
    if(ne555_time>=200)
    {
        ne555_time=0;
        TR0=0;
        freq=(int)(TH0<<8)|TL0;
        TH0=TL0=0;
        TR0=1;
        freq*=5;
    }
}

uint8_t cnt=0;
uint8_t T=20;
uint32_t duty=0;
bit duty_flag=1;
uint8_t pwm_time=0;

void pwm_control(void)
{
    if(cnt++>T)
        cnt=0;
    if(cnt>=duty)
        led&=~0x10;
    else
        led|=0x10;
    if(++pwm_time>=200)
    {
        pwm_time=0;
        if(duty_flag==0)
            duty--;
        else
            duty++;
        if(duty==0)
            duty_flag=1;
        else if(duty==T)
            duty_flag=0;
    }

}

void Timer1_Init(void)		//1毫秒@12.000MHz
{
	AUXR |= 0x40;			//定时器时钟1T模式
	TMOD &= 0x0F;			//设置定时器模式
	TL1 = 0x20;				//设置定时初始值
	TH1 = 0xD1;				//设置定时初始值
	TF1 = 0;				//清除TF1标志
	TR1 = 1;				//定时器1开始计时
	ET1 = 1;				//使能定时器1中断
    EA=1;
}

void key_handle(void)
{
    if(key_value==7&&key_state==5)  led|=~0x10;
    else if(key_value==6&&key_state==5) led&=0x10;
    else if(key_value==5&&key_state==5)  beep=ON;
    else if(key_value==4&&key_state==5)  beep=OFF;
    else if(key_value==11&&key_state==5)    relay=ON;
    else if(key_value==10&&key_state==5)    relay=OFF;
    else if(key_value==8&&key_state==5)
    {
        if(++mode>=6)
            mode=0;
		at_rd_buf[0]=at24c02_read(0x00);
        at_rd_buf[1]=at24c02_read(0x01);
        at_rd_buf[2]=at24c02_read(0x02);
    }
}
void dig_handle(void)
{
    if(mode==TIME)
    {
        dig_buf[mode][0]=ds1302_buf[0]/0x10;
        dig_buf[mode][1]=ds1302_buf[0]%0x10;
        dig_buf[mode][2]=17;
        dig_buf[mode][3]=ds1302_buf[1]/0x10;
        dig_buf[mode][4]=ds1302_buf[1]%0x10;
        dig_buf[mode][5]=17;
        dig_buf[mode][6]=ds1302_buf[2]/0x10;
        dig_buf[mode][7]=ds1302_buf[2]%0x10;
    }
    else if(mode==TEMPERATURE)
    {
        dig_buf[mode][4]=temp/1000%10;
        dig_buf[mode][5]=temp/100%10+32;
        dig_buf[mode][6]=temp/10%10;
        dig_buf[mode][7]=temp%10;
    }
    else if(mode==PCFV)
    {
        dig_buf[mode][0]=pcfv1/100%10+32;
        dig_buf[mode][1]=pcfv1/10%10;
        dig_buf[mode][2]=16;
        dig_buf[mode][3]=pcfv2/100%10+32;
        dig_buf[mode][4]=pcfv2/10%10;
        dig_buf[mode][5]=16;
        dig_buf[mode][6]=pcfv3/100%10+32;
        dig_buf[mode][7]=pcfv3/10%10;
    }
    else if(mode==AT24)
    {
        dig_buf[mode][0]=at_rd_buf[0]/10%10;
        dig_buf[mode][1]=at_rd_buf[0]%10;
        dig_buf[mode][2]=16;
        dig_buf[mode][3]=at_rd_buf[1]/10%10;
        dig_buf[mode][4]=at_rd_buf[1]%10;
        dig_buf[mode][5]=16;
        dig_buf[mode][6]=at_rd_buf[2]/10%10;
        dig_buf[mode][7]=at_rd_buf[2]%10;
    }
    else if(mode==NE555)
    {
        dig_buf[mode][0]=freq/100000%10;
        dig_buf[mode][1]=freq/10000%10;
        dig_buf[mode][2]=freq/1000%10;
        dig_buf[mode][3]=freq/100%10;
        dig_buf[mode][4]=freq/10%10;
        dig_buf[mode][5]=freq%10;
    }
    else if(mode==DIS)
    {
        dig_buf[mode][0]=dis/100%10;
        dig_buf[mode][1]=dis/10%10;
        dig_buf[mode][2]=dis%10;
    }
}

void main(void)
{
    rd_temperature();
    Uart1_Init();
    pca_init();
    Timer1_Init();
    Timer0_Init();
    at24c02_write(at_wr_buf,3,0x00);
    pcf8591_write(128);
    ds1302_write(); 
    Delay14us();
    SendString("Hello world!\n");
    while(1)
    {
        ne555_detect();
        uart_handle();
        if(time10ms>=10)
        {
            key_scan();
			key_handle();
			time10ms=0;
        }
        if(time200ms>=200)
        {
            temp=rd_temperature();
            pcfv3=pcf8591_read(0)/0.51+0.5;
            pcfv1=pcf8591_read(1)/0.51+0.5;
            pcfv2=pcf8591_read(3)/0.51+0.5;
            ds1302_read();
			dig_handle();
			time200ms=0;
            
        }
        if(dis_time>=250)
        {
            rd_dis();
			dis_time=0;
        }
    }
}
void Timer1_Isr(void) interrupt 3
{
	pwm_control();
    dis_time++;
	ne555_time++;
    time10ms++;
    time200ms++;
    led_handle(led);
    beep_relay(beep,relay);
    dig_show();
}
void pca_irq(void) interrupt 7
{
    CCAPM0&=~0X01;
    CR=0;
    if(CF)
    {
        dis_flag=1;
        CF=0;
    }
    else if(CCF0)
    {
        CCF0=0;
        timeus=(int)(CCAP0H<<8)|CCAP0L;
        dis_flag=0;
    }
}
void Delay14us(void)	//@12.000MHz
{
	unsigned char data i;

	_nop_();
	_nop_();
	i = 36;
	while (--i);
}

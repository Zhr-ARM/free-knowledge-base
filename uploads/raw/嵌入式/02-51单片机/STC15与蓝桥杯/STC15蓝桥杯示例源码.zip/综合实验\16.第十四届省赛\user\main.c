#include "main.h"
#include "hardware.h"
#include "onewire.h"
#include "iic.h"
#include "ds1302.h"

uint8_t xdata led=0xff;
uint8_t xdata relay_flag=OFF;
uint8_t xdata buzzer_flag=OFF;

uint8_t xdata time_10ms=0;
uint8_t xdata time_100ms=0;
uint8_t xdata time_200ms=0;
uint8_t xdata time_50ms=0;
uint32_t xdata time_3000ms=0;

uint32_t xdata pcfv=0;
uint32_t xdata temp=0;
uint8_t xdata water=0;
uint32_t xdata last_pcfv=0;
uint32_t xdata last_temp=0;
uint8_t xdata  last_water=0;
uint8_t xdata water_max=68;
uint8_t xdata ds1302_buf_temp[2]={0};
uint8_t xdata light_flag=OFF;
uint8_t xdata last_light_flag=OFF;
uint8_t xdata detect_flag=OFF;
uint8_t xdata mode_buf;
uint8_t xdata led_flag=OFF;
uint8_t xdata led_time=0;

void light_detect(void)
{
	last_light_flag=light_flag;
	if(pcfv<200)
		light_flag=ON;
	else
		light_flag=OFF;
	
}

void Timer0_Init(void)		//@12.000MHz
{
	TMOD &= 0xF0;			//���ö�ʱ��ģʽ
	TMOD |= 0X04;
	TL0 = 0x00;				//���ö�ʱ��ʼֵ
	TH0 = 0x00;				//���ö�ʱ��ʼֵ
	TF0 = 0;				//���TF0��־
	TR0 = 1;				//��ʱ��0��ʼ��ʱ
}
bit bline_flag=0;

void Timer1_Init(void)		//1����@12.000MHz
{
	AUXR |= 0x40;			//��ʱ��ʱ��1Tģʽ
	TMOD &= 0x0F;			//���ö�ʱ��ģʽ
	TL1 = 0x20;				//���ö�ʱ��ʼֵ
	TH1 = 0xD1;				//���ö�ʱ��ʼֵ
	TF1 = 0;				//���TF1��־
	TR1 = 1;				//��ʱ��1��ʼ��ʱ
	ET1 = 1;				//ʹ�ܶ�ʱ��1�ж�
	EA=1;
}

uint32_t xdata freq=0;
void freq_detect(void)
{
	if(time_100ms>=100)
	{
		TR0=0;
		freq=(int)(TH0<<8|TL0);
		freq=freq*10;
		TH0=TL0=0;
		TR0=1;
		time_100ms=0;
	}
}

uint8_t mode=0;
uint8_t xdata mode_temp=MODE2;
uint8_t xdata flag=0;
uint8_t xdata temp_max=30;
uint8_t xdata cnt=0;
uint8_t xdata last_key_value=0;
uint32_t xdata key_time=0;
bit key_flag=0;
void key_handle(void)
{
	if(key_value==4&&key_state==5)
	{
		if(mode==0) 
		{
			mode=mode_temp;
			flag=1;
		}
		else if(mode>=1&&mode<=3)
		{
			mode=MODE5;
			flag=0;
		}
		else if(mode==MODE5)
		{
			mode=0;
		}
	}
	if(key_value==5&&key_state==5)
	{
		if(flag==1) 
		{
			if(mode_temp<3)
			{
				mode_temp++;
				mode=mode_temp;
			}
			else
			{
				mode_temp=mode=MODE2;
			}
		}
	}
	if(key_value==8&&key_state==5)
	{
		if(mode==MODE5)
		{
			temp_max++;
		}
	}
//	if(key_value==9&&key_state==200)
//	{

//	}
//	else if(key_value==9&&key_state==10)
//	{
//		if(mode==MODE5)
//		{
//			temp_max--;
//		}
//	}
	if(key_value==9)
		key_flag=1;
	if(last_key_value==9&&key_value!=9)
	{
		key_flag=0;
		if(key_time<1500)
		{
			if(mode==MODE5)
			{
				temp_max--;
			}
		}
		else if(key_time>=2000)
		{
			if(mode==MODE5)
			{
				temp=0;
				water=0;
				ds1302_buf_temp[0]=0;
				ds1302_buf_temp[1]=0;
				cnt=0;
			}
		}
		key_time=0;
	}
	last_key_value=key_value;
}

void mode_select(void)
{
	if(mode==MODE1)
	{
		dig_buf[mode][0]=ds1302_buf[0]/0x10;
		dig_buf[mode][1]=ds1302_buf[0]%0x10;
		dig_buf[mode][2]=17;
		dig_buf[mode][3]=ds1302_buf[1]/0x10;
		dig_buf[mode][4]=ds1302_buf[1]%0x10;
		dig_buf[mode][5]=17;
		dig_buf[mode][6]=ds1302_buf[2]/0x10;
		dig_buf[mode][7]=ds1302_buf[2]%0x10;
	}
	else if(mode==MODE2)
	{
		dig_buf[mode][0]=12;
		dig_buf[mode][2]=temp_max/10%10;
		dig_buf[mode][3]=temp_max%10;
		dig_buf[mode][4]=17;
		dig_buf[mode][5]=temp/1000%10;
		dig_buf[mode][6]=temp/100%10+32;
		dig_buf[mode][7]=temp/10%10;
	}
	else if(mode==MODE3)
	{
		dig_buf[mode][0]=18;
		dig_buf[mode][2]=water_max/10%10;
		dig_buf[mode][3]=water_max%10;
		dig_buf[mode][4]=17;
		dig_buf[mode][5]=water/100%10;
		dig_buf[mode][6]=water/10%10+32;
		dig_buf[mode][7]=water%10;
	}
	else if(mode==MODE4)
	{
		dig_buf[mode][0]=15;
		if(cnt>=10)
		{
			dig_buf[mode][1]=cnt/10%10;
			dig_buf[mode][2]=cnt%10;
		}
		else
		{
			dig_buf[mode][1]=0;
			dig_buf[mode][2]=cnt%10;
		}
		dig_buf[mode][3]=ds1302_buf_temp[0]/0x10;
		dig_buf[mode][4]=ds1302_buf_temp[0]%0x10;
		dig_buf[mode][5]=17;
		dig_buf[mode][6]=ds1302_buf_temp[1]/0x10;
		dig_buf[mode][7]=ds1302_buf_temp[1]%0x10;
	}
	else if(mode==MODE5)
	{
		dig_buf[mode][0]=24;
		dig_buf[mode][6]=temp_max/10%10;
		dig_buf[mode][7]=temp_max%10;
	}
	else if(mode==MODE6)
	{
		dig_buf[mode][0]=14;
		dig_buf[mode][3]=temp/1000%10;
		dig_buf[mode][4]=temp/100%10;
		dig_buf[mode][5]=17;
		dig_buf[mode][6]=water/100%10;
		dig_buf[mode][7]=water/10%10;
	}
}

void detect(void)
{
	if(last_light_flag==OFF&&light_flag==ON&&detect_flag==OFF)
	{
		detect_flag=ON;
		last_water=water;
		last_temp=temp;
		if(freq>=200&&freq<=2000)
		{
			water=((freq*20/45)+(100/9));
			led|=0x10;
		}
		else if(freq<200)
		{
			led&=~0x10;
			water=100;
		}
		else if(freq>2000)
		{
			led&=~0x10;
			water=900;
		}
		temp=rd_temperature();
		ds1302_buf_temp[0]=ds1302_buf[0];
		ds1302_buf_temp[1]=ds1302_buf[1];
		cnt++;
		if(mode_buf!=mode)
			mode_buf=mode;
		mode=MODE6;
		
	}
}

void led_handle(void)
{
	if(mode==MODE1) led&=~0x01;
	else  led|=0x01;
	if(mode>=1&&mode<=3) led&=~0x02;
	else	led|=0x02;
	if(mode==MODE6)  led&=~0x04;
	else	led|=0x04;
	if(temp>temp_max*100)
	{
		led_flag=ON;
	}
	else 
		led_flag=OFF;
	if(bline_flag==1)
	{
		led&=~0x08;
	}
	else
		led|=0x08;
	if(cnt>=2&&last_temp<temp&&last_water<water)
	{
		led&=~0x20;
	}
	else
	{
		led|=0x20;
	}
}

void main(void)
{
	ds1302_write();
	Timer0_Init();
	Timer1_Init();
	rd_temperature();
	rd_temperature();
	while(1)
	{
		freq_detect();
		if(time_10ms>=10)
		{
			light_detect();
			key_scan();
			key_handle();
			mode_select();
			led_handle();
			time_10ms=0;
		}
		if(time_200ms>=200)
		{
			pcfv=pcf8591_read(1)/0.51+0.5;
			light_detect();
			detect();
			ds1302_read();
			time_200ms=0;
		}
		if(time_50ms>=50)
		{
			
			time_50ms=0;
		}
	}
}

void Timer1_Isr(void) interrupt 3
{
	relay_buzzer(relay_flag,buzzer_flag);
	led_output(led);
	dig_show();
	time_100ms++;
	time_10ms++;
	time_50ms++;
	time_200ms++;
	if(detect_flag==ON)
		time_3000ms++;
	if(time_3000ms>=3000)
	{		
		detect_flag=OFF;
		mode=mode_buf;
		time_3000ms=0;
	}
	led_time++;
	if(led_flag==ON)
	{
		if(led_time>=100)
		{
			bline_flag=~bline_flag;
			led_time=0;
		}
	}
	else
		bline_flag=0;
	if(key_flag==1)
		key_time++;
	else
		key_time=0;
}
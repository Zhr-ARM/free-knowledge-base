#ifndef __I2C_H__
#define __I2C_H__

#include "main.h"

void write_at24c02(unsigned char addr,unsigned char *dat , unsigned char len);
uint8_t read_at24c02(unsigned char addr);
void write_pcf8591(unsigned char v);
uint32_t read_pcf8591(unsigned char addr);

#endif 
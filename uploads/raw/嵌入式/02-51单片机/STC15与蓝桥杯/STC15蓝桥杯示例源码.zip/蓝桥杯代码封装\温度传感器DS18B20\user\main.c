#include <STC15F2K60S2.H>
#include "smg.h"
#include "Onewire.h"
unsigned char cnt_temp=0;
unsigned int temperature;
void Timer2Init(void)		//1����@12.000MHz
{
	AUXR |= 0x04;		//��ʱ��ʱ��1Tģʽ
	T2L = 0x20;		//���ö�ʱ��ֵ
	T2H = 0xD1;		//���ö�ʱ��ֵ
	AUXR |= 0x10;		//��ʱ��2��ʼ��ʱ
	IE2|=0x04;
	EA=1;
}
void Timer2Service() interrupt 12
{
	show_smg();
	cnt_temp++;
}
void main()
{
	Timer2Init();
	while(1)
	{
		if(cnt_temp>=191)
		{
			cnt_temp=0;
			temperature=rd_temperature();
		}
		dig_buf[0]=temperature/1000;
		dig_buf[1]=temperature/100%10+32;
		dig_buf[2]=temperature/10%10;
		dig_buf[3]=temperature%10;
	}
}
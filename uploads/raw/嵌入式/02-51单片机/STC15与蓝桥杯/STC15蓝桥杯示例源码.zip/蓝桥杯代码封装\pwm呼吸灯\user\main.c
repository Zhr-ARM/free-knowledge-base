#include <STC15F2K60S2.H>
#include "pwm.h"
unsigned char led_buf=0x00;
unsigned char duty=2;
unsigned char duty_flag=0;
unsigned char cnt=0;
unsigned char T=20;
unsigned char time_100ms=0;

void Timer0Init(void)		//1����@12.000MHz
{
	AUXR |= 0x80;		//��ʱ��ʱ��1Tģʽ
	TMOD &= 0xF0;		//���ö�ʱ��ģʽ
	TL0 = 0x20;		//���ö�ʱ��ֵ
	TH0 = 0xD1;		//���ö�ʱ��ֵ
	TF0 = 0;		//���TF0��־
	TR0 = 1;		//��ʱ��0��ʼ��ʱ
	
	ET0=1;
	EA=1;
}
void Timer0Service(void) interrupt 1
{
	if(++cnt>=T)
		cnt=0;
	if(cnt<=duty)
		led_output();
	else
	{
		P0=0xFF;
		P2=P2&0x1f|0x80;
		P2&=0x1f;
	}
	if(++time_100ms>=100)
	{
		time_100ms=0;
		if(duty_flag==0)
			duty++;
		else if(duty_flag==1)
			duty--;
		if(duty==0)
			duty_flag=0;
		else if(duty==20)
			duty_flag=1;
	}
}

int main(void)
{
	Timer0Init();
	while(1)
	{
		
	}
}
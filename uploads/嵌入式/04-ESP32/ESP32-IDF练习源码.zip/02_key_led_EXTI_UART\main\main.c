#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "nvs_flash.h"
#include "led.h"
#include "key.h"
#include "exit.h"
#include "uart.h"
#include <stdio.h>
#include "string.h"

void app_main(void)
{
    uint8_t key;
    esp_err_t ret;
    uint8_t len = 0;
    uint16_t times = 0;
    unsigned char data[RX_BUF_SIZE] = {0};

    ret = nvs_flash_init(); /* 初始化 NVS */
    if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND)
    {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ret = nvs_flash_init();
    }
    led_init();
    key_init();
    exit_init();
    usart_init(115200);
    uint8_t buf[30]={0};
    sprintf((char*)buf,"\nthe message you send is: \r\n");
    while (1)
    {
        uart_get_buffered_data_len(USART_UX,(size_t *)&len);
        if(len>0)
        {
            memset(data,0,RX_BUF_SIZE);
            //printf("\nthe message you send is: \r\n");
            uart_write_bytes(USART_UX,(const char*)buf,strlen((const char*)buf));
            uart_read_bytes(USART_UX, data ,len,100);
            uart_write_bytes(USART_UX,(const char*)data,strlen((const char*)data));
        }
        else
        {
            times++;
            if(times % 500==0)
            {
                printf("Hello CDUT!\r\n");
            }
        }
        vTaskDelay(10);
    }
}

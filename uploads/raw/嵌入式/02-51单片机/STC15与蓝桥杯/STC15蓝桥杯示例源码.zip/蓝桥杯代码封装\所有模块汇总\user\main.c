#include "main.h"
#include "hardware.h"
#include "DS1302.h"
#include "I2C.h"
#include "Onewire.h"

#define Nops {_nop_();_nop_();_nop_();_nop_();_nop_();\
_nop_();_nop_();_nop_();_nop_();_nop_();\
_nop_();_nop_();_nop_();_nop_();_nop_();}//定义延时函数

uint8_t xdata time0_10ms = 0;
uint8_t xdata time0_191ms = 0;
uint8_t xdata uart_20ms = 0;
uint8_t xdata dis_t =0;
uint8_t xdata led = 0xff;

uint8_t xdata relay_flag = OFF;
uint8_t xdata buzzer_flag = OFF;

uint32_t xdata temp = 18;

uint8_t xdata at24_tx_buf[2]={56,87};
uint8_t	xdata at24_rx_buf[2]={0};

uint32_t xdata pcfv = 0;

uint8_t  mode = temp_mode;

void Delay14us()		//@12.000MHz
{
	unsigned char i;

	_nop_();
	_nop_();
	i = 39;
	while (--i);
}


sbit Trig = P1^0;		//定义Trig引脚
sbit Echo = P1^1;		//定义Echo引脚

void Sendwave()                 //发送8个脉冲
{
	unsigned char i;
	for(i = 0; i < 10; i++)
	{
	    Trig = 1;
		Delay14us();	
		Trig = 0;
		Delay14us();
	}
}
unsigned int xdata distance=0; 
void Get_distance()
{
    //每200ms发送一次
	if(dis_t<200) return;//通过dis_t判断发送频率
	dis_t = 0;
	CCON = 0;//清零
	CL = 0;//清零
	CH = 0;//清零
	CR = 0;//清零
	Sendwave();//发送8个脉冲
	CR = 1;//启动
	while(Echo&&!CF);//等待Echo为低电平
	CR = 0;//停止
	if(CF==1) {CF = 0; distance=255;}//如果CF为1,则距离为255
	if(!Echo) { distance = (CH<<8|CL)*0.017+3;}//如果Echo为0,则距离为(CH<<8|CL)*0.017+3
}


void UartInit(void) // 9600bps@12.000MHz
{
    SCON = 0x50;  // 8位数据,可变波特率
    AUXR |= 0x01; // 选择1为时钟源
    AUXR |= 0x04; // 时钟2为Fosc,1T
    T2L = 0xC7;   // 设置定时器2值
    T2H = 0xFE;   // 设置定时器2值
    AUXR |= 0x10; // 使能定时器2

    ES = 1;//使能串口中断
    EA = 1;//使能总中断
}
//接收信息中断
unsigned char xdata ri_value[20];//接收信息缓冲区,最多20个字符,最后一个字符为\0
unsigned char xdata ri_index = 0;
bit receieve_flag = 0;
void recive_uart () interrupt 4
{
	if ( RI == 1 )
	{
		RI = 0;
		if(SBUF!='\0')
		{
		ri_value[ri_index++] = SBUF;
		}
		else
		{
			receieve_flag = 1;
		}
	}	
}

void SendByte(uint8_t dat)
{
    SBUF = dat;
    while (TI==0);
    TI = 0;
}
void SendString(uint8_t *s)
{
    while (*s!='\0')
    {
        SendByte(*s++);
    }
	 ri_index = 0;
	 
	
}

void Timer0Init(void) // 1ms@12.000MHz
{
    AUXR |= 0x80; // 时钟1T模式
    TMOD &= 0xF0; // 使用定时器0模式
    TL0 = 0x20;   // 设置定时器0值
    TH0 = 0xD1;   // 设置定时器0值
    TF0 = 0;      // 清零TF0标志
    TR0 = 1;      // 启动定时器0

    ET0 = 1; // 使能定时器0中断
    EA = 1; // 使能总中断
}
void key_handle(void)
{
    if (key_value == 7 && key_state == 5)
        mode = at24_mode;
    else if (key_value == 11 && key_state == 5)
        mode = pcf_mode;
    else if (key_value == 15 && key_state == 5)
        mode = temp_mode;
    else if (key_value == 19 && key_state == 5)
        mode = ds18b20_mode;
    else if (key_value == 6 && key_state == 5)
        buzzer_flag = ON;
    else if (key_value == 10 && key_state == 5)
        buzzer_flag = OFF;
	else if (key_value == 14 && key_state == 5)
        relay_flag = ON;
    else if (key_value == 18 && key_state == 5)
        relay_flag = OFF;
	else if (key_value == 5 && key_state ==5)
		mode = uart_mode;
	else if (key_value ==9 && key_state == 5)
		mode = dis_mode;
}
void mode_handle(void)
{
    if (mode == temp_mode)
    {
        dig_buf[mode][4] = temp / 1000 % 10;
        dig_buf[mode][5] = temp / 100 % 10 + 32;
        dig_buf[mode][6] = temp / 10 % 10;
        dig_buf[mode][7] = temp % 10;
    }
    else if (mode == at24_mode)
    {
        dig_buf[mode][3] = at24_rx_buf[0] / 10;
        dig_buf[mode][4] = at24_rx_buf[0] % 10;
        dig_buf[mode][5] = 17;
        dig_buf[mode][6] = at24_rx_buf[1] / 10;
        dig_buf[mode][7] = at24_rx_buf[1] % 10;
    }
    else if (mode == pcf_mode)
    {
		dig_buf[mode][2] = pcfv / 100+32;
        dig_buf[mode][3] = pcfv / 10%10;
        dig_buf[mode][4] = pcfv % 10;   
    }
    else if (mode == ds18b20_mode)
    {
        dig_buf[mode][0]=ds1302_buf[0]/0x10;
        dig_buf[mode][1]=ds1302_buf[0]%0x10;
        dig_buf[mode][2]=17;
        dig_buf[mode][3]=ds1302_buf[1]/0x10;
        dig_buf[mode][4]=ds1302_buf[1]%0x10;
        dig_buf[mode][5]=17;
        dig_buf[mode][6]=ds1302_buf[2]/0x10;
        dig_buf[mode][7]=ds1302_buf[2]%0x10;
    }
	else if(mode == uart_mode)
	{
		dig_buf[mode][0]=ri_value[0]-48;
		dig_buf[mode][1]=ri_value[1]-48;
		dig_buf[mode][2]=ri_value[2]-48;
		dig_buf[mode][3]=ri_value[3]-48;
		dig_buf[mode][4]=ri_value[4]-48;
        dig_buf[mode][5]=ri_value[5]-48;
        dig_buf[mode][6]=ri_value[6]-48;
        dig_buf[mode][7]=ri_value[7]-48;
	}
	else if(mode == dis_mode)
	{
		dig_buf[mode][0] = distance/1000%10;
		dig_buf[mode][1] = distance/100%10+32;
		dig_buf[mode][2] = distance/10%10;
		dig_buf[mode][3] = distance%10;
	}
}
void main()
{
    P2 &= 0x1f;
	write_at24c02(0x00,at24_tx_buf,2);
    led = 0xff;
    relay_flag = OFF;
    buzzer_flag = OFF;
    temp = rd_temperature();
    ds1302_write();
    Timer0Init();
	UartInit();
	SendString("hello world");
//    write_pcf8591(5);//在内部电阻上施加5V电压,测量电流,若不用这个函数,固定一个警告
	
    while (1)
    {
		
        if (time0_10ms >= 10)
        {
            key_scan();
            key_handle();
            mode_handle();
			at24_rx_buf[0] = read_at24c02(0x00);
			at24_rx_buf[1] = read_at24c02(0x01);
            time0_10ms = 0;
        }
        if (time0_191ms >= 191)
        {
            temp = rd_temperature();
        //pcfv =  read_pcf8591(0)/0.51+0.5;//读取写入电压
		//pcfv =  read_pcf8591(1)/0.51+0.5;//读取光照强度
			pcfv =  read_pcf8591(3)/0.51+0.5;//读取滑动变阻器电压
            ds1302_read();			
            time0_191ms = 0;
        }
		
        if(ri_index != 0)
        {  
            SendString(ri_value); 
			receieve_flag = 0;
        }
		Get_distance();
        
    }
}
void Timer0Interrupt() interrupt 1
{
    dig_show();
    led_output(led);
    relay_buzzer(relay_flag, buzzer_flag);
    time0_10ms++;
    time0_191ms++;
	dis_t++;
   if(receieve_flag == 1)
    {
        uart_20ms++;
    }
}



#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include "freertos/FreeRTOS.h"
#include "freertos/task.h"
#include "esp_system.h"
#include "nvs_flash.h"
#include "esp_wifi.h"
#include "esp_event.h"
#include "esp_mac.h"
#include "led.h"
#include "lcd.h"
#include "wifi.h"

i2c_obj_t i2c0_master;
/**
 * @brief       程序入口
 * @param       无
 * @retval      无
 */
void app_main(void)
{
    esp_err_t ret;

    ret = nvs_flash_init();             /* 初始化NVS */

    if (ret == ESP_ERR_NVS_NO_FREE_PAGES || ret == ESP_ERR_NVS_NEW_VERSION_FOUND)
    {
        ESP_ERROR_CHECK(nvs_flash_erase());
        ret = nvs_flash_init();
    }

    led_init();                         /* 初始化LED */
    i2c0_master = iic_init(I2C_NUM_0);  /* 初始化IIC0 */
    spi2_init();                        /* 初始化SPI2 */
    xl9555_init(i2c0_master);           /* IO扩展芯片初始化 */
    lcd_init();                         /* 初始化LCD */

    lcd_show_string(0, 0, 240, 16, 16, "ESP32-S3", RED);
    lcd_show_string(0, 20, 240, 16, 16, "WiFi SCAN Test", RED);
    lcd_show_string(0, 40, 240, 16, 16, "ATOM@ALIENTEK", RED);
    lcd_draw_line(120,0,120,239,DARKBLUE);
    wifi_scan();
    uint8_t count = 0;
    while (1)
    {
        LED_TOGGLE();
        if(count++ > 8)  /* 每4秒开始扫描WIFI */
        {
            wifi_scan();        /* 扫描附件的WIFI */
            count = 0;
        }
        vTaskDelay(500);
    }
}

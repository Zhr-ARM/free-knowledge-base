#ifndef ___MPU6050_H__
#define ___MPU6050_H_

/**
 * @file    mpu6050.h
 * @brief   MPU6050六轴传感器驱动头文件
 * @details MPU6050是一款集成3轴陀螺仪和3轴加速度计的MEMS运动处理传感器
 *          - 陀螺仪量程: ±250, ±500, ±1000, ±2000 °/s
 *          - 加速度计量程: ±2g, ±4g, ±8g, ±16g
 *          - 通信接口: I2C (本驱动使用I2C1)
 *          - 16位ADC分辨率
 */

#include <stdint.h>

/*============================================================================
 *                         类型定义
 *===========================================================================*/

/**
 * @brief 四元数结构体
 */
typedef struct 
{
    float q0, q1, q2, q3;
} MPU6050_Quaternion_t;

/**
 * @brief 欧拉角结构体
 */
typedef struct
{
    float roll;
    float pitch;
    float yaw;
} MPU6050_EulerAngle_t;

/**
 * @brief 陀螺仪零偏结构体
 */
typedef struct
{
    float x;
    float y;
    float z;
} MPU6050_GyroOffset_t;

/**
 * @brief MPU6050设备句柄结构体
 * @note  包含设备配置、接口函数和运行时状态
 */
typedef struct
{
    /* 接口函数指针 (由用户提供) */
    uint8_t (*WriteReg)(uint8_t devAddr, uint8_t reg, uint8_t data);
    uint8_t (*ReadReg)(uint8_t devAddr, uint8_t reg, uint8_t *data, uint8_t len);
    void (*DelayMs)(uint32_t ms);
    
    /* 设备地址 */
    uint8_t devAddr;
    
    /* 配置参数 */
    float sampleRate;       /* 采样率 (Hz) */
    float mahonyKp;         /* Mahony滤波器比例增益 */
    
    /* 运行时状态 */
    MPU6050_Quaternion_t q;
    MPU6050_GyroOffset_t gyroOffset;
    float yawOffset;
    float yawAccumulated;
    
} MPU6050_Handle_t;

/*============================================================================
 *                         MPU6050寄存器地址定义
 *===========================================================================*/

/* 采样率分频寄存器 - 用于设置传感器采样频率 */
#define	MPU6050_SMPLRT_DIV 0x19     /* 采样率 = 陀螺仪输出率 / (1 + SMPLRT_DIV) */

/* 配置寄存器 - 用于设置FSYNC和数字低通滤波器(DLPF) */
#define	MPU6050_CONFIG 0x1A

/* 陀螺仪配置寄存器 - 用于设置陀螺仪量程 */
#define	MPU6050_GYRO_CONFIG 0X1B    /* FS_SEL[4:3]: 00=±250°/s, 01=±500°/s, 10=±1000°/s, 11=±2000°/s */

/* 加速度计配置寄存器 - 用于设置加速度计量程 */
#define	MPU6050_ACCEL_CONFIG 0x1C   /* AFS_SEL[4:3]: 00=±2g, 01=±4g, 10=±8g, 11=±16g */

/* 加速度计数据输出寄存器 (16位，高字节在前) */
#define	MPU6050_ACCEL_XOUT_H 0X3B   /* X轴加速度高8位 */
#define	MPU6050_ACCEL_XOUT_L 0x3C   /* X轴加速度低8位 */
#define	MPU6050_ACCEL_YOUT_H 0X3D   /* Y轴加速度高8位 */
#define	MPU6050_ACCEL_YOUT_L 0X3E   /* Y轴加速度低8位 */
#define	MPU6050_ACCEL_ZOUT_H 0X3F   /* Z轴加速度高8位 */
#define	MPU6050_ACCEL_ZOUT_L 0x40   /* Z轴加速度低8位 */

/* 温度传感器数据输出寄存器 (16位) */
#define	MPU6050_TEMP_OUT_H 0x41     /* 温度高8位 */
#define	MPU6050_TEMP_OUT_L 0x42     /* 温度低8位 */

/* 陀螺仪数据输出寄存器 (16位，高字节在前) */
#define	MPU6050_GYRO_XOUT_H 0x43    /* X轴角速度高8位 */
#define	MPU6050_GYRO_XOUT_L 0x44    /* X轴角速度低8位 */
#define	MPU6050_GYRO_YOUT_H 0X45    /* Y轴角速度高8位 */
#define	MPU6050_GYRO_YOUT_L 0x46    /* Y轴角速度低8位 */
#define	MPU6050_GYRO_ZOUT_H 0x47    /* Z轴角速度高8位 */
#define	MPU6050_GYRO_ZOUT_L 0x48    /* Z轴角速度低8位 */

/* 电源管理寄存器 */
#define	MPU6050_PWR_MGMT_1 0x6B     /* 电源管理1: 设备复位、睡眠模式、时钟源选择 */
#define	MPU6050_PWR_MGMT_2 0x6C     /* 电源管理2: 待机模式、加速度/陀螺仪使能控制 */

/* 设备ID寄存器 - 用于验证设备连接，默认值为0x68 */
#define	MPU6050_WHO_AM_I 0x75

/*============================================================================
 *                           函数声明
 *===========================================================================*/

/**
 * @brief  初始化MPU6050传感器
 * @param  dev: 设备句柄指针
 * @note   配置采样率、低通滤波器、陀螺仪和加速度计量程
 */
void MPU6050_Init(MPU6050_Handle_t *dev);

/**
 * @brief  读取所有传感器数据(加速度计和陀螺仪)
 * @param  dev: 设备句柄指针
 * @param  ax: X轴加速度指针 (单位: g)
 * @param  ay: Y轴加速度指针 (单位: g)
 * @param  az: Z轴加速度指针 (单位: g)
 * @param  gx: X轴角速度指针 (单位: °/s)
 * @param  gy: Y轴角速度指针 (单位: °/s)
 * @param  gz: Z轴角速度指针 (单位: °/s)
 */
void MPU6050_ReadSensors(MPU6050_Handle_t *dev, float *ax, float *ay, float *az, float *gx, float *gy, float *gz);

/**
 * @brief  陀螺仪零偏校准
 * @param  dev: 设备句柄指针
 */
void MPU6050_CalibrateGyro(MPU6050_Handle_t *dev);

/**
 * @brief  Mahony互补滤波姿态更新
 * @param  dev: 设备句柄指针
 * @param  dt: 采样周期 (秒)
 */
void MPU6050_UpdateAttitude(MPU6050_Handle_t *dev, float dt);

/**
 * @brief  获取欧拉角
 * @param  dev: 设备句柄指针
 * @param  euler: 欧拉角结构体指针
 */
void MPU6050_GetEulerAngles(MPU6050_Handle_t *dev, MPU6050_EulerAngle_t *euler);

/**
 * @brief  重置姿态解算器
 * @param  dev: 设备句柄指针
 */
void MPU6050_ResetAttitude(MPU6050_Handle_t *dev);

/**
 * @brief  设置Yaw轴零点
 * @param  dev: 设备句柄指针
 */
void MPU6050_SetYawZero(MPU6050_Handle_t *dev);

/**
 * @brief  将陀螺仪原始值转换为角速度

 * @param  value: 陀螺仪原始ADC值
 * @param  range: 陀螺仪量程配置值
 * @retval 角速度值 (单位: °/s)
 */
float MPU6050_ConvertGyro(int16_t value, uint8_t range);

/**
 * @brief  将加速度计原始值转换为加速度
 * @param  value: 加速度计原始ADC值
 * @param  range: 加速度计量程配置值
 * @retval 加速度值 (单位: g)
 */
float MPU6050_ConvertAccel(int16_t value, uint8_t range);

#endif


#ifndef TETRIS_H__
#define TETRIS_H__

#include <stdio.h>
#include <windows.h>
#include <conio.h>
#include <stdlib.h>
#include <time.h>

//游戏区域大小常量
#define GAME_BOARD_HEIGHT	22
#define GAME_BOARD_WIDTH	16
#define PLAYABLE_AREA_WIDTH	14

//屏幕区域位置偏移量  - 控制游戏区域在屏幕上的位置
#define SCREEN_OFFSET_X		15
#define SCREEN_OFFSET_Y		2

//信息区域位置常量
#define INFO_AREA_X			50
#define INFO_AREA_Y			5	

//方块状态常量
#define CELL_EMPTY			-1
#define CELL_BORDER			-2

//方块类型枚举定义
enum PieceType{
	PIECE_I,
	PIECE_O,
	PIECE_T,
	PIECE_S,
	PIECE_Z,
	PIECE_J,
	PIECE_L
};

//控制台颜色枚举定义
enum ConsoleColors {
	COLOR_WHITE = 7,		//白色/默认色
	COLOR_ORANGE = 6,		//橙色
	COLOR_GRAY = 8,			//灰色
	COLOR_BLUE = 9,			//蓝色
	COLOR_GREEN = 10,		//绿色
	COLOR_CYAN = 11,		//青色
	COLOR_RED = 12,			//红色
	COLOR_MAGENTA = 13,		//紫色
	COLOR_YELLOW = 14,		//黄色
	COLOR_BRIGHT_WHITE = 15	//亮白色
};

//按键枚举定义
enum{
	KEY_LEFT = 75,
	KEY_RIGHT = 77,
	KEY_UP = 72,
	KEY_DOWN = 80,
	KEY_SPACE = 32,
	KEY_QUIT = 27,
	KEY_ARROW = 224
};

//游戏状态结构体
typedef struct{
	int game_borad[GAME_BOARD_HEIGHT][GAME_BOARD_WIDTH];	//直接保存方块类型，-1空，-2边框，0-6方块类型
	int current_score;
	int total_lines_cleared;
	int current_level;
	int game_over_flag;
} TetrisGameState;

//方块结构体
typedef struct {
	int piece_shape[4][4];
	int position_x, position_y;
	int piece_type;
} TetrisPiece;

#endif
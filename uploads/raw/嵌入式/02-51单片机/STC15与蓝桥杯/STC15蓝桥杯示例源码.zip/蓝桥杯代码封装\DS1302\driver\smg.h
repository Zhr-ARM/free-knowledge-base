#ifndef __SMG_H__
#define __SMG_H__
extern unsigned char code t_display[];
extern unsigned char code T_COM[];
extern unsigned char smg_buf[];
void show_smg();
#endif
#ifndef __I2C_H__
#define __I2C_H__

#include "main.h"

void at24c02_write(uint8_t addr,uint8_t *dat,uint8_t len);
uint8_t at24c02_read(uint8_t addr);
uint32_t pcf8591_read(uint8_t addr);

#endif
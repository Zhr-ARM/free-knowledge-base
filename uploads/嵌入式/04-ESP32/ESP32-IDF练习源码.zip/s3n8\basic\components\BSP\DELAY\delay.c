#include "delay.h"

/**
 * @brief 毫秒级阻塞延时（基于 FreeRTOS）
 * @param ms 需要延时的毫秒数
 * @note  调用该函数会阻塞当前任务，期间 CPU 可调度至其他任务；
 *        仅能在已启用 FreeRTOS 调度器的环境中使用。
 */
void delay_ms(uint32_t ms)
{
    vTaskDelay(ms);
}

/**
 * @brief 微秒级阻塞忙延时（基于 ROM 实现）
 * @param us 需要延时的微秒数
 * @note  调用该函数会阻塞当前任务并占用 CPU，期间不会切换任务；
 *        适用于对延时精度要求较高的场景。
 */
void delay_us(uint32_t us)
{
    esp_rom_delay_us(us);
}

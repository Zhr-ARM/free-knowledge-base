#ifndef __MAIN_H__
#define __MAIN_H__

#define uint8_t unsigned char
#define uint32_t unsigned int

#endif 